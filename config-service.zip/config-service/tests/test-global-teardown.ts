// globalTeardown
module.exports = async function afterTests() {
    process.exit(0);
};
