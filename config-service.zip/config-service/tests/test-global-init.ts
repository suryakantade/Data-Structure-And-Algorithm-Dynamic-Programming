import { SdkUtility } from "@khatabook/test-sdk/build/sdk-utility";
import { PgDatabaseUtility } from "@khatabook/test-sdk/build/database-utility";
import { TestConstants } from "./common/test-constants";

import { path } from "app-root-path";
// import { bootstrap } from "../../mock-server/src/mock-index";
import { render } from "nunjucks";
import { CommonSetupTestHelper } from "./common/common-setup.test.helper";

const appConf = require(`${path}/server/config.json`);
let sdkUtility = new SdkUtility();

async function createTestDB(config) {
    // Create a Test DB
    const pgUtility = new PgDatabaseUtility({
        host: config.pgOptions.connection.host,
        port: config.pgOptions.connection.port,
        user: config.pgOptions.connection.user,
        password: config.pgOptions.connection.password,
        database: config.pgOptions.connection.database
    });

    try {
        await pgUtility.terminateSession(TestConstants.PG_TEMPLATE_DB);
        await pgUtility.deleteDatabase(TestConstants.PG_TEMPLATE_DB);
    } catch (e) {
        console.log(
            `DB doesnt exists: ${TestConstants.PG_TEMPLATE_DB} Creating a new DB : ${TestConstants.PG_TEMPLATE_DB}`
        );
    }
    await pgUtility.createDatabase(TestConstants.PG_TEMPLATE_DB);

    appConf.pgOptions.connection.database = TestConstants.PG_TEMPLATE_DB;
    await CommonSetupTestHelper.runMigration(TestConstants.PG_TEMPLATE_DB);

    await pgUtility.terminateSession(TestConstants.PG_TEMPLATE_DB);
}

module.exports = async function init() {
    // Starts Mock server and override test-config
    // TODO: Currently we don't have a use-case for mock-server so this is disabled
    // Substitutes randomMockPort with the port address of mock instantiated
    // const port = await bootstrap();
    // const testOverride = JSON.parse(
    //   render(`${path}/tests/override.json`, { randomMockPort: port })
    // );
    const testOverride = JSON.parse(render(`${path}/tests/override.json`));

    // create a new config-file that will be used by the application
    sdkUtility.overrideConfigFile(TestConstants.TEST_CONFIG, appConf, testOverride);

    // point config path to new test config created in above step
    // ConfigService will pick config file from this path
    process.env.CONFIG_PATH = `${path}/${TestConstants.TEST_CONFIG}`;

    // Sanity test whether nest server is coming up
    // const module: TestingModule = await Test.createTestingModule({
    //     imports: [AppModule]
    // }).compile();

    // Create a test DB. This test db will be further used as a template to create more dbs during tests.
    await createTestDB(testOverride);
    // const app: INestApplication = module.createNestApplication();
    // await app.init();

    // await healthCheck(app); // health check to ensure application is running fine
};
