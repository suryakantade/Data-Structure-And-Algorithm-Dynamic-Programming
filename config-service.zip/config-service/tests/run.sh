#!/usr/bin/env bash
#
set -e
set -x

# Install dependencies
npm install
npm run build-server

# Start the Docker container
# Execute docker-compose up command to start any db, redis container
npm run testdb:start

# Start the Integration test
npm run test:integration

# Stop the docker container
# Execute docker-compose down command to stop any db, redis container
npm run testdb:stop

echo 'Test execution completed'
