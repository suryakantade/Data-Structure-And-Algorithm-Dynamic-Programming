export class TestConstants {
    static TEST_CONFIG = "test-config.json";
    static PG_TEMPLATE_DB = "test";
}
