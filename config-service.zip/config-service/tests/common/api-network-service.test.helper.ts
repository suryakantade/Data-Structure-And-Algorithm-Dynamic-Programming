import { NetworkUtility } from "@khatabook/test-sdk/build/network-utility";
import { HttpRequestDto } from "@khatabook/test-sdk/build/common/types";

const networkUtility = new NetworkUtility();

export class ApiNetworkServiceTestHelper {
    static async get(param: HttpRequestDto) {
        return networkUtility.get(param);
    }

    static async post(param: HttpRequestDto) {
        return networkUtility.post(param);
    }

    static async put(param: HttpRequestDto) {
        return networkUtility.put(param);
    }
}
