import { Knex } from "knex";
import { INestApplication } from "@nestjs/common";
import * as assert from "assert";
import { TestDatabaseInfo } from "./types.test.helper";
import { ApiNetworkServiceTestHelper } from "./api-network-service.test.helper";
import { defaultInternalConfig } from "../../server/src/lib/internal-config/internal-config.service";
import { CommonSetupTestHelper } from "./common-setup.test.helper";

const conf = defaultInternalConfig;

export class TestPreRequisiteHelpers {
    static async initTestDbSetup(): Promise<TestDatabaseInfo> {
        // Create a new random database name
        const databaseName = "test".concat(CommonSetupTestHelper.getRandomDatabaseName());
        conf.pgOptions.connection.database = databaseName;

        // const kb = await TestPreRequisiteHelpers.setupAndGetKbObject(databaseName);

        // setup test database
        const databaseClient: Knex = await CommonSetupTestHelper.createRandomDataBaseFromTemplate(databaseName);

        return {
            databaseName,
            databaseClient
        };
    }
}

export async function healthCheck(app: INestApplication) {
    const response = await ApiNetworkServiceTestHelper.get({
        app: app.getHttpServer(),
        endpoints: "/health"
    });
    assert.strictEqual<number>(response.statusCode, 200);
}
