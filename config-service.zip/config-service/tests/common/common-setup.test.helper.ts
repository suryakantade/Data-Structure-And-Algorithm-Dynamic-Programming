import { PgDatabaseUtility } from "@khatabook/test-sdk/build/database-utility";
import { defaultInternalConfig } from "../../server/src/lib/internal-config/internal-config.service";
import { ServerConfig } from "../../server/src/utils/types/types";

const conf = defaultInternalConfig;
const path = require("path");
const fs = require("fs");
const util = require("util");
const childProcess = require("child_process");
const exec = util.promisify(childProcess.exec).bind(childProcess);

export class CommonSetupTestHelper {
    static getRandomDatabaseName() {
        return Math.random()
            .toString(36)
            .replace(/[^a-z]+/g, "")
            .substr(0, 10);
    }

    static async createRandomDataBaseFromTemplate(testDatabase: string) {
        const pgUtility = new PgDatabaseUtility({
            host: conf.pgOptions.connection.host,
            port: conf.pgOptions.connection.port,
            user: conf.pgOptions.connection.user,
            password: conf.pgOptions.connection.password,
            database: "config_service"
        });
        try {
            await pgUtility.deleteDatabase(testDatabase);
        } catch (e) {
            console.log("Database doesnt exists");
        }

        await pgUtility.executeSqlQuery(`CREATE DATABASE ${testDatabase} WITH TEMPLATE test;`);

        const pgTestClient = require("knex")({
            client: "pg",
            connection: {
                host: conf.pgOptions.connection.host,
                port: conf.pgOptions.connection.port,
                user: conf.pgOptions.connection.user,
                password: conf.pgOptions.connection.password,
                database: testDatabase
            }
        });

        // const pgMockClient = new PgDatabaseUtility({
        //     host: testConfig.mockServer.pgOptions.connection.host,
        //     port: testConfig.mockServer.pgOptions.connection.port,
        //     user: testConfig.mockServer.pgOptions.connection.user,
        //     password: testConfig.mockServer.pgOptions.connection.password,
        //     database: testConfig.mockServer.pgOptions.connection.database,
        // });
        // return [pgTestClient, pgMockClient];
        return pgTestClient;
    }

    static getMigrationDir() {
        return path.join(__dirname, "../../server/", "migrations");
    }

    static getMigrationFile(migrationFile) {
        return path.join(__dirname, "../../server/", "migrations", migrationFile);
    }

    static async deleteDataBase(name: string, oldClient) {
        const pgClient = new PgDatabaseUtility({
            host: conf.pgOptions.connection.host,
            port: conf.pgOptions.connection.port,
            user: conf.pgOptions.connection.user,
            password: conf.pgOptions.connection.password,
            database: "config_service"
        });

        await pgClient.terminateSession(name);
        await pgClient.deleteDatabase(name);
    }

    static async runMigration(name) {
        const migrations = fs.readdirSync(CommonSetupTestHelper.getMigrationDir()).sort();

        for (const migration of migrations) {
            const sqlFile = this.getMigrationFile(migration);
            const connectString = CommonSetupTestHelper.getConnectString(name);
            const sqlCommand = await CommonSetupTestHelper.getSqlCommandUsingFile(connectString, sqlFile);
            await exec(sqlCommand);
        }
    }

    static async getSqlCommandUsingFile(connectString: string, file: string) {
        return `psql "${connectString}" -f ${file}`;
    }

    static getBasePath(config: ServerConfig) {
        return `${config.host}:${config.port}/${config.path}`;
    }

    static getRandomPort(min = 4000, max = 9000) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    static getConnectString(db: string) {
        const dbConnection = conf.pgOptions.connection;
        return `postgres://${dbConnection.user}:${dbConnection.password}@${dbConnection.host}:${dbConnection.port}/${db}`;
    }

    static getIntraAuthApiToken(): string {
        return conf.intraAuthConfig.token;
    }
}
