import { INestApplication } from "@nestjs/common";
import { Knex } from "knex";

export interface TestDatabaseInfo {
    databaseName: string;
    databaseClient: Knex;
}

export interface TestInitData {
    app: INestApplication;
    db: TestDatabaseInfo;
}
