import * as Joi from "joi";

export class TestUtility {
    static getPowerSetOfArray<T>(arr: T[]): T[][] {
        return arr.reduce(
            (subsetsTillNow: T[][], currentValue: T) => {
                return subsetsTillNow.concat(subsetsTillNow.map((subSet) => [...subSet, currentValue]));
            },
            [[]]
        );
    }

    static joiValidator(testSchema, testResponse) {
        const { error, value: validatedConfig } = Joi.object(testSchema).validate(testResponse);
        if (error) {
            throw new Error(`JOI Config validation error: ${error.message}`);
        }
        return validatedConfig;
    }
}
