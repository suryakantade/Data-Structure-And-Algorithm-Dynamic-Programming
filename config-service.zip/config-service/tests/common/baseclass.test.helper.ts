import { Test, TestingModule } from "@nestjs/testing";
import { TestPreRequisiteHelpers } from "./pre-setup.test.helper";
import { NestExpressApplication } from "@nestjs/platform-express";
import { AppModule } from "../../server/src/app.module";
import { TestInitData } from "./types.test.helper";
import { getServerConfig, setup } from "../../server/src/server";
import { MockFunctionMetadata, ModuleMocker } from "jest-mock";
import { ModuleMetadata } from "@nestjs/common/interfaces/modules/module-metadata.interface";
import { INestApplication } from "@nestjs/common";
import { Knex } from "knex";

export async function initTestApplication(): Promise<TestInitData> {
    // This is shared utility, DO NOT CHANGE unless change is required in pipes and filters
    // For each testsuite setup we use TestPreRequisiteHelpers for
    // - initializing a random db
    // - updating a new config with that randomDBName
    const db = await TestPreRequisiteHelpers.initTestDbSetup();
    const module: TestingModule = await Test.createTestingModule({
        imports: [AppModule]
    }).compile();

    // Start the nest application
    const app: NestExpressApplication = module.createNestApplication<NestExpressApplication>();
    setup(app, getServerConfig());
    await app.init();
    return { app, db: db };
}

export async function teardownTestApplication(app: INestApplication, dbClient: Knex) {
    await app.close();
    await dbClient.destroy();
}

/**
 * Method to initialise a testing module mainly for unit tests, it does automocking for the dependencies
 * Reference: https://docs.nestjs.com/fundamentals/testing#auto-mocking
 * @param moduleMetadata
 */
export async function initTestModule(moduleMetadata: ModuleMetadata): Promise<TestingModule> {
    const moduleMocker = new ModuleMocker(global);
    const module = await Test.createTestingModule(moduleMetadata)
        .useMocker((token) => {
            const mockMetadata = moduleMocker.getMetadata(token) as MockFunctionMetadata<any, any>;
            const Mock = moduleMocker.generateFromMetadata(mockMetadata);
            return new Mock();
        })
        .compile();
    return module;
}
