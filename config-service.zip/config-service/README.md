# About

Client facing service to fetch any type of config

This repo is created from [nest-service-template](https://gitlab.com/khatabook/platform/nest-service-template), please
refer README of nest-template for basic overview

# Running Locally

## Inside Docker Container

1. Get config file and save to `config/local/config.json` in root directory (`local` is the DEPLOYMENT_ENV that we will
   pass while starting the container).
2. Build the main docker image:
    ```shell 
    docker build -t config-service:latest -f docker/Dockerfile .
    ```
3. Build local docker image for quick local development
    ```shell 
    docker build -t config-service-local:latest -f docker/local.Dockerfile .
    ```
4. Start container:
   ```shell 
    docker run --rm -it -e DEPLOYMENT_ENV="local" -v /Users/garvit/repo/config-service/server/src:/application/server/src -p 8964:8964 config-service-local
    ```

## Without Docker:

1. Get config file and save it in `server` directory
2. Run command: `npm run start-dev`

# Code Formatting

- This repo is integrated with [prettier](https://prettier.io/) to ensure consistent code formatting across multiple
  developers and to avoid formatting related review changes
- All files can be formatted in one go by running `npm run format`
- Rather than formatting all file, recommended way is to integrate the tool to automatically format on save so that file
  is formatted as soon as it is saved. Most major IDEs support "format-on-save" integration with prettier.
    - [WebStorm integration](https://www.jetbrains.com/help/webstorm/prettier.html#ws_prettier_run_automatically_in_current_project)
    - [vs-code integration](https://www.digitalocean.com/community/tutorials/code-formatting-with-prettier-in-visual-studio-code)