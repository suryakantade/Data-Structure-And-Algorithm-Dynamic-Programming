CREATE TYPE config_tenant AS ENUM ('KHATABOOK');

CREATE TYPE config_entity_type AS ENUM ('DEFAULT', 'FEATURE', 'VALIDATION');

CREATE TYPE config_status AS ENUM ('DRAFT', 'LIVE', 'DELETED');

CREATE TYPE config_target_type AS ENUM ('ANONYMOUS_ID', 'USER_ID');

CREATE TABLE config (

    id UUID PRIMARY KEY NOT NULL,

    name VARCHAR UNIQUE NOT NULL,

    target_type config_target_type NOT NULL,

    tenant config_tenant NOT NULL,

    entity_type config_entity_type NOT NULL,

    client_meta JSONB NULL,

    config_value JSONB NULL,

    status config_status NOT NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    created_by VARCHAR NULL,

    updated_by VARCHAR NULL,

    -- this unique index is needed for "ON CONFLICT" clause
    UNIQUE(name, id)
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS config_tenant_idx ON config(tenant);
CREATE INDEX CONCURRENTLY IF NOT EXISTS config_entity_type_idx ON config(entity_type);
