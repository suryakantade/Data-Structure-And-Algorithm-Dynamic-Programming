CREATE TYPE rollout_status AS ENUM ('DRAFT', 'LIVE', 'DELETED');

CREATE TABLE rollout (

    id UUID NOT NULL PRIMARY KEY,

    name VARCHAR NOT NULL,

    config_id UUID NOT NULL,

    rollout_percent NUMERIC NOT NULL
        CHECK(rollout_percent >= 0 AND rollout_percent <= 100),

    segment_id UUID NULL,

    experiment_id UUID NULL,

    status rollout_status NOT NULL,

    constraints JSONB NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    created_by VARCHAR NULL,

    updated_by VARCHAR NULL,

    FOREIGN KEY(config_id) REFERENCES config(id),

    UNIQUE(id, config_id),

    -- Duplicate rollout names not allowed for a given config
    -- works for select by config_id also
    UNIQUE(config_id, name)
);