import { Module } from "@nestjs/common";
import { LibModule } from "./lib/lib.module";
import { MiddlewareModule } from "./common/middleware/middleware.module";
import { RolloutModule } from "./features/rollout/rollout.module";
import { ConfigModule } from "./features/config/config.module";
import { HashModule } from "./features/hash/hash.module";
import { ClientAnalyticsModule } from "./features/client-analytics-config/client-analytics-config.module";

@Module({
    imports: [LibModule, MiddlewareModule, ClientAnalyticsModule, ConfigModule, RolloutModule, HashModule]
})
export class MainModule {}
