require("newrelic");
import { getServerConfig, Server } from "./server";

const server = new Server(getServerConfig(), {
    cors: true
});
server.boot();
