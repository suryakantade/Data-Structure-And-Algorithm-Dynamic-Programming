import { Helper } from "../../helper";

describe("Unit tests for global helper functions", () => {
    describe("Test isStructureMatch() function", () => {
        test.each([
            ["match", {}, {}, true],
            ["match", null, null, true],
            ["match", { a: 123, b: 456 }, { a: 456 }, true],
            ["match", { a: 123 }, null, true],
            ["not match", { a: 123 }, { a: 49, b: 456 }, false],
            ["not match", null, { b: 456 }, false],
            ["not match", {}, { b: 456 }, false]
        ])(
            "should %s, testObject: %s, sourceObject: %s",
            (_, testObject: any, sourceObject: any, expectedOutput: boolean) => {
                const isMatch = Helper.isStructureMatch(testObject, sourceObject);
                expect(isMatch).toBe(expectedOutput);
            }
        );
    });
});
