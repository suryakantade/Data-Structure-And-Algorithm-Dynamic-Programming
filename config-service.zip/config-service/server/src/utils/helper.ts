import { validateSync, ValidationError } from "class-validator";
import { Environment } from "./types/types";
import { ClassConstructor, plainToClass } from "class-transformer";
import * as uuid from "uuid";

export class Helper {
    static isNullOrUndefined(value) {
        return value === null || value === undefined;
    }

    static validateClassSync<T extends object>(
        cls: ClassConstructor<T>,
        value: object
    ): {
        object: T;
        errors: ValidationError[];
    } {
        const object = plainToClass(cls, value);

        const errors: ValidationError[] = validateSync(object, {
            whitelist: true
        });

        return { object, errors };
    }

    static getEnvironment(): Environment {
        const env = process.env.DEPLOYMENT_ENV || process.env.ENV || process.env.NODE_ENV;
        if (!env) {
            return Environment.DEV;
        }
        switch (env.toLowerCase()) {
            case "prod":
                return Environment.PRODUCTION;
            case "production":
                return Environment.PRODUCTION;
            case "staging":
                return Environment.STAGING;
        }
        return Environment.DEV;
    }

    static getUUID() {
        return uuid.v4();
    }

    // tslint:disable-next-line: no-any
    static deleteAllUndefined(obj: any, checker = (value: any) => value === undefined) {
        if (obj instanceof Array) {
            obj.forEach((data) => Helper.deleteAllUndefined(data));
        } else if (typeof obj === "object") {
            for (const key in obj) {
                const value = obj[key];
                if (checker(value)) {
                    delete obj[key];
                }
                if (obj[key] instanceof Array) {
                    obj[key].forEach((data) => Helper.deleteAllUndefined(data));
                } else if (typeof obj[key] === "object") {
                    Helper.deleteAllUndefined(obj[key]);
                }
            }
        }
    }

    static isStructureMatch(testObject: object | null, sourceObject: object | null): boolean {
        if (testObject === null && sourceObject === null) {
            return true;
        }
        if (testObject === null && sourceObject !== null) {
            return false;
        }

        if (testObject !== null && sourceObject === null) {
            return true;
        }

        return !Object.keys(sourceObject!).some((sourceKey) => Helper.isNullOrUndefined(testObject![sourceKey]));
    }
}
