export class Constants {
    static DATABASE_SERVICE_TOKEN = "DATABASE_SERVICE";

    static CONFIG_TOKEN = "CONFIG";

    static PROCESS_READY = "ready";

    static PG_DB_POOL = {
        min: 2,
        max: 100
    };

    static PG_DB_ACQUIRE_CONNECTION_TIMEOUT_IN_MILLIS = 1000;

    static CLS_NAMESPACE = "CLS_NAMESPACE";

    static TRACE_ID = "trace-id";

    static HEADERS = {
        X_KB_APP_NAME: "x-kb-app-name",
        X_KB_PLATFORM: "x-kb-platform",
        X_KB_APP_VERSION: "x-kb-app-version",
        X_API_TOKEN: "x-api-token"
    };

    static SUCCESS_RESPONSE = {
        success: true,
        message: "OK"
    };
}
