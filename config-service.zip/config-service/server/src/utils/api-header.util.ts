import { Constants } from "./constants";
import { Request } from "express";
import { Helper } from "./helper";
import { parseInt } from "lodash";
import { WrongInput } from "../common/error/WrongInput";
import { Tenant } from "../common/models/tenant.enum";

const APP_NAME_TO_TENANT_MAPPING: Record<string, Tenant | undefined> = {
    khatabook: Tenant.KHATABOOK
};

export function getPlatformFromHeaders(req: Request): string | undefined {
    const headerName = Constants.HEADERS.X_KB_PLATFORM;
    return req.headers[headerName] as string | undefined;
}

export function getAppVersionFromHeaders(req: Request): number | undefined {
    const headerName = Constants.HEADERS.X_KB_APP_VERSION;
    const headerValue = req.headers[headerName] as string | undefined;
    return Helper.isNullOrUndefined(headerValue) ? undefined : parseInt(headerValue as string);
}

export function getApiTokenFromHeaders(req: Request): string | undefined {
    const headerName = Constants.HEADERS.X_API_TOKEN;
    return req.headers[headerName] as string | undefined;
}

export function getAppNameFromHeadersOrThrow(req: Request): string {
    const headerName = Constants.HEADERS.X_KB_APP_NAME;
    const headerValue = req.headers[headerName];
    if (!headerValue) {
        throw new WrongInput(`${Constants.HEADERS.X_KB_APP_NAME} is mandatory`);
    }
    return headerValue as string;
}

export function getTenantFromAppName(req: Request): Tenant {
    const appName = getAppNameFromHeadersOrThrow(req);
    const tenant = APP_NAME_TO_TENANT_MAPPING[appName];
    if (!tenant) {
        throw new WrongInput(`Unable to deduce tenant from app name: ${appName}`);
    }
    return tenant;
}
