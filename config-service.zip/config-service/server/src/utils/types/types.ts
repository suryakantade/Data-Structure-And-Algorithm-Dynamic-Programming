import express = require("express");
import { NestExpressApplication } from "@nestjs/platform-express";

export const enum Environment {
    DEV = "DEV",
    PRODUCTION = "PRODUCTION",
    STAGING = "STAGING"
}

export interface ServerConfig {
    host: string;
    path: string;
    port: number;
}

export interface BaseServer {
    config: ServerConfig;
    app: NestExpressApplication;
    boot: () => void;
    close: () => void;
}

export type ReqWithRawBody = express.Request & { rawBody: string };
