import * as Bluebird from "bluebird";
import * as bodyParser from "body-parser";

import { NestExpressApplication } from "@nestjs/platform-express";
import { NestFactory } from "@nestjs/core";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { NestApplicationOptions, ValidationPipe, VersioningType } from "@nestjs/common";

import { Helper } from "./utils/helper";
import { Environment, BaseServer, ServerConfig, ReqWithRawBody } from "./utils/types/types";
import { GlobalResponseInterceptor } from "./common/interceptors/global-response.interceptor";
import { AppModule } from "./app.module";
import { defaultInternalConfig } from "./lib/internal-config/internal-config.service";

const config = defaultInternalConfig;

// this is done to ensure that logging is always done through logger and to avoid any sensitive PII data from getting logged in production accidentally.
console.log = function () {};

function setupAPIDocs(app: NestExpressApplication, serverConfig: ServerConfig) {
    if (Helper.getEnvironment() === Environment.PRODUCTION) {
        return;
    }
    const swaggerConfig = new DocumentBuilder()
        .setTitle("Configuration Service")
        .setDescription("Client facing service to fetch different types of configurations")
        .setVersion("1.0")
        .build();
    const document = SwaggerModule.createDocument(app, swaggerConfig);

    const path = serverConfig.path ? `/${serverConfig.path}/apidocs` : "/apidocs";
    SwaggerModule.setup(path, app, document);
}

function setupVersioning(app: NestExpressApplication) {
    app.enableVersioning({
        type: VersioningType.URI
    });
}

function setupBluebirdAsPromise() {
    global.Promise = Bluebird;
}

function setupInterceptors(app: NestExpressApplication) {
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
}

function setupPipes(app: NestExpressApplication) {
    app.useGlobalPipes(
        new ValidationPipe({
            whitelist: true
        })
    );
}

function setupGlobalPrefix(app: NestExpressApplication) {
    app.setGlobalPrefix(config.path || "");
}

function setupReqRawBody(app: NestExpressApplication) {
    app.use(
        bodyParser.json({
            limit: "5mb",

            verify: (req: ReqWithRawBody, res, buffer) => {
                req.rawBody = buffer.toString();
            }
        })
    );
}

export function setup(app: NestExpressApplication, serverConfig: ServerConfig) {
    setupGlobalPrefix(app);
    setupVersioning(app);
    setupBluebirdAsPromise();
    setupReqRawBody(app);
    setupAPIDocs(app, serverConfig);
    setupInterceptors(app);
    setupPipes(app);
}

export function getServerConfig(): ServerConfig {
    return {
        port: config.port,
        host: config.host,
        path: config.path
    };
}

export class Server implements BaseServer {
    app: NestExpressApplication;

    constructor(readonly config: ServerConfig, readonly nestConfig?: NestApplicationOptions) {}

    async init() {
        const app = await NestFactory.create<NestExpressApplication>(AppModule, this.nestConfig);
        app.set("trust proxy", 1);

        this.app = app;
        setup(this.app, this.config);
        return this;
    }

    async boot() {
        await this.init();
        await this.app.listen(this.config.port);
    }

    async close() {
        await this.app.close();
    }
}
