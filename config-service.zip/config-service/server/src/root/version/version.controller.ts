import { Controller, Get } from "@nestjs/common";
import { VersionService } from "./version.service";
import { ApiTags } from "@nestjs/swagger";
import { PublicApi } from "../../common/decorators/authentication-decorators";

@ApiTags("Version")
@Controller("version")
@PublicApi()
export class VersionController {
    constructor(readonly versionService: VersionService) {}

    @Get()
    async getVersion() {
        const version = this.versionService.getVersion();
        return {
            ts: new Date().toISOString(),
            version
        };
    }
}
