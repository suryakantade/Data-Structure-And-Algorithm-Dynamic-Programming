let appRoot = require("app-root-path");
import { Injectable } from "@nestjs/common";
import { InternalServer } from "../../common/error/InternalServer";

const packagePath = `${appRoot.path}/package.json`;
const packageData = require(`${packagePath}`);

@Injectable()
export class VersionService {
    private readonly version: string;

    constructor() {
        const { version } = packageData;
        if (!version) {
            throw new InternalServer("No version provided!");
        }
        this.version = version;
    }

    getVersion() {
        return this.version;
    }
}
