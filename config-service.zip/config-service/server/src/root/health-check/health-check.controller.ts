import { Controller, Get, Inject } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { HealthCheckService } from "./health-check.service";
import { Constants } from "../../utils/constants";
import { DataBase } from "../../lib/database/database.service";
import { PublicApi } from "../../common/decorators/authentication-decorators";

@ApiTags("Health Check")
@Controller("/health")
@PublicApi()
export class HealthCheckController {
    constructor(
        private readonly healthCheckService: HealthCheckService,
        @Inject(Constants.DATABASE_SERVICE_TOKEN) private readonly db: DataBase
    ) {}

    @Get()
    async healthCheck() {
        return this.healthCheckService.healthCheck();
    }

    @Get("/db")
    async healthCheckDb() {
        return this.healthCheckService.healthCheckDb();
    }
}
