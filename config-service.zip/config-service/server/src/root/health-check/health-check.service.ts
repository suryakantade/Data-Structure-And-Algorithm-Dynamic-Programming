import { Inject, Injectable } from "@nestjs/common";
import { Constants } from "../../utils/constants";
import { DataBase } from "../../lib/database/database.service";

@Injectable()
export class HealthCheckService {
    constructor(@Inject(Constants.DATABASE_SERVICE_TOKEN) private readonly db: DataBase) {}

    async healthCheck() {
        return { now: Date.now() };
    }

    async healthCheckDb() {
        const {
            rows: [data]
        } = await this.db.raw("SELECT now()");
        return data;
    }
}
