import { Module } from "@nestjs/common";
import { VersionModule } from "./version/version.module";
import { HealthCheckModule } from "./health-check/health-check.module";

@Module({
    imports: [VersionModule, HealthCheckModule]
})
export class RootModule {}
