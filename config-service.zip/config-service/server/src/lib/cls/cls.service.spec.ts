import { Test, TestingModule } from "@nestjs/testing";
import { ClsService } from "./cls.service";

describe("ClsService", () => {
    let service: ClsService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [ClsService]
        }).compile();

        service = module.get<ClsService>(ClsService);
    });

    it("should be defined", () => {
        expect(service).toBeDefined();
    });
});
