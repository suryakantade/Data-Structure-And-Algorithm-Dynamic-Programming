import { Injectable } from "@nestjs/common";
import * as cls from "cls-hooked";
import { Constants } from "../../utils/constants";

@Injectable()
export class ClsService {
    defaultNamespace: cls.Namespace;

    constructor() {
        this.defaultNamespace = this.createNamespace(Constants.CLS_NAMESPACE);
    }

    private createNamespace(name: string) {
        return cls.createNamespace(name);
    }

    setContext<T>(key: string, value: T) {
        return this.defaultNamespace.set(key, value);
    }

    getContext<T>(key: string): T {
        return this.defaultNamespace.get(key) as T;
    }

    run<T>(fn: (...args) => T) {
        return this.defaultNamespace.run(fn);
    }
}
