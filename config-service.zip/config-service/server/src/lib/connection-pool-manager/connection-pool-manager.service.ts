import { Injectable, Inject } from "@nestjs/common";
import { DataBase } from "../database/database.service";
import { Constants } from "../../utils/constants";
import { Helper } from "../../utils/helper";
import { Environment } from "../../utils/types/types";
import { Pool } from "tarn";
import { Resource } from "tarn/dist/Resource";
import { LogService } from "@khatabook/nestjs-logger";
import { InternalConfigService } from "../internal-config/internal-config.service";

export interface Connection {
    _queryable: boolean;
    __knex__disposed: string;
    processID: string;
}

@Injectable()
export class ConnectionPoolManagerService {
    private pool: Pool<Connection> & {
        used: Resource<Connection>[];
        free: Resource<Connection>[];
        min: number;
        max: number;
    };
    private cleanUpIntervalMillis = 2000;

    constructor(
        @Inject(Constants.DATABASE_SERVICE_TOKEN) readonly db: DataBase,
        readonly internalConfigService: InternalConfigService,
        readonly log: LogService
    ) {
        log.setContext(ConnectionPoolManagerService.name);
        this.pool = this.db.client.pool;
        const configuredCleanUpIntervalMillis = this.internalConfigService.getDbConnectionPoolCleanUpIntervalMillis();
        if (configuredCleanUpIntervalMillis) {
            this.cleanUpIntervalMillis = configuredCleanUpIntervalMillis;
        }

        setInterval(async () => {
            await this.purgeInvalidConnections();
        }, this.cleanUpIntervalMillis);

        if (Helper.getEnvironment() === Environment.PRODUCTION) {
            setInterval(() => {
                this.logPoolState();
            }, 5000);
        }
    }

    getUsedResources() {
        return this.pool.used.map((poolMember) => poolMember.resource);
    }

    getFreeResources() {
        return this.pool.free.map((poolMember) => poolMember.resource);
    }

    async purgeInvalidConnections() {
        for (const resource of this.getUsedResources()) {
            const isResourceValid = await this.pool._validateResource(resource);
            if (!isResourceValid) {
                this.log.debug(
                    {
                        data: {
                            pid: resource.processID
                        }
                    },
                    "POOL_RELEASING_RESOURCE"
                );
                await this.db.client.releaseConnection(resource);
            }
        }
    }

    logPoolState() {
        const usedResources = this.getUsedResources().map((resource) => ({
            processId: resource.processID,
            queryable: resource._queryable,
            possibleError: resource.__knex__disposed
        }));
        const freeResources = this.getFreeResources().map((resource) => ({
            processId: resource.processID,
            queryable: resource._queryable,
            possibleError: resource.__knex__disposed
        }));

        this.log.debug(
            {
                data: {
                    usedCount: usedResources.length,
                    freeCount: freeResources.length,
                    used: JSON.stringify(usedResources),
                    free: JSON.stringify(freeResources),
                    min: this.pool.min,
                    max: this.pool.max
                }
            },
            "POOL_STATE_CAPTURED"
        );
    }
}
