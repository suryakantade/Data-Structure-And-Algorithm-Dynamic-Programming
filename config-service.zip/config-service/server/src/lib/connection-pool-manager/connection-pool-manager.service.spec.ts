import { Test, TestingModule } from "@nestjs/testing";
import { ConnectionPoolManagerService } from "./connection-pool-manager.service";

describe("ConnectionPoolManagerService", () => {
    let service: ConnectionPoolManagerService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [ConnectionPoolManagerService]
        }).compile();

        service = module.get<ConnectionPoolManagerService>(ConnectionPoolManagerService);
    });

    it("should be defined", () => {
        expect(service).toBeDefined();
    });
});
