import { Module } from "@nestjs/common";
import { ConnectionPoolManagerService } from "./connection-pool-manager.service";

@Module({
    providers: [ConnectionPoolManagerService]
})
export class ConnectionPoolManagerModule {}
