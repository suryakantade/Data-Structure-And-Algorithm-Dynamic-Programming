import { Injectable } from '@nestjs/common';

import * as AWS from 'aws-sdk';

@Injectable()
export class S3Service {
    private s3: AWS.S3;

    constructor() {
        this.s3 = new AWS.S3();
    }

    async upload(key: string, bucket: string, content: Buffer) {
        const params = {
            Key: key,
            Bucket: bucket,
            Body: content,
        };

        return await this.s3.upload(params).promise();
    }

    async getObject(key: string, bucket: string) {
        const params = {
            Key: key,
            Bucket: bucket,
        };

        return await this.s3.getObject(params).promise();
    }
}
