import { Module } from "@nestjs/common";
import { DatabaseModule } from "./database/database.module";
import { EventModule } from "./event/event.module";
import { NetworkModule } from "./network/network.module";
import { ClsModule } from "./cls/cls.module";
import { ConnectionPoolManagerModule } from "./connection-pool-manager/connection-pool-manager.module";
import { InternalConfigModule } from "./internal-config/internal-config.module";
import { S3Module } from "./s3/s3.module";

@Module({
    imports: [
        InternalConfigModule,
        DatabaseModule,
        EventModule,
        NetworkModule,
        ClsModule,
        ConnectionPoolManagerModule,
        S3Module
    ]
})
export class LibModule {}
