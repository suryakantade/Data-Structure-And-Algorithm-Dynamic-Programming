import { knex, Knex } from "knex";
import { Constants } from "../../utils/constants";
import { InternalConfigService } from "../internal-config/internal-config.service";
import * as pg from "pg";

// IMP: By default, pg client returns postgres NUMERIC value as javascript string,
// here were are telling pg to convert NUMERIC to float (javascript number)
// reference: https://github.com/brianc/node-pg-types
pg.types.setTypeParser(pg.types.builtins.NUMERIC, Number.parseFloat);

/* tslint:disable */
export const DatabaseService = {
    provide: Constants.DATABASE_SERVICE_TOKEN,
    useFactory: async (internalConfigService: InternalConfigService) => {
        const client = knex({
            client: "pg",
            connection: internalConfigService.getPgOptions().connection,
            pool: internalConfigService.getPgOptions().pool || Constants.PG_DB_POOL,
            acquireConnectionTimeout:
                internalConfigService.getPgOptions().acquireConnectionTimeout ||
                Constants.PG_DB_ACQUIRE_CONNECTION_TIMEOUT_IN_MILLIS
        }) as DataBase;

        return client;
    },
    inject: [InternalConfigService]
};

export type DataBase = Knex<any, unknown[]>;
