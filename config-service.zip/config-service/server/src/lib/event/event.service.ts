import { Injectable } from "@nestjs/common";
import * as EventEmitter from "events";

export enum EventServiceEvents {
    PAYMENT_LINK_GENERATED = "PAYMENT_LINK_GENERATED",
    PAYMENT_LINK_GENERATION_FAILED = "PAYMENT_LINK_GENERATION_FAILED",
    PAYMENT_SUCCESSFUL = "PAYMENT_SUCCESSFUL",

    PAYOUT_CREATED = "PAYOUT_CREATED",
    PAYOUT_INITIATED = "PAYOUT_INITIATED",
    PAYOUT_INITIATION_FAILED = "PAYOUT_INITIATION_FAILED",
    PAYOUT_SUCCESSFUL = "PAYOUT_SUCCESSFUL",
    PAYOUT_BLOCKED = "PAYOUT_BLOCKED",
    PAYOUT_FAILED = "PAYOUT_FAILED",

    BANK_ACCOUNT_ADDITION_FAILED = "BANK_ACCOUNT_ADDITION_FAILED",
    BANK_ACCOUNT_ADDED = "BANK_ACCOUNT_ADDED",
    BLACKLISTED_BANK_ADD_ATTEMPT = "BLACKLISTED_BANK_ADD_ATTEMPT",

    QR_TXN_SUCCESSFUL = "QR_TXN_SUCCESSFUL",
    QR_ENTRIES_ADDED = "QR_ENTRIES_ADDED",

    IPC = "IPC",

    GET_SCHEDULED_JOBS = "GET_SCHEDULED_JOBS",
    GET_JOB_STATUS = "GET_JOB_STATUS",
    STOP_JOB = "STOP_JOB",
    RESTART_JOB = "RESTART_JOB",
    RUN_JOB = "RUN_JOB",

    APP_STARTED = "APP_STARTED"
}

@Injectable()
export class EventService {
    private emitter: EventEmitter;
    static events = EventServiceEvents;

    constructor() {
        this.emitter = new EventEmitter();
    }

    on<T>(event: EventServiceEvents, fn: (...args) => T) {
        this.emitter.on(event, fn);
    }

    emit(event: EventServiceEvents, ...args) {
        this.emitter.emit(event, ...args);
    }
}
