import { Module, Global, DynamicModule } from "@nestjs/common";
import { Constants } from "../../utils/constants";
import { InternalConfigService } from "./internal-config.service";

@Global()
@Module({
    providers: [InternalConfigService],
    exports: [InternalConfigService]
})
export class InternalConfigModule {
    static register(config): DynamicModule {
        return {
            module: InternalConfigModule,
            providers: [
                {
                    provide: Constants.CONFIG_TOKEN,
                    useValue: config
                },
                InternalConfigService
            ],
            exports: [InternalConfigService]
        };
    }
}
