import { Inject, Injectable, Optional } from "@nestjs/common";
import { Constants } from "../../utils/constants";
import { IsNumber, IsObject, IsOptional, IsString, IsUUID, ValidateNested, IsInt, IsDefined } from "class-validator";
import { Type } from "class-transformer";
import { Helper } from "../../utils/helper";

const appPath = require("app-root-path").path;

const defaultConfigPath = `${appPath}/server/config.json`;
// This contains path to test config file that is generated dynamically during tests.
// This environment variable will only be present when running tests, in all other cases
// config file will be picked up from defaultConfigPath
const testConfigPath = process.env.CONFIG_PATH;

export const defaultInternalConfig = require(testConfigPath || defaultConfigPath);

class DatabaseConnection {
    @IsString()
    host: string;

    @IsNumber()
    port: number;

    @IsString()
    user: string;

    @IsString()
    password: string;

    @IsString()
    database: string;
}

class DatabasePool {
    @IsNumber()
    min: number;

    @IsNumber()
    max: number;
}

class DatabaseConfig {
    @IsObject()
    @ValidateNested()
    @Type(() => DatabaseConnection)
    connection: DatabaseConnection;

    @IsObject()
    @ValidateNested()
    @Type(() => DatabasePool)
    pool: DatabasePool;

    @IsNumber()
    @IsOptional()
    acquireConnectionTimeout?: number;
}

class NewRelicConfig {
    @IsString()
    appName: string;

    @IsString()
    licenseKey: string;
}

class ClientAnalyticsConfig {
    @IsString()
    bucket: string;

    @IsString()
    analyticsPath: string;

    @IsInt()
    refreshInterval: number;
}

class CacheConfig {
    @IsNumber()
    hashRefreshIntervalMs: number;
}

class IntraAuthConfig {
    @IsUUID()
    token: string;
}

class InternalConfigSchema {
    @IsString()
    host: string;

    @IsString()
    path: string;

    @IsNumber()
    port: number;

    @IsObject()
    @ValidateNested()
    @Type(() => DatabaseConfig)
    pgOptions: DatabaseConfig;

    @IsNumber()
    @IsOptional()
    dbConnectionPoolCleanUpIntervalMillis?: number;

    @IsObject()
    @ValidateNested()
    @Type(() => NewRelicConfig)
    newRelic: NewRelicConfig;

    @IsDefined()
    @Type(() => ClientAnalyticsConfig)
    @IsObject()
    @ValidateNested({ each: true })
    clientAnalyticsConfig: ClientAnalyticsConfig;

    @IsObject()
    @ValidateNested()
    @Type(() => CacheConfig)
    cacheConfig: CacheConfig;

    @IsObject()
    @ValidateNested()
    @Type(() => IntraAuthConfig)
    intraAuthConfig: IntraAuthConfig;
}

@Injectable()
export class InternalConfigService {
    private config: InternalConfigSchema;

    constructor(
        @Optional()
        @Inject(Constants.CONFIG_TOKEN)
        config: InternalConfigSchema = defaultInternalConfig
    ) {
        this.config = this.validateConfig(config);
    }

    validateConfig(config: InternalConfigSchema): InternalConfigSchema {
        const { object, errors } = Helper.validateClassSync(InternalConfigSchema, config);
        if (errors.length !== 0) {
            throw new Error(`Config validation error: ${errors}`);
        }
        return object;
    }

    getPgOptions(): DatabaseConfig {
        return this.config.pgOptions;
    }

    getDbConnectionPoolCleanUpIntervalMillis(): number | undefined {
        return this.config.dbConnectionPoolCleanUpIntervalMillis;
    }

    getClientAnalyticsConfig() {
        return this.config.clientAnalyticsConfig;
    }

    getCacheConfig(): CacheConfig {
        return this.config.cacheConfig;
    }

    getIntraAuthConfig(): IntraAuthConfig {
        return this.config.intraAuthConfig;
    }
}
