import { Injectable } from "@nestjs/common";
import * as request from "request-promise";

import { Helper } from "../../utils/helper";
import { LogService } from "@khatabook/nestjs-logger";

@Injectable()
export class NetworkService {
    constructor(readonly log: LogService) {
        log.setContext(NetworkService.name);
    }

    async get<T>(url: string, headers?: Object, params?: Object, options?: Object): Promise<T> {
        this.log.debug(`INSTRUMENT_START:NETWORK_GET ${url}`);
        const result = await request.get(url, {
            headers,
            qs: params,
            json: true,
            ...options
        });
        this.log.debug(`INSTRUMENT_END:NETWORK_GET ${url}`);
        return result as T;
    }

    async post<T>(
        url: string,
        headers: Object,
        params: { [key in "body" | "formData" | "form"]?: Object },
        options?: Object
    ) {
        this.log.debug(`INSTRUMENT_START:NETWORK_POST ${url}`);
        if (params.formData) {
            Helper.deleteAllUndefined(params.formData);
        }

        const result = await request.post(url, {
            headers,
            ...params,
            json: true,
            ...options
        });
        this.log.debug(`INSTRUMENT_END:NETWORK_POST ${url}`);
        return result as T;
    }
}
