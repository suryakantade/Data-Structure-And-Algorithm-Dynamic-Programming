export enum Platform {
    ANDROID = "android",
    IOS = "ios"
}
