export class PlatformInfo {
    // keeping optional because inter-service API calls might not contain platform information
    platform?: string;
    appVersion?: number;
}
