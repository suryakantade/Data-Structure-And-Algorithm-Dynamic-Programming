export enum Tenant {
    KHATABOOK = "KHATABOOK"
}
