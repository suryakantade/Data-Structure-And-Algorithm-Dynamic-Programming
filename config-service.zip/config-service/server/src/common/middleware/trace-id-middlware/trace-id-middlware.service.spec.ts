import { Test, TestingModule } from "@nestjs/testing";
import { TraceIdMiddlwareService } from "./trace-id-middlware.service";

describe("TraceIdMiddlwareService", () => {
    let service: TraceIdMiddlwareService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [TraceIdMiddlwareService]
        }).compile();

        service = module.get<TraceIdMiddlwareService>(TraceIdMiddlwareService);
    });

    it("should be defined", () => {
        expect(service).toBeDefined();
    });
});
