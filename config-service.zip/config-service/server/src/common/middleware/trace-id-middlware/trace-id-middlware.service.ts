import { Injectable } from "@nestjs/common";
import * as express from "express";
import { ClsService } from "../../../lib/cls/cls.service";
import { Constants } from "../../../utils/constants";
import { Helper } from "../../../utils/helper";

@Injectable()
export class TraceIdMiddlwareService {
    constructor(readonly cls: ClsService) {}

    use(req: express.Request, res: express.Response, next: () => void) {
        this.cls.defaultNamespace.bindEmitter(req);
        this.cls.defaultNamespace.bindEmitter(res);

        this.cls.defaultNamespace.run(() => {
            const traceId = req.headers[Constants.TRACE_ID] || Helper.getUUID();
            this.cls.setContext(Constants.TRACE_ID, traceId);
            next();
        });
    }
}
