import { Module, Global } from "@nestjs/common";
import { TraceIdMiddlwareService } from "./trace-id-middlware/trace-id-middlware.service";
import { LibModule } from "../../lib/lib.module";

@Global()
@Module({
    imports: [LibModule],
    providers: [TraceIdMiddlwareService]
})
export class MiddlewareModule {}
