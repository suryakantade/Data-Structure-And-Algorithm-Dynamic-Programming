import { BaseError } from "./BaseError";
import { ErrorCode } from "../error-codes";

export class WrongAuthentication extends BaseError {
    public message: string;
    httpStatusCode = 401;
    constructor(message: string, readonly errorCode?: ErrorCode) {
        super(message);
    }
}
