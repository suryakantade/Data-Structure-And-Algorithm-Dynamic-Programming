import { BaseError } from "./BaseError";
import { ErrorCode } from "../error-codes";

export class InternalServer extends BaseError {
    public message: string;
    public stack?: string;
    constructor(message: string, stack?: string, readonly errorCode?: ErrorCode) {
        super(message);
        if (stack) {
            this.stack = stack.toString();
        }
    }
}
