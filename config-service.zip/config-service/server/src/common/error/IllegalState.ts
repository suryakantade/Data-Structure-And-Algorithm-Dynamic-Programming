import { BaseError } from "./BaseError";
import { ErrorCode } from "../error-codes";

export class IllegalState extends BaseError {
    public message: string;
    httpStatusCode = 500;

    constructor(message: string) {
        super(message, ErrorCode.ILLEGAL_STATE);
    }
}
