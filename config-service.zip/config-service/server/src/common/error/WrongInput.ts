import { BaseError } from "./BaseError";
import { ErrorCode } from "../error-codes";

export class WrongInput extends BaseError {
    public message: string;
    httpStatusCode = 400;

    constructor(message: string, readonly errorCode?: ErrorCode) {
        super(message, errorCode);
    }
}
