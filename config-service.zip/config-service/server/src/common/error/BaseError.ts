import { ErrorCode } from "../error-codes";
import { Helper } from "../../utils/helper";
import { Environment } from "../../utils/types/types";

export class BaseError extends Error {
    public errorCode?: ErrorCode = ErrorCode.UNEXPECTED_ERROR;
    // public context = {};
    public httpStatusCode = 500;

    // whether or not to send this to sentry. use in global exception filter
    // public captureInSentry = true;

    constructor(message: string, errorCode?: ErrorCode) {
        super();
        this.message = message;
        this.errorCode = errorCode;
    }

    // addContext(ctx: Object) {
    //     this.context = Object.assign(this.context, ctx);
    //     return this;
    // }

    set<T extends keyof this>(key: T, value: this[T]) {
        this[key] = value;
        return this;
    }

    getExtraDetailsStrippedError() {
        // tslint:disable-next-line: no-this-assignment
        const { httpStatusCode, ...toSend } = this;
        if (Helper.getEnvironment() === Environment.PRODUCTION) {
            toSend.stack = undefined;
        } else {
            toSend.stack = this.stack;
        }
        return toSend;
    }
}
