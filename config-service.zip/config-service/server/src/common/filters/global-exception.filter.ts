import { ArgumentsHost, Catch, ExceptionFilter, HttpStatus, HttpException } from "@nestjs/common";
import { BaseError } from "../error/BaseError";
import { InternalServer } from "../error/InternalServer";
import { ErrorCode } from "../error-codes";
import { LogService } from "@khatabook/nestjs-logger";

@Catch(HttpException, Error)
export class GlobalExceptionFilter implements ExceptionFilter {
    constructor(readonly log: LogService) {
        log.setContext(GlobalExceptionFilter.name);
    }

    catch(exception, host: ArgumentsHost) {
        const ctx = host.switchToHttp();
        const res = ctx.getResponse();
        this.log.error({ err: exception });
        if (exception instanceof BaseError) {
            const status = exception.httpStatusCode;
            res.status(status).json(exception.getExtraDetailsStrippedError());
        } else if (exception instanceof Error) {
            if ((exception as Error & { status }).status) {
                return res.status((exception as Error & { status }).status).json({
                    ...(exception as Error & { response }).response
                });
            }

            const internalServerError = new InternalServer(exception.message, exception.stack).set(
                "errorCode",
                ErrorCode.UNEXPECTED_ERROR
            );

            res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(internalServerError.getExtraDetailsStrippedError());
        }
    }
}
