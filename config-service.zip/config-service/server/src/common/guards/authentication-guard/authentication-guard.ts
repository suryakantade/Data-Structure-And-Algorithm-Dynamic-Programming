import { CanActivate, ExecutionContext, Injectable } from "@nestjs/common";
import { Observable } from "rxjs";
import { Reflector } from "@nestjs/core";
import { InternalServer } from "../../error/InternalServer";
import { InternalConfigService } from "../../../lib/internal-config/internal-config.service";
import { getApiTokenFromHeaders } from "../../../utils/api-header.util";
import { WrongAuthentication } from "../../error/WrongAuthentication";
import { Request } from "express";

export enum ApiType {
    INTRA = "INTRA",
    PUBLIC = "PUBLIC"
}

@Injectable()
export class AuthenticationGuard implements CanActivate {
    constructor(private reflector: Reflector, private readonly internalConfigService: InternalConfigService) {}

    canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        // check apiType at route level
        const routeApiType = this.reflector.get<ApiType>("apiType", context.getHandler());
        // check apiType at controller level
        const controllerApiType = this.reflector.get<ApiType>("apiType", context.getClass());
        // give priority to route level decorator
        const apiType = routeApiType || controllerApiType;
        if (!apiType) {
            throw new InternalServer("API type not passed to authentication guard");
        }
        const request = context.switchToHttp().getRequest();
        switch (apiType) {
            case ApiType.INTRA:
                return this.authenticateIntraApiRequest(request);
            case ApiType.PUBLIC:
                return true;
            default:
                return false;
        }
    }

    private authenticateIntraApiRequest(request: Request): boolean {
        const apiToken = getApiTokenFromHeaders(request);
        const expectedToken = this.internalConfigService.getIntraAuthConfig().token;

        if (!apiToken) {
            throw new WrongAuthentication("API token missing in request");
        }

        if (apiToken !== expectedToken) {
            throw new WrongAuthentication("Incorrect API token passed in request");
        }
        return true;
    }
}
