import { ExecutionContext, Injectable, NestInterceptor, CallHandler } from "@nestjs/common";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Success } from "../dto/Success";

@Injectable()
export class GlobalResponseInterceptor<T> implements NestInterceptor {
    intercept(context: ExecutionContext, next: CallHandler<T>): Observable<Success<T>> {
        return next.handle().pipe(map((data) => new Success(data)));
    }
}
