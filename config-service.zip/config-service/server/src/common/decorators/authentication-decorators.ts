import { applyDecorators, SetMetadata, UseGuards } from "@nestjs/common";
import { ApiType, AuthenticationGuard } from "../guards/authentication-guard/authentication-guard";
import { ApiHeaders } from "@nestjs/swagger";
import { Constants } from "../../utils/constants";

export function IntraApi() {
    return applyDecorators(
        ApiHeaders([
            {
                name: Constants.HEADERS.X_API_TOKEN,
                required: true
            }
        ]),
        SetMetadata("apiType", ApiType.INTRA),
        UseGuards(AuthenticationGuard)
    );
}

export function PublicApi() {
    return applyDecorators(SetMetadata("apiType", ApiType.PUBLIC), UseGuards(AuthenticationGuard));
}
