export class Success<T> {
    constructor(data: Object | T[]) {
        return data;
    }
}
