import { Module, NestModule, MiddlewareConsumer, OnApplicationBootstrap } from "@nestjs/common";
import { MainModule } from "./main.module";
import { RootModule } from "./root/root.module";
import { EventService, EventServiceEvents } from "./lib/event/event.service";
import { Constants } from "./utils/constants";
import { TraceIdMiddlwareService } from "./common/middleware/trace-id-middlware/trace-id-middlware.service";
import * as cls from "cls-hooked";
import { LogModule } from "@khatabook/nestjs-logger";
import { APP_FILTER } from "@nestjs/core";
import { GlobalExceptionFilter } from "./common/filters/global-exception.filter";
import { ScheduleModule } from "@nestjs/schedule";

@Module({
    imports: [
        RootModule,
        MainModule,
        ScheduleModule.forRoot(),
        LogModule.forRoot({
            cls,
            clsNamespace: Constants.CLS_NAMESPACE,
            traceIdKey: Constants.TRACE_ID,
            httpRequestLogLevel: "debug",
            keysToStringify: ["err", "data"],
            minimumLogLevel: "trace",
            logRequestParams: true
        })
    ],
    providers: [
        {
            provide: APP_FILTER,
            useClass: GlobalExceptionFilter
        }
    ]
})
export class AppModule implements NestModule, OnApplicationBootstrap {
    constructor(readonly eventService: EventService) {}

    onApplicationBootstrap() {
        this.eventService.emit(EventServiceEvents.APP_STARTED);
        if (process.send) {
            process.send(Constants.PROCESS_READY);
        }
    }

    configure(consumer: MiddlewareConsumer) {
        consumer.apply(TraceIdMiddlwareService).forRoutes("*");
    }
}
