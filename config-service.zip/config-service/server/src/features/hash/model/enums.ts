export enum HashEntityType {
    CONFIG = "config",
    ROLLOUT = "rollout"
    // SEGMENT = "segment",
    // EXPERIMENT = "experiment"
}

export enum HashUpdateReferenceType {
    CONFIG_NAME = "config_name",
    CONFIG_ID = "config_id"
    // SEGMENT_ID = "segment_id",
    // EXPERIMENT_ID = "experiment_id"
}
