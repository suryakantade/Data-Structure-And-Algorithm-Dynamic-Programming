export class HashPullResponseItemDto {
    /**
     * Name of the config
     * @example CASHBOOK_HOME_SCREEN
     */
    config_name: string;

    /**
     * Current hash of the config
     * @example 23152de7-d047-4a73-bdc2-893949b175fa#1649652262312
     */
    config_hash: string;
}

export class HashPullResponseDto {
    /**
     * Flag for pagination support, currently there is no support for pagination so it will always be false
     * @example false
     */
    has_more: boolean; // pagination not supported as of now

    /**
     * Response items containing config name and corresponding hash
     */
    items: HashPullResponseItemDto[];
}
