import { IsEnum, IsOptional, IsString } from "class-validator";
import { ConfigEntityType } from "../../config/model/enums";

export class HashPullRequestParamsDto {
    /**
     * Entity type of configs for which hash needs to be fetched
     * @example DEFAULT
     */
    @IsEnum(ConfigEntityType)
    @IsOptional()
    entity_type?: ConfigEntityType;

    /**
     * Config name for which hash needs to be fetched
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    @IsOptional()
    config_name?: string;
}
