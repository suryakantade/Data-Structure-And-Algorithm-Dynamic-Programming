import { HashEntityType } from "../model/enums";
import { IsEnum } from "class-validator";

export class UpdateHashRouteParamsDto {
    /**
     * Identifier for downstream entity(Config/Rollout/Segment/Experiment) that got updated
     * @example ROLLOUT
     */
    @IsEnum(HashEntityType)
    hash_entity_type: HashEntityType;
}
