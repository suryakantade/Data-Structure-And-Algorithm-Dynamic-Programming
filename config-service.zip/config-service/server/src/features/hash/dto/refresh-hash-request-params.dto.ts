import { IsString } from "class-validator";

export class RefreshHashRequestParamsDto {
    /**
     * Config name
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    config_name: string;
}
