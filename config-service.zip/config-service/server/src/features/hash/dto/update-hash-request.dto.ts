import { IsEnum, IsString } from "class-validator";
import { HashUpdateReferenceType } from "../model/enums";

export class UpdateHashRequestDto {
    /**
     * Whenever a downstream component(Config/Rollout/Segment/Experiment) is updated then it should send an ID that can be used to deduce the configs that are affected due to that component update
     * @example 53b75e37-7372-46eb-9dc0-126a8dcd6c7f
     */
    @IsString()
    reference_id: string;

    /**
     * Tells the type of reference_id
     * @example CONFIG_ID
     */
    @IsEnum(HashUpdateReferenceType)
    reference_id_type: HashUpdateReferenceType;
}
