import { HashEntityType, HashUpdateReferenceType } from "./model/enums";

export class HashHelper {
    static HASH_ENTITY_TYPE_TO_REFERENCE_TYPE_MAPPING: Record<HashEntityType, HashUpdateReferenceType> = {
        [HashEntityType.CONFIG]: HashUpdateReferenceType.CONFIG_NAME,
        [HashEntityType.ROLLOUT]: HashUpdateReferenceType.CONFIG_ID
    };
}
