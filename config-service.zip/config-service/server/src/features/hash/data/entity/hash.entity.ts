export class HashEntity {
    config_name: string;
    hash: string;
}
