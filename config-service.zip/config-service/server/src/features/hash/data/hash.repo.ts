import { Inject, Injectable, OnModuleInit } from "@nestjs/common";
import { Constants } from "../../../utils/constants";
import { DataBase } from "../../../lib/database/database.service";
import { HashEntity } from "./entity/hash.entity";
import { LogService } from "@khatabook/nestjs-logger";
import { InternalConfigService } from "../../../lib/internal-config/internal-config.service";
import { SchedulerRegistry } from "@nestjs/schedule";
import { EventService, EventServiceEvents } from "../../../lib/event/event.service";

@Injectable()
export class HashRepo implements OnModuleInit {
    private readonly TABLE_NAME = "hash";
    private readonly UPSERT_CONFLICT_COLUMNS = ["config_name"];
    private readonly HASH_LOADER_INTERVAL_NAME = "CONFIG_HASH_LOADER";
    private hashCache: Record<string, string | undefined> = {};

    constructor(
        @Inject(Constants.DATABASE_SERVICE_TOKEN)
        private readonly db: DataBase,
        private readonly log: LogService,
        private readonly internalConfigService: InternalConfigService,
        private readonly schedulerRegistry: SchedulerRegistry,
        private readonly eventService: EventService
    ) {
        log.setContext(HashRepo.name);
        // This is needed to ensure that hashes are loaded before application starts
        // this event is emitted inside onApplicationBootstrap method of AppModule
        this.eventService.on(EventServiceEvents.APP_STARTED, this.loadHashes);
    }

    onModuleInit(): any {
        const { hashRefreshIntervalMs } = this.internalConfigService.getCacheConfig();
        const interval = setInterval(this.loadHashes, hashRefreshIntervalMs);
        this.schedulerRegistry.addInterval(this.HASH_LOADER_INTERVAL_NAME, interval);
    }

    async upsertHashes(entities: HashEntity[]): Promise<HashEntity[]> {
        const toInsert = entities.map((e) => ({
            ...e,
            updated_at: new Date().toISOString()
        }));
        return this.db<HashEntity>(this.TABLE_NAME)
            .insert(toInsert)
            .onConflict(this.UPSERT_CONFLICT_COLUMNS)
            .merge()
            .returning("*");
    }

    async getHashes(configNames: string[]): Promise<HashEntity[]> {
        let hashEntities: HashEntity[] = [];
        configNames.forEach((name) => {
            const hash = this.hashCache[name];
            if (hash) {
                hashEntities.push({
                    config_name: name,
                    hash
                });
            }
        });
        return hashEntities;
    }

    loadHashes = async () => {
        try {
            const hashEntities = await this.db<HashEntity>(this.TABLE_NAME).select();
            let configNameToHash: Record<string, string> = {};
            hashEntities.forEach((entity) => {
                configNameToHash[entity.config_name] = entity.hash;
            });
            this.hashCache = configNameToHash;
        } catch (e) {
            // will setup newrelic alert for this event
            this.log.error({ err: e }, "HASH_REFRESH_FAILURE: Error occurred while refreshing hashes from database");
        }
    };
}
