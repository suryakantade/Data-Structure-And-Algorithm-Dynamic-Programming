import { forwardRef, Module } from "@nestjs/common";
import { HashController } from "./hash.controller";
import { HashService } from "./hash.service";
import { RolloutModule } from "../rollout/rollout.module";
import { HashRepo } from "./data/hash.repo";
import { ConfigModule } from "../config/config.module";

@Module({
    controllers: [HashController],
    providers: [HashService, HashRepo],
    imports: [forwardRef(() => RolloutModule), forwardRef(() => ConfigModule)],
    exports: [HashService]
})
export class HashModule {}
