import { forwardRef, Inject, Injectable } from "@nestjs/common";
import { LogService } from "@khatabook/nestjs-logger";
import { UpdateHashRouteParamsDto } from "./dto/update-hash-route-params.dto";
import { UpdateHashRequestDto } from "./dto/update-hash-request.dto";
import { HashEntityType, HashUpdateReferenceType } from "./model/enums";
import { IllegalState } from "../../common/error/IllegalState";
import { HashEntity } from "./data/entity/hash.entity";
import { v4 as uuidv4 } from "uuid";
import { HashRepo } from "./data/hash.repo";
import { RolloutService } from "../rollout/rollout.service";
import { HashPullRequestParamsDto } from "./dto/hash-pull-request-params.dto";
import { Tenant } from "../../common/models/tenant.enum";
import { ConfigService } from "../config/config.service";
import { ConfigStatus } from "../config/model/enums";
import { HashPullResponseDto, HashPullResponseItemDto } from "./dto/hash-pull-response.dto";
import { WrongInput } from "../../common/error/WrongInput";
import * as assert from "assert";
import { HashHelper } from "./hash-helper";

@Injectable()
export class HashService {
    constructor(
        private readonly log: LogService,
        private readonly hashRepo: HashRepo,
        @Inject(forwardRef(() => RolloutService))
        private readonly rolloutService: RolloutService,
        @Inject(forwardRef(() => ConfigService))
        private readonly configService: ConfigService
    ) {
        log.setContext(HashService.name);
    }

    async getHashes(tenant: Tenant, query: HashPullRequestParamsDto): Promise<HashPullResponseDto> {
        const { entity_type, config_name } = query;
        const configs = await this.configService.getConfigs(tenant, undefined, config_name, entity_type);
        const filteredConfigs = configs.filter((c) => c.status === ConfigStatus.LIVE);
        const configNames = filteredConfigs.map((c) => c.name);
        const hashEntities = await this.hashRepo.getHashes(configNames);
        const configNameToHashEntityMap: Record<string, HashEntity> = {};
        hashEntities.forEach((hashEntity) => {
            configNameToHashEntityMap[hashEntity.config_name] = hashEntity;
        });
        const hashResponseItems: HashPullResponseItemDto[] = filteredConfigs.map((config) => {
            return this.getHashPullResponseItemFromDbEntity(configNameToHashEntityMap[config.name]);
        });
        return {
            has_more: false,
            items: hashResponseItems
        };
    }

    async updateHash(params: UpdateHashRouteParamsDto, body: UpdateHashRequestDto): Promise<HashPullResponseItemDto[]> {
        const { hash_entity_type: hashEntityType } = params;
        const { reference_id, reference_id_type } = body;
        let updatedHashes: HashEntity[] = [];
        switch (hashEntityType) {
            case HashEntityType.CONFIG:
                updatedHashes = await this.handleConfigHashUpdate(reference_id, reference_id_type);
                break;
            case HashEntityType.ROLLOUT:
                updatedHashes = await this.handleRolloutHashUpdate(reference_id, reference_id_type);
                break;
            default:
                // Illegal state
                throw new IllegalState(`Incorrect hash entity type ${hashEntityType}`);
        }
        return updatedHashes.map(this.getHashPullResponseItemFromDbEntity);
    }

    async refreshHash(configName: string): Promise<HashPullResponseItemDto> {
        const configs = await this.configService.getConfigs(undefined, undefined, configName);
        if (configs.length === 0) {
            throw new WrongInput(`Config with name ${configName} does not exist`);
        }
        const updatesHashes = await this.recalculateAndUpsertHashes([configName]);
        assert(updatesHashes.length === 1, "Only one hash should have been updated");
        return this.getHashPullResponseItemFromDbEntity(updatesHashes[0]);
    }

    private async handleConfigHashUpdate(
        referenceId: string,
        referenceIdType: HashUpdateReferenceType
    ): Promise<HashEntity[]> {
        this.validateReferenceInHashUpdate(HashEntityType.CONFIG, referenceIdType);
        return this.recalculateAndUpsertHashes([referenceId]);
    }

    private async handleRolloutHashUpdate(
        referenceId: string,
        referenceIdType: HashUpdateReferenceType
    ): Promise<HashEntity[]> {
        this.validateReferenceInHashUpdate(HashEntityType.ROLLOUT, referenceIdType);
        const configName = await this.getConfigNameFromId(referenceId);
        return this.recalculateAndUpsertHashes([configName]);
    }

    private async recalculateAndUpsertHashes(configNames: string[]): Promise<HashEntity[]> {
        const currentTimestamp = new Date().getTime();
        const hashEntities: HashEntity[] = configNames.map((configName) => {
            const newHash = `${uuidv4()}#${currentTimestamp}`;
            return {
                config_name: configName,
                hash: newHash
            };
        });
        return this.hashRepo.upsertHashes(hashEntities);
    }

    private async getConfigNameFromId(configId: string): Promise<string> {
        const configs = await this.configService.getConfigs(undefined, configId);
        if (configs.length === 0) {
            throw new WrongInput(`Config with ID: ${configId} not found`);
        }
        assert(configs.length === 1, "Multiple configs with same ID cannot exist");
        return configs[0].name;
    }

    private validateReferenceInHashUpdate(hashEntityType: HashEntityType, referenceType: HashUpdateReferenceType) {
        const expectedReferenceType = HashHelper.HASH_ENTITY_TYPE_TO_REFERENCE_TYPE_MAPPING[hashEntityType];
        if (expectedReferenceType !== referenceType) {
            throw new WrongInput(`For ${hashEntityType} reference_id_type should be ${expectedReferenceType}`);
        }
    }

    private getHashPullResponseItemFromDbEntity(hashEntity: HashEntity): HashPullResponseItemDto {
        return {
            config_name: hashEntity.config_name,
            config_hash: hashEntity.hash
        };
    }
}
