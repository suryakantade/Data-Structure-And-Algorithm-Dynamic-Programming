import { v4 as uuidv4 } from "uuid";
import { init } from "../helper/hash-baseclass.test.helper";
import { HashEntityType, HashUpdateReferenceType } from "../../model/enums";
import { getHash, refreshHash, updateHash } from "../helper/hash-api.test.helper";
import { DummyHashDb, TestInitDataHash } from "../helper/hash.test.types";
import { ConfigService } from "../../../config/config.service";
import { Tenant } from "../../../../common/models/tenant.enum";
import { ConfigEntityType, ConfigStatus } from "../../../config/model/enums";
import {
    getDummyConfigModel,
    getHeadersForFetchingHash,
    getInvalidHashPullRequestParamsDto,
    getInvalidUpdateHashRequestDto,
    HASH_RESPONSE_ITEM_SCHEMA,
    HASH_SCHEMA
} from "../helper/hash.data.test.helper";
import { HashDbQueryTestHelper } from "../helper/hash-db-query.test.helper";
import { TestUtility } from "../../../../../../tests/common/test.utility";
import { HashRepo } from "../../data/hash.repo";
import { teardownTestApplication } from "../../../../../../tests/common/baseclass.test.helper";

describe("Integration tests for hashing logic, API: /v1/hash", () => {
    let initData: TestInitDataHash;
    let configService: ConfigService;
    let hashRepo: HashRepo;
    let persistedHash: DummyHashDb;

    beforeEach(async () => {
        initData = await init();
        persistedHash = initData.dummyHashDbObject;
        configService = await initData.app.resolve(ConfigService);
        hashRepo = await initData.app.resolve(HashRepo);
        // explicitly load hashes so that they are cached
        await hashRepo.loadHashes();
        jest.spyOn(configService, "getConfigs").mockImplementation(
            async (tenant?: Tenant, configId?: string, configName?: string, entityType?: ConfigEntityType) => {
                return [
                    getDummyConfigModel({ id: configId, name: persistedHash.config_name, status: ConfigStatus.LIVE })
                ];
            }
        );
    }, 50000);

    describe("API: POST /, update or create hash", () => {
        test.each([
            [
                "hash should update when rollout is updated",
                HashEntityType.ROLLOUT,
                HashUpdateReferenceType.CONFIG_ID,
                uuidv4()
            ],
            [
                "hash should update when config is updated",
                HashEntityType.CONFIG,
                HashUpdateReferenceType.CONFIG_NAME,
                HashDbQueryTestHelper.DB_HASH_CONFIG_NAME
            ]
        ])(
            "verify that %s",
            async (_, hashEntityType: HashEntityType, referenceType: HashUpdateReferenceType, referenceId: string) => {
                const body = {
                    reference_id: referenceId,
                    reference_id_type: referenceType
                };
                const response = await updateHash(initData.app, hashEntityType, body);
                expect(response.statusCode).toBe(201);
                TestUtility.joiValidator(HASH_RESPONSE_ITEM_SCHEMA, response.body[0]);
                const newHash = await HashDbQueryTestHelper.getHash(
                    initData.db.databaseClient,
                    initData.dummyHashDbObject.config_name
                );
                expect(newHash.hash).not.toMatch(initData.dummyHashDbObject.hash);
            }
        );

        test("verify that new hash should be created if it is not already present for the config", async () => {
            const newConfigName = "SOME_NEW_CONFIG";
            const body = {
                reference_id: newConfigName,
                reference_id_type: HashUpdateReferenceType.CONFIG_NAME
            };
            const response = await updateHash(initData.app, HashEntityType.CONFIG, body);
            expect(response.statusCode).toBe(201);
            TestUtility.joiValidator(HASH_RESPONSE_ITEM_SCHEMA, response.body[0]);
            expect(response.body[0].config_hash).toBeTruthy();
        });

        test("verify that error should be thrown when body contract is not followed", async () => {
            const response = await updateHash(initData.app, HashEntityType.CONFIG, getInvalidUpdateHashRequestDto());
            expect(response.statusCode).toBe(400);
            expect(response.body.message.length).toBe(2);
        });

        test.each([
            [
                "it should fail if config is updated but config name is not passed",
                HashEntityType.CONFIG,
                HashUpdateReferenceType.CONFIG_ID,
                "reference_id_type should be",
                () => {}
            ],
            [
                "it should fail if rollout is updated but config ID is not passed",
                HashEntityType.ROLLOUT,
                HashUpdateReferenceType.CONFIG_NAME,
                "reference_id_type should be",
                () => {}
            ],
            [
                "it should fail if rollout is updated but config with passed ID is not present",
                HashEntityType.ROLLOUT,
                HashUpdateReferenceType.CONFIG_ID,
                "not found",
                () => {
                    jest.spyOn(configService, "getConfigs").mockResolvedValue([]);
                }
            ]
        ])(
            "verify that %s",
            async (
                _,
                entityType: HashEntityType,
                referenceType: HashUpdateReferenceType,
                expectedMsg: string,
                pretest: () => any
            ) => {
                pretest();
                const body = {
                    reference_id: uuidv4(),
                    reference_id_type: referenceType
                };
                const response = await updateHash(initData.app, entityType, body);
                expect(response.statusCode).toBe(400);
                expect(response.body.message).toMatch(expectedMsg);
            }
        );
    });

    describe("API: GET /, Fetch hashes", () => {
        test.each([
            ["by only tenant", {}, getHeadersForFetchingHash()],
            [
                "by tenant and config_name",
                { config_name: HashDbQueryTestHelper.DB_HASH_CONFIG_NAME },
                getHeadersForFetchingHash()
            ],
            [
                "by tenant and entity_type",
                { entity_type: getDummyConfigModel().entity_type },
                getHeadersForFetchingHash()
            ]
        ])("get hash %s", async (_, params: object, headers: object) => {
            const response = await getHash(initData.app, params, headers);
            expect(response.statusCode).toBe(200);
            TestUtility.joiValidator(HASH_SCHEMA, response.body[0]);
            const expectedResponse = {
                has_more: false,
                items: [
                    {
                        config_name: initData.dummyHashDbObject.config_name,
                        config_hash: initData.dummyHashDbObject.hash
                    }
                ]
            };
            expect(response.body).toMatchObject(expectedResponse);
        });

        test.each([
            [
                "should fail when query params does not follow contract",
                getInvalidHashPullRequestParamsDto(),
                getHeadersForFetchingHash(),
                (response) => expect(response.body.message.length).toBe(2)
            ],
            [
                "should fail when app name header is not passed",
                {},
                {},
                (response) => expect(response.body.message).toMatch("is mandatory")
            ],
            [
                "should fail when incorrect app name is passed",
                {},
                { "x-kb-app-name": "kb" },
                (response) => expect(response.body.message).toMatch("Unable to deduce tenant")
            ]
        ])("verify that it %s", async (_, params: object, headers: object, assertions: (response: any) => void) => {
            const response = await getHash(initData.app, params, headers);
            expect(response.statusCode).toBe(400);
            assertions(response);
        });
    });

    describe("API: PUT /refresh, refresh hash", () => {
        test("should refresh hash if config exists", async () => {
            const response = await refreshHash(initData.app, {
                config_name: initData.dummyHashDbObject.config_name
            });
            expect(response.statusCode).toBe(200);
            TestUtility.joiValidator(HASH_RESPONSE_ITEM_SCHEMA, response.body);
            expect(response.body.config_hash).not.toMatch(initData.dummyHashDbObject.hash);
        });

        test("should throw error if config does not exist", async () => {
            jest.spyOn(configService, "getConfigs").mockResolvedValue([]);
            const response = await refreshHash(initData.app, { config_name: "C1" });
            expect(response.statusCode).toBe(400);
            expect(response.body.message).toMatch("does not exist");
        });
    });

    afterEach(async () => {
        await teardownTestApplication(initData.app, initData.db.databaseClient);
    }, 50000);
});
