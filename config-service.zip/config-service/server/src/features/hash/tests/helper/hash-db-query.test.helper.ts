import { Knex } from "knex";
import { v4 as uuidv4 } from "uuid";
import { DummyHashDb } from "./hash.test.types";

export class HashDbQueryTestHelper {
    static readonly TABLE_NAME = "hash";
    static readonly DB_HASH_CONFIG_NAME = "TEST_HASH_CONFIG";

    static async persistDummyHash(dbClient: Knex): Promise<DummyHashDb> {
        const row = {
            config_name: HashDbQueryTestHelper.DB_HASH_CONFIG_NAME,
            hash: `${uuidv4()}#${new Date().getTime()}`,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        await dbClient(HashDbQueryTestHelper.TABLE_NAME).insert(row);
        return HashDbQueryTestHelper.getHash(dbClient, row.config_name);
    }

    static async getHash(dbClient: Knex, configName: string): Promise<DummyHashDb> {
        const hashes = await dbClient(HashDbQueryTestHelper.TABLE_NAME).select().where({
            config_name: configName
        });
        return hashes[0];
    }
}
