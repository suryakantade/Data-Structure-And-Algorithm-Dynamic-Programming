import { v4 as uuidv4 } from "uuid";
import * as Joi from "joi";
import { Tenant } from "../../../../common/models/tenant.enum";
import { ConfigEntityType, ConfigTargetType } from "../../../config/model/enums";

export const getDummyConfigModel = (overrideFields: any = {}) => {
    return {
        id: uuidv4(),
        name: "DUMMY_CONFIG_MDOEL",
        tenant: Tenant.KHATABOOK,
        entityType: ConfigEntityType.DEFAULT,
        targetType: ConfigTargetType.USER_ID,
        clientMeta: {},
        configValue: {},
        status: {},
        // override passed fields
        ...overrideFields
    };
};

export const getHeadersForFetchingHash = () => {
    return { "x-kb-app-name": "khatabook" };
};

export const getInvalidUpdateHashRequestDto = () => {
    return {
        reference_id: 1234,
        reference_id_type: "Wrong Type"
    };
};

export const getInvalidHashPullRequestParamsDto = () => {
    return {
        entity_type: "abcd",
        config_name: [123, 456]
    };
};

export const HASH_RESPONSE_ITEM_SCHEMA = {
    config_name: Joi.string().required(),
    config_hash: Joi.string().required()
};

export const HASH_SCHEMA = {
    has_more: Joi.boolean().required(),
    items: Joi.array().items(HASH_RESPONSE_ITEM_SCHEMA).required()
};
