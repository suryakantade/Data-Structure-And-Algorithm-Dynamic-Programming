import { INestApplication } from "@nestjs/common";
import { ApiNetworkServiceTestHelper } from "../../../../../../tests/common/api-network-service.test.helper";
import { CommonSetupTestHelper } from "../../../../../../tests/common/common-setup.test.helper";

export async function updateHash(app: INestApplication, hashEntityType: string, body: object) {
    return await ApiNetworkServiceTestHelper.post({
        app: app.getHttpServer(),
        endpoints: `/config-service/v1/hash/${hashEntityType}`,
        body,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}

export async function getHash(app: INestApplication, params: object, headers: object) {
    return await ApiNetworkServiceTestHelper.get({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/hash",
        params,
        headers
    });
}

export async function refreshHash(app: INestApplication, params: object) {
    return await ApiNetworkServiceTestHelper.put({
        app: app.getHttpServer(),
        endpoints: `/config-service/v1/hash/refresh`,
        params,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}
