import { initTestApplication } from "../../../../../../tests/common/baseclass.test.helper";
import { TestInitDataHash } from "./hash.test.types";
import { HashDbQueryTestHelper } from "./hash-db-query.test.helper";

export async function init(): Promise<TestInitDataHash> {
    const testInitData = await initTestApplication();
    const dbClient = testInitData.db.databaseClient;
    const dummyHashDbObject = await HashDbQueryTestHelper.persistDummyHash(dbClient);

    return {
        ...testInitData,
        dummyHashDbObject
    };
}
