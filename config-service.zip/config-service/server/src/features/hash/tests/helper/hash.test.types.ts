import { TestInitData } from "../../../../../../tests/common/types.test.helper";

export interface TestInitDataHash extends TestInitData {
    dummyHashDbObject: DummyHashDb;
}

export interface DummyHashDb {
    config_name: string;
    hash: string;
    created_at: string;
    updated_at: string;
}
