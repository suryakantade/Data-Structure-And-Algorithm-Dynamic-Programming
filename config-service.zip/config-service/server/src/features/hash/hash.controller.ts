import { ApiHeaders, ApiTags } from "@nestjs/swagger";
import { Body, Controller, Get, Param, Post, Put, Query, Req } from "@nestjs/common";
import { HashService } from "./hash.service";
import { UpdateHashRouteParamsDto } from "./dto/update-hash-route-params.dto";
import { UpdateHashRequestDto } from "./dto/update-hash-request.dto";
import { Constants } from "../../utils/constants";
import { HashPullRequestParamsDto } from "./dto/hash-pull-request-params.dto";
import { getTenantFromAppName } from "../../utils/api-header.util";
import { Request } from "express";
import { HashPullResponseDto, HashPullResponseItemDto } from "./dto/hash-pull-response.dto";
import { RefreshHashRequestParamsDto } from "./dto/refresh-hash-request-params.dto";
import { IntraApi, PublicApi } from "../../common/decorators/authentication-decorators";

@ApiTags("APIs for CRUD operations on config hashes")
@Controller({
    path: "hash",
    version: "1"
})
export class HashController {
    constructor(private readonly hashService: HashService) {}

    /**
     * API for fetching hashes for configs
     */
    @Get()
    @ApiHeaders([
        {
            name: Constants.HEADERS.X_KB_APP_NAME,
            required: true
        }
    ])
    @PublicApi()
    getHashes(@Req() req: Request, @Query() query: HashPullRequestParamsDto): Promise<HashPullResponseDto> {
        const tenant = getTenantFromAppName(req);
        return this.hashService.getHashes(tenant, query);
    }

    /**
     * API for force refreshing hash of a particular config (For internal use only)
     */
    @Put("refresh")
    @IntraApi()
    refreshHash(@Query() params: RefreshHashRequestParamsDto): Promise<HashPullResponseItemDto> {
        return this.hashService.refreshHash(params.config_name);
    }

    /**
     * API used by downstream components(Config/Rollout/Segment/Experiment) to publish update so that hash of dependent configs can be updated
     */
    @Post(":hash_entity_type")
    @IntraApi()
    updateHash(
        @Param() params: UpdateHashRouteParamsDto,
        @Body() body: UpdateHashRequestDto
    ): Promise<HashPullResponseItemDto[]> {
        // IMP: avoid doing any processing for this request in controller because config and rollout
        // modules directly calls service method bypassing this controller method
        return this.hashService.updateHash(params, body);
    }
}
