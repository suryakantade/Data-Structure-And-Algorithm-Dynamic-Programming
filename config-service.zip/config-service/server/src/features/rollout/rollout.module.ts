import { forwardRef, Module } from "@nestjs/common";
import { RolloutController } from "./rollout.controller";
import { RolloutService } from "./rollout.service";
import { RolloutRepo } from "./data/rollout.repo";
import { ConfigModule } from "../config/config.module";
import { RolloutValidationService } from "./rollout-validation.service";
import { RolloutEvaluationService } from "./rollout-evaluation.service";
import { HashModule } from "../hash/hash.module";

@Module({
    controllers: [RolloutController],
    providers: [RolloutService, RolloutRepo, RolloutValidationService, RolloutEvaluationService],
    exports: [RolloutEvaluationService, RolloutService],
    imports: [forwardRef(() => ConfigModule), forwardRef(() => HashModule)]
})
export class RolloutModule {}
