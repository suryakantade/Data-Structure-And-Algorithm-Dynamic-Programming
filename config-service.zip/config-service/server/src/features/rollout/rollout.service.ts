import { forwardRef, Inject, Injectable } from "@nestjs/common";
import { RolloutRepo } from "./data/rollout.repo";
import { RolloutInsertDto, RolloutPushDto } from "./dto/rollout-push.dto";
import { RolloutEntity, RolloutUpdateEntity } from "./data/entity/rollout.entity";
import { RolloutValidationService } from "./rollout-validation.service";
import { LogService } from "@khatabook/nestjs-logger";
import { RolloutGetParamsDto } from "./dto/rollout-get.params.dto";
import { WrongInput } from "../../common/error/WrongInput";
import { RolloutPullResponseDto } from "./dto/rollout-pull-response.dto";
import { RolloutColumnName } from "./data/entity/rollout.column";
import { HashEntityType, HashUpdateReferenceType } from "../hash/model/enums";
import { HashService } from "../hash/hash.service";
import * as assert from "assert";
import * as _ from "lodash";
import { v4 as uuidv4 } from "uuid";
import { ConfigService } from "../config/config.service";

@Injectable()
export class RolloutService {
    constructor(
        private readonly rolloutRepo: RolloutRepo,
        private readonly rolloutValidationService: RolloutValidationService,
        private readonly log: LogService,
        @Inject(forwardRef(() => HashService))
        private readonly hashService: HashService,
        @Inject(forwardRef(() => ConfigService))
        private readonly configService: ConfigService
    ) {
        log.setContext(RolloutService.name);
    }

    async pushRollout(insertDto: RolloutInsertDto): Promise<RolloutPullResponseDto> {
        const pushDto: RolloutPushDto = {
            ...insertDto,
            id: uuidv4()
        };
        const rolloutEntity = await this.getRolloutEntityFromDto(pushDto);
        await this.rolloutValidationService.validateRolloutInsert(rolloutEntity);
        // IMP: updating the hash before DB changes because if upsert is done first and hash updation fails then
        // rollout will be updated but its hash will remain same (i.e. incorrect state). In below approach, hash will be updated even if upsert
        // fails, that does not have any implication on correctness of data, just that client might do some redundant API calls.
        await this.updateHash(rolloutEntity.config_id);
        const insertedEntities = await this.rolloutRepo.upsertRollout(rolloutEntity);
        assert(insertedEntities.length === 1, "Exactly one rollout should have been inserted");
        return this.getRolloutResponseDtoFromEntity(insertedEntities[0]);
    }

    async putRollout(pushDto: RolloutPushDto): Promise<RolloutPullResponseDto> {
        const rolloutEntity: RolloutUpdateEntity = await _.omit(
            await this.getRolloutEntityFromDto(pushDto),
            RolloutColumnName.CREATED_AT,
            RolloutColumnName.CREATED_BY
        );

        await this.rolloutValidationService.validateRolloutUpdate(rolloutEntity);
        // IMP: updating the hash before DB changes because if upsert is done first and hash updation fails then
        // rollout will be updated but its hash will remain same (i.e. incorrect state). In below approach, hash will be updated even if upsert
        // fails, that does not have any implication on correctness of data, just that client might do some redundant API calls.
        await this.updateHash(rolloutEntity.config_id);
        const updatedEntities = await this.rolloutRepo.upsertRollout(rolloutEntity);
        assert(updatedEntities.length === 1, "Exactly one rollout should have been updated");
        return this.getRolloutResponseDtoFromEntity(updatedEntities[0]);
    }

    async getRollouts(rolloutGetParamsDto: RolloutGetParamsDto): Promise<RolloutPullResponseDto[]> {
        const { rollout_id, config_name } = rolloutGetParamsDto;
        let configId: string | undefined;

        if (config_name) {
            const configs = await this.configService.getConfigs(undefined, undefined, config_name);
            if (configs.length === 0) {
                throw new WrongInput(`Config with name ${config_name} does not exist`);
            }
            assert(configs.length === 1, "Only one config can exist for a given name");
            configId = configs[0].id;
        }

        let entities: RolloutEntity[] = [];
        if (rollout_id && configId) {
            entities = await this.rolloutRepo.getByRolloutIdAndConfigId(rollout_id, configId);
        } else if (rollout_id) {
            entities = await this.rolloutRepo.getRolloutById(rollout_id);
        } else if (configId) {
            entities = await this.rolloutRepo.getRolloutsByConfigIds([configId]);
        } else {
            throw new WrongInput("Pass at-least one out of rollout_id and config_name");
        }

        let responseDtos: RolloutPullResponseDto[] = [];
        for (const entity of entities) {
            const dto = await this.getRolloutResponseDtoFromEntity(entity);
            responseDtos.push(dto);
        }
        return responseDtos;
    }

    private async getRolloutEntityFromDto(pushDto: RolloutPushDto): Promise<RolloutEntity> {
        const configs = await this.configService.getConfigs(undefined, undefined, pushDto.config_name);
        if (configs.length === 0) {
            throw new WrongInput(`Config with name ${pushDto.config_name} does not exist`);
        }
        assert(configs.length === 1, "More than one config cannot exist for a name");
        const configId = configs[0].id;
        return {
            id: pushDto.id,
            name: pushDto.name,
            config_id: configId,
            rollout_percent: pushDto.rollout_percent,
            // segment_id: pushDto.segment_id,
            // experiment_id: pushDto.experiment_id,
            segment_id: null,
            experiment_id: null,
            status: pushDto.status,
            constraints: pushDto.constraints ?? null,
            created_at: new Date().toISOString(),
            created_by: null,
            updated_at: new Date().toISOString(),
            updated_by: null
        };
    }

    private async getRolloutResponseDtoFromEntity(entity: RolloutEntity): Promise<RolloutPullResponseDto> {
        const configs = await this.configService.getConfigs(undefined, entity.config_id);
        assert(configs.length === 1, "Exactly one config should be present for given name");
        const configName = configs[0].name;
        return {
            id: entity[RolloutColumnName.ID],
            name: entity[RolloutColumnName.NAME],
            config_id: entity[RolloutColumnName.CONFIG_ID],
            config_name: configName,
            rollout_percent: entity[RolloutColumnName.ROLLOUT_PERCENT],
            status: entity[RolloutColumnName.STATUS],
            constraints: entity[RolloutColumnName.CONSTRAINTS] ?? undefined,
            created_at: new Date(entity[RolloutColumnName.CREATED_AT]!).getTime(),
            created_by: entity[RolloutColumnName.CREATED_BY] ?? undefined,
            updated_at: new Date(entity[RolloutColumnName.UPDATED_AT]).getTime(),
            updated_by: entity[RolloutColumnName.UPDATED_BY] ?? undefined
        };
    }

    private async updateHash(configId: string) {
        await this.hashService.updateHash(
            {
                hash_entity_type: HashEntityType.ROLLOUT
            },
            {
                reference_id: configId,
                reference_id_type: HashUpdateReferenceType.CONFIG_ID
            }
        );
    }
}
