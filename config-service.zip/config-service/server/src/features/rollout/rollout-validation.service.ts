import { Injectable } from "@nestjs/common";
import { ConfigService } from "../config/config.service";
import { Config } from "../config/model/config";
import { ConfigStatus, ConfigTargetType } from "../config/model/enums";
import { WrongInput } from "../../common/error/WrongInput";
import { RolloutEntity, RolloutUpdateEntity } from "./data/entity/rollout.entity";
import { ROLLOUT_COLUMNS, RolloutColumnName } from "./data/entity/rollout.column";
import { RolloutRepo } from "./data/rollout.repo";
import * as assert from "assert";
import * as _ from "lodash";
import { RolloutStatus } from "./model/enums";

@Injectable()
export class RolloutValidationService {
    constructor(private readonly configService: ConfigService, private readonly rolloutRepo: RolloutRepo) {}

    async validateRolloutInsert(newRollout: RolloutEntity) {
        const configId = newRollout[RolloutColumnName.CONFIG_ID];
        const rolloutName = newRollout[RolloutColumnName.NAME];
        const existingRollouts = await this.rolloutRepo.getRolloutsByConfigIdAndName(configId, rolloutName);
        if (existingRollouts.length !== 0) {
            throw new WrongInput(`Rollout with name: ${rolloutName} already exists for config ID: ${configId}`);
        }
        await this.validateRolloutCorrectness(newRollout);
    }

    async validateRolloutUpdate(updatedRollout: RolloutUpdateEntity) {
        const rolloutId = updatedRollout[RolloutColumnName.ID];
        const existingRollouts = await this.rolloutRepo.getRolloutById(rolloutId);
        if (existingRollouts.length === 0) {
            throw new WrongInput(`Rollout with ID: ${rolloutId} does not exist`);
        }
        assert(existingRollouts.length === 1, "Multiple rollouts with same ID cannot exist");
        const existingRollout = existingRollouts[0];

        const { status: currentRolloutStatus } = existingRollout;
        Object.entries(ROLLOUT_COLUMNS).forEach(([columnName, columnHelpers]) => {
            if (!(columnName in updatedRollout)) {
                // this column is not getting updated so no need to validate
                return;
            }
            const existingValue = existingRollout[columnName];
            const newValue = updatedRollout[columnName];

            if (!_.isEqual(existingValue, newValue)) {
                const updateEligibility = columnHelpers.canUpdate(
                    currentRolloutStatus,
                    existingRollout,
                    updatedRollout
                );
                if (!updateEligibility.canUpdate) {
                    assert(
                        updateEligibility.failureMessage !== undefined,
                        "Failure message must be passed if update is invalid"
                    );
                    throw new WrongInput(updateEligibility.failureMessage);
                }
            }
        });
        await this.validateRolloutCorrectness(updatedRollout);
    }

    /**
     * 1. if config target type is USER_ID then rollout must have a segment and if it is ANONYMOUS_ID then it must not have a segment
     * 2. If rollout is attached to an experiment then:
     *    2a. experiment target type and config target type should be same
     *    2b. experiment segment and rollout segment should be same, if rollout segment is not present then implicitly pick it from experiment segment
     *    2c. experiment tenant and config tenant should be same
     * 3. If rollout is attached to a segment then that should be a valid segment
     * 4. Config should be live to attach a rollout to it
     * 5. Rollout can only be attached to a live config
     */
    async validateRolloutCorrectness(rolloutEntity: RolloutEntity | RolloutUpdateEntity) {
        const { config_id, status: rolloutStatus } = rolloutEntity;
        const configs = await this.configService.getConfigs(undefined, config_id);
        if (configs.length === 0) {
            throw new WrongInput(`Config with ID: ${config_id} does not exist`);
        }
        assert(configs.length === 1, "More than one config cannot exist for a given ID");
        const config = configs[0];
        if (rolloutStatus === RolloutStatus.LIVE) {
            // critical validations regarding correctness of system state when rollout is made LIVE
            this.validateConfig(config, ConfigStatus.LIVE);
            this.validateSegment(config, rolloutEntity);
        }

        // experiment related validations once AB experiment service is ready
    }

    /**
     * Method to validate config attached to a rollout. expectedConfigStatus should be passed if you want config to have a particular status
     */
    private validateConfig(config: Config, expectedConfigStatus?: ConfigStatus) {
        const { status, name: configName } = config;
        if (expectedConfigStatus && status !== expectedConfigStatus) {
            throw new WrongInput(`Status ${status} of config ${configName} is invalid for this rollout`);
        }
    }

    private validateSegment(config: Config, rolloutEntity: RolloutEntity | RolloutUpdateEntity) {
        const { targetType } = config;
        const { segment_id: segmentId } = rolloutEntity;
        if (targetType === ConfigTargetType.ANONYMOUS_ID && segmentId) {
            throw new WrongInput(
                `Rollout must not be associated with a segment if config is of target type ${ConfigTargetType.ANONYMOUS_ID}`
            );
        }
        if (targetType === ConfigTargetType.USER_ID && !segmentId) {
            throw new WrongInput(
                `Rollout must be associated with a segment if config is of target type ${ConfigTargetType.USER_ID}`
            );
        }
        // if (segmentId) {
        //     // validate that it is a validate segment using segmentation service
        // }
    }
}
