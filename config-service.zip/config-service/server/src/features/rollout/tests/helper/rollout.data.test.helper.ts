import { v4 as uuidv4 } from "uuid";
import * as Joi from "joi";
import { Tenant } from "../../../../common/models/tenant.enum";
import { RolloutStatus } from "../../model/enums";
import { DummyRolloutDb } from "./rollout.test.types";
import { DummyConfigDb } from "../../../config/tests/helper/config.test.types";
import { ConfigEntityType, ConfigTargetType } from "../../../config/model/enums";
import { RolloutEntity } from "../../data/entity/rollout.entity";
import { Platform } from "../../../../common/models/platform.enum";

export const getRolloutPushDto = (overrideFields: any = {}) => {
    return {
        id: uuidv4(),
        name: "ROLLOUT_NAME_1",
        config_name: "CONFIG_NAME",
        rollout_percent: 100,
        status: RolloutStatus.DRAFT,
        constraints: {
            min_app_version: 50,
            max_app_version: 500,
            platform: "android"
        },
        // override passed fields
        ...overrideFields
    };
};

export const getInvalidRolloutPushDto = () => {
    return {
        id: "not-a-uuid",
        name: "@@special_symbols+-",
        config_name: [1, 2, 3],
        rollout_percent: 105,
        status: "completed",
        constraints: {
            min_app_version: "50",
            max_app_version: "500",
            platform: 123
        }
    };
};

export const getRolloutPutDto = (persistedConfig: DummyConfigDb, persistedRollout: DummyRolloutDb) => {
    return {
        id: persistedRollout.id,
        name: persistedRollout.name,
        config_name: persistedConfig.name,
        // update rollout percent
        rollout_percent: 50,
        status: persistedRollout.status,
        constraints: persistedRollout.constraints
    };
};

export const getRolloutPullResponse = (persistedRollout: DummyRolloutDb) => {
    return {
        id: persistedRollout.id,
        name: persistedRollout.name,
        config_id: persistedRollout.config_id,
        rollout_percent: persistedRollout.rollout_percent,
        status: persistedRollout.status,
        constraints: persistedRollout.constraints
    };
};

export const getInvalidRolloutGetParamsDto = () => {
    return {
        config_name: [123, 456],
        rollout_id: 123
    };
};

export const getDummyConfigModel = (overrideFields: any = {}) => {
    return {
        id: uuidv4(),
        name: "DUMMY_CONFIG_MDOEL",
        tenant: Tenant.KHATABOOK,
        entityType: ConfigEntityType.DEFAULT,
        targetType: ConfigTargetType.USER_ID,
        clientMeta: {},
        configValue: {},
        status: {},
        // override passed fields
        ...overrideFields
    };
};

export const getMockRolloutEntity = (overrideFields: any = {}): RolloutEntity => {
    return {
        id: "73378d2c-f79a-4b8c-bdb5-eff2d7aafb35",
        name: "MOCK_ROLLOUT_ENTITY",
        config_id: "49073b92-64df-44ed-ba7a-3b4c98c6a544",
        rollout_percent: 100,
        segment_id: null,
        experiment_id: null,
        status: RolloutStatus.LIVE,
        constraints: {
            min_app_version: 50,
            max_app_version: 500,
            platform: Platform.ANDROID
        },
        created_by: null,
        updated_at: new Date().toISOString(),
        updated_by: null,
        // override passed fields
        ...overrideFields
    };
};

export const ROLLOUT_SCHEMA = {
    id: Joi.string().required(),
    name: Joi.string().required(),
    config_id: Joi.string().required(),
    config_name: Joi.string().required(),
    rollout_percent: Joi.number().required(),
    status: Joi.string()
        .required()
        .valid(...Object.values(RolloutStatus)),
    constraints: Joi.object(),
    created_at: Joi.number().required(),
    created_by: Joi.string(),
    updated_at: Joi.number().required(),
    updated_by: Joi.string()
};
