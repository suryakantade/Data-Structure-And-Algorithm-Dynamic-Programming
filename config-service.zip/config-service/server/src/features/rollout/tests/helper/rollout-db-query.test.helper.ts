import { Knex } from "knex";
import { v4 as uuidv4 } from "uuid";

export class RolloutDbQueryTestHelper {
    static readonly TABLE_NAME = "rollout";

    static async persistDummyRollout(configId: string, dbClient: Knex): Promise<any> {
        const row = {
            id: uuidv4(),
            name: "DUMMY_DB_ROLLOUT",
            config_id: configId,
            rollout_percent: 100,
            status: "LIVE",
            constraints: {
                min_app_version: 5,
                max_app_version: 50,
                platform: "android"
            },
            created_by: null,
            updated_at: new Date().toISOString(),
            updated_by: null
        };
        await dbClient(RolloutDbQueryTestHelper.TABLE_NAME).insert(row);
        const insertedData = await dbClient(RolloutDbQueryTestHelper.TABLE_NAME).select().where({
            id: row.id
        });
        return insertedData[0];
    }
}
