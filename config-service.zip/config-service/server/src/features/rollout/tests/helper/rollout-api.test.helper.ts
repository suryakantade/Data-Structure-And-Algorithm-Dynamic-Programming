import { INestApplication } from "@nestjs/common";
import { ApiNetworkServiceTestHelper } from "../../../../../../tests/common/api-network-service.test.helper";
import { CommonSetupTestHelper } from "../../../../../../tests/common/common-setup.test.helper";

export async function postRollout(app: INestApplication, body: object) {
    return await ApiNetworkServiceTestHelper.post({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/rollout",
        body,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}

export async function putRollout(app: INestApplication, body: object) {
    return await ApiNetworkServiceTestHelper.put({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/rollout",
        body,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}

export async function getRollout(app: INestApplication, params: object) {
    return await ApiNetworkServiceTestHelper.get({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/rollout",
        params,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}
