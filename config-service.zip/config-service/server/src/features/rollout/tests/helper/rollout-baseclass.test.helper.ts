import { initTestApplication } from "../../../../../../tests/common/baseclass.test.helper";
import { ConfigDbQueryTestHelper } from "../../../config/tests/helper/config-db-query.test.helper";
import { TestInitDataRollout } from "./rollout.test.types";
import { RolloutDbQueryTestHelper } from "./rollout-db-query.test.helper";

export async function init(): Promise<TestInitDataRollout> {
    const testInitData = await initTestApplication();
    const dbClient = testInitData.db.databaseClient;
    const dummyConfigDbObject = await ConfigDbQueryTestHelper.persistDummyConfig(dbClient);
    const dummyRolloutDbObject = await RolloutDbQueryTestHelper.persistDummyRollout(dummyConfigDbObject.id, dbClient);
    return {
        ...testInitData,
        dummyConfigDbObject,
        dummyRolloutDbObject
    };
}
