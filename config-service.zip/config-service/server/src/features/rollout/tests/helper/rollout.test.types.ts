import { TestInitData } from "../../../../../../tests/common/types.test.helper";
import { DummyConfigDb } from "../../../config/tests/helper/config.test.types";

export interface TestInitDataRollout extends TestInitData {
    dummyConfigDbObject: DummyConfigDb;
    dummyRolloutDbObject: DummyRolloutDb;
}

export interface DummyRolloutDb {
    id: string;
    name: string;
    config_id: string;
    rollout_percent: number;
    status: string;
    constraints: object;
    created_at: string;
    created_by: string | null;
    updated_at: string;
    updated_by: string | null;
}
