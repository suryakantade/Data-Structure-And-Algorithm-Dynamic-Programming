import { TestUtility } from "../../../../../../tests/common/test.utility";
import { teardownTestApplication } from "../../../../../../tests/common/baseclass.test.helper";
import { getRollout, postRollout, putRollout } from "../helper/rollout-api.test.helper";
import {
    getInvalidRolloutGetParamsDto,
    getInvalidRolloutPushDto,
    getRolloutPullResponse,
    getRolloutPushDto,
    getRolloutPutDto,
    ROLLOUT_SCHEMA
} from "../helper/rollout.data.test.helper";
import { TestInitDataRollout } from "../helper/rollout.test.types";
import { HashService } from "../../../hash/hash.service";
import { RolloutService } from "../../rollout.service";
import { RolloutRepo } from "../../data/rollout.repo";
import { init } from "../helper/rollout-baseclass.test.helper";

describe("Integration tests for rollout logic, API: /v1/rollout", () => {
    let initData: TestInitDataRollout;
    let hashService: HashService;
    let rolloutService: RolloutService;
    let rolloutRepo: RolloutRepo;

    // Not mocking ConfigService because rollout is coupled with config, rollout table refers config as foreign key
    beforeEach(async () => {
        initData = await init();
        hashService = await initData.app.resolve(HashService);
        rolloutService = await initData.app.resolve(RolloutService);
        rolloutRepo = await initData.app.resolve(RolloutRepo);
    }, 50000);

    describe("API: POST /, create rollout", () => {
        test("verify successful creation of rollout", async () => {
            const hashUpdateSpy = jest.spyOn(hashService, "updateHash");
            const rolloutUpsertSpy = jest.spyOn(rolloutRepo, "upsertRollout");
            const body = getRolloutPushDto({
                id: undefined, // auto generated
                config_name: initData.dummyConfigDbObject.name
            });
            const response = await postRollout(initData.app, body);
            expect(response.statusCode).toBe(201);
            TestUtility.joiValidator(ROLLOUT_SCHEMA, response.body);
            expect(hashUpdateSpy).toHaveBeenCalledWith(
                expect.anything(),
                expect.objectContaining({
                    reference_id: initData.dummyConfigDbObject.id
                })
            );
            // hash must be updated before upserting the rollout in DB
            expect(hashUpdateSpy.mock.invocationCallOrder[0]).toBeLessThan(
                rolloutUpsertSpy.mock.invocationCallOrder[0]
            );
        });

        test("verify that exception is thrown when request body contract is incorrect", async () => {
            const response = await postRollout(initData.app, getInvalidRolloutPushDto());
            expect(response.statusCode).toBe(400);
            expect(response.body.message.length).toBe(7); // passed DTO with 7 incorrect fields
        });
    });

    describe("API: PUT /, update rollout", () => {
        test("verify successful update of rollout", async () => {
            const hashUpdateSpy = jest.spyOn(hashService, "updateHash");
            const rolloutUpsertSpy = jest.spyOn(rolloutRepo, "upsertRollout");
            const body = getRolloutPutDto(initData.dummyConfigDbObject, initData.dummyRolloutDbObject);
            const response = await putRollout(initData.app, body);
            expect(response.statusCode).toBe(200);
            TestUtility.joiValidator(ROLLOUT_SCHEMA, response.body[0]);
            expect(hashUpdateSpy).toHaveBeenCalledWith(
                expect.anything(),
                expect.objectContaining({
                    reference_id: initData.dummyConfigDbObject.id
                })
            );
            // hash must be updated before upserting the rollout in DB
            expect(hashUpdateSpy.mock.invocationCallOrder[0]).toBeLessThan(
                rolloutUpsertSpy.mock.invocationCallOrder[0]
            );
        });

        test("verify that exception is thrown when request body contract is incorrect", async () => {
            const response = await putRollout(initData.app, getInvalidRolloutPushDto());
            expect(response.statusCode).toBe(400);
            expect(response.body.message.length).toBe(8); // passed DTO with 8 incorrect fields
        });
    });

    describe("API: GET /, get rollout", () => {
        test.each([
            ["fetched by only config_name", true, false],
            ["fetched by only rollout_id", false, true],
            ["fetched by both config_name and rollout_id", true, true]
        ])(
            "verify successful fetching of rollout when %s",
            async (_, shouldPassConfigName: boolean, shouldPassRolloutId: boolean) => {
                const params = {};
                if (shouldPassConfigName) {
                    params["config_name"] = initData.dummyConfigDbObject.name;
                }
                if (shouldPassRolloutId) {
                    params["rollout_id"] = initData.dummyRolloutDbObject.id;
                }
                const response = await getRollout(initData.app, params);
                expect(response.statusCode).toBe(200);
                expect(response.body.length).toEqual(1);
                TestUtility.joiValidator(ROLLOUT_SCHEMA, response.body[0]);
                expect(response.body[0]).toEqual(
                    expect.objectContaining(getRolloutPullResponse(initData.dummyRolloutDbObject))
                );
            }
        );

        test("verify that exception is thrown when query params contract is incorrect", async () => {
            const response = await getRollout(initData.app, getInvalidRolloutGetParamsDto());
            expect(response.statusCode).toBe(400);
            expect(response.body.message.length).toBe(2);
        });

        test("verify that exception is thrown when neither config_name nor rollout_id is passed", async () => {
            const response = await getRollout(initData.app, {});
            expect(response.statusCode).toBe(400);
            expect(response.body.message).toMatch("Pass at-least one");
        });
    });

    afterEach(async () => {
        await teardownTestApplication(initData.app, initData.db.databaseClient);
    }, 50000);
});
