import { initTestModule } from "../../../../../../tests/common/baseclass.test.helper";
import { RolloutEvaluationService } from "../../rollout-evaluation.service";
import { RolloutRepo } from "../../data/rollout.repo";
import { getDummyConfigModel, getMockRolloutEntity } from "../helper/rollout.data.test.helper";
import { v4 as uuidv4 } from "uuid";
import { RolloutStatus } from "../../model/enums";
import { RolloutEntity } from "../../data/entity/rollout.entity";
import { RolloutEvaluationResult } from "../../model/rollout-evaluation-result";
import { Platform } from "../../../../common/models/platform.enum";
import { Config } from "../../../config/model/config";
import { ConfigTargetType } from "../../../config/model/enums";
import { PlatformInfo } from "../../../../common/models/platform-info";
import { RolloutConstraintsEntity } from "../../data/entity/rollout-constraints.entity";

describe("Unit tests for rollout-evaluation-service", () => {
    let rolloutEvaluationService: RolloutEvaluationService;
    let rolloutRepo: RolloutRepo;
    const TEST_UUID = uuidv4();

    beforeEach(async () => {
        const module = await initTestModule({ providers: [RolloutEvaluationService] });
        rolloutEvaluationService = await module.resolve(RolloutEvaluationService);
        rolloutRepo = await module.resolve(RolloutRepo);
    }, 50000);

    test.each([
        [
            "only LIVE rollouts should be evaluated",
            {},
            [getMockRolloutEntity({ id: TEST_UUID, status: RolloutStatus.LIVE, constraints: undefined })],
            getDummyConfigModel({
                // will test the user ID flow
                targetType: ConfigTargetType.USER_ID
            }),
            (result?: RolloutEvaluationResult) => expect(result!.systemData.rolloutId).toBe(TEST_UUID)
        ],
        [
            "DRAFT and DELETED rollouts should not be evaluated",
            {},
            [
                getMockRolloutEntity({ status: RolloutStatus.DRAFT, constraints: undefined }),
                getMockRolloutEntity({ status: RolloutStatus.DELETED, constraints: undefined })
            ],
            getDummyConfigModel(),
            (result?: RolloutEvaluationResult) => expect(result).toBe(undefined)
        ],
        [
            "rollouts are evaluated in order of creation time if one rollout is applicable then data from others should not be returned",
            {},
            [
                getMockRolloutEntity({
                    status: RolloutStatus.LIVE,
                    constraints: undefined,
                    created_at: new Date("2022-04-02").toISOString()
                }),
                // applicable rollout that was created earlier
                getMockRolloutEntity({
                    id: TEST_UUID,
                    status: RolloutStatus.LIVE,
                    constraints: undefined,
                    created_at: new Date("2022-04-01").toISOString()
                })
            ],
            getDummyConfigModel({
                // will test the anonymous ID flow
                targetType: ConfigTargetType.ANONYMOUS_ID
            }),
            (result?: RolloutEvaluationResult) => expect(result!.systemData.rolloutId).toBe(TEST_UUID)
        ]
    ])(
        "verify that %s",
        async (
            _,
            platformInfo: object,
            mockEntities: RolloutEntity[],
            dummyConfig: Config,
            assertions: (result?: RolloutEvaluationResult) => void
        ) => {
            let userId;
            let anonymousId;
            if (dummyConfig.targetType === ConfigTargetType.USER_ID) {
                userId = uuidv4();
            } else {
                anonymousId = uuidv4();
            }
            jest.spyOn(rolloutRepo, "getRolloutsByConfigIds").mockImplementation(async (configIds: string[]) => {
                const configId = configIds[0];
                return mockEntities.map((mockEntity) => ({
                    ...mockEntity,
                    config_id: configId
                }));
            });

            const evaluationResult = await rolloutEvaluationService.evaluateRolloutsForConfigs(
                [dummyConfig],
                platformInfo,
                userId,
                anonymousId
            );
            assertions(evaluationResult[dummyConfig.id]);
        }
    );

    test.each([
        [
            "all constraints are satisfied",
            { platform: "android", appVersion: 20 },
            { min_app_version: 5, max_app_version: 50, platform: Platform.ANDROID },
            true
        ],
        ["platform constraint is not satisfied", { platform: "ios" }, { platform: Platform.ANDROID }, false],
        ["min app version constraint is not satisfied", { appVersion: 4 }, { min_app_version: 5 }, false],
        ["max app version constraint is not satisfied", { appVersion: 55 }, { max_app_version: 50 }, false]
    ])(
        "verify constraints when %s",
        async (_, platformInfo: PlatformInfo, constraints: RolloutConstraintsEntity, doesSatisfy: boolean) => {
            const response = rolloutEvaluationService.doesSatisfyRolloutConstraints(platformInfo, constraints);
            expect(response).toBe(doesSatisfy);
        }
    );
});
