import { initTestModule } from "../../../../../../tests/common/baseclass.test.helper";
import { RolloutRepo } from "../../data/rollout.repo";
import { RolloutValidationService } from "../../rollout-validation.service";
import { ConfigService } from "../../../config/config.service";
import { getDummyConfigModel, getMockRolloutEntity } from "../helper/rollout.data.test.helper";
import { WrongInput } from "../../../../common/error/WrongInput";
import { ConfigStatus, ConfigTargetType } from "../../../config/model/enums";
import { RolloutEntity } from "../../data/entity/rollout.entity";
import { Config } from "../../../config/model/config";
import { v4 as uuidv4 } from "uuid";
import { RolloutStatus } from "../../model/enums";

describe("Unit tests for rollout-validation-service", () => {
    let rolloutValidationService: RolloutValidationService;
    let rolloutRepo: RolloutRepo;
    let configService: ConfigService;

    beforeEach(async () => {
        const module = await initTestModule({ providers: [RolloutValidationService] });
        rolloutValidationService = await module.resolve(RolloutValidationService);
        rolloutRepo = await module.resolve(RolloutRepo);
        configService = await module.resolve(ConfigService);
    }, 50000);

    describe("validate rollout insert", () => {
        test("verify during insertion that exception should be thrown if rollout with same name exists for config", async () => {
            const rolloutEntity = getMockRolloutEntity();
            jest.spyOn(rolloutRepo, "getRolloutsByConfigIdAndName").mockResolvedValue([rolloutEntity]);
            const func = () => rolloutValidationService.validateRolloutInsert(rolloutEntity);
            await expect(func()).rejects.toThrowError(WrongInput);
            await expect(func()).rejects.toThrowError("already exists");
        });
    });

    describe("validate rollout correctness", () => {
        test.each([
            ["exception should be thrown when config does not exist", getMockRolloutEntity(), [], "does not exist"],
            [
                "exception should be thrown when rollout is LIVE but config is not LIVE",
                getMockRolloutEntity({ status: ConfigStatus.LIVE }),
                [getDummyConfigModel({ status: ConfigStatus.DRAFT })],
                "invalid for this rollout"
            ],
            [
                "exception should be thrown when config target_type is USER_ID but rollout is not attached to a segment",
                getMockRolloutEntity({ segment_id: null, status: RolloutStatus.LIVE }),
                [getDummyConfigModel({ targetType: ConfigTargetType.USER_ID, status: ConfigStatus.LIVE })],
                "must be associated with a segment"
            ],
            [
                "exception should be thrown when config target_type is ANONYMOUS_ID but rollout is attached to a segment",
                getMockRolloutEntity({ segment_id: uuidv4(), status: RolloutStatus.LIVE }),
                [getDummyConfigModel({ targetType: ConfigTargetType.ANONYMOUS_ID, status: ConfigStatus.LIVE })],
                "must not be associated with a segment"
            ]
        ])("verify that %s", async (_, rolloutEntity: RolloutEntity, config: Config[], expectedMsg: string) => {
            jest.spyOn(configService, "getConfigs").mockResolvedValue(config);
            const func = () => rolloutValidationService.validateRolloutCorrectness(rolloutEntity);
            await expect(func()).rejects.toThrowError(WrongInput);
            await expect(func()).rejects.toThrowError(expectedMsg);
        });
    });
    describe("Validate rollout update", () => {
        test.each([
            ["id", [], uuidv4(), uuidv4()],
            ["name", [RolloutStatus.DRAFT], "R-1", "R-2"],
            ["config_id", [RolloutStatus.DRAFT], uuidv4(), uuidv4()],
            ["rollout_percent", [RolloutStatus.DRAFT, RolloutStatus.LIVE], 100, 90],
            ["segment_id", [RolloutStatus.DRAFT], null, uuidv4()],
            ["experiment_id", [RolloutStatus.DRAFT], uuidv4(), null],
            ["constraints", [RolloutStatus.DRAFT, RolloutStatus.LIVE], {}, { platform: "ios" }],
            ["created_by", [], "abc", "def"],
            [
                "updated_at",
                [RolloutStatus.DRAFT, RolloutStatus.LIVE, RolloutStatus.DELETED],
                new Date("2022-04-16").toISOString(),
                new Date("2022-04-17").toISOString()
            ],
            ["updated_by", [RolloutStatus.DRAFT, RolloutStatus.LIVE, RolloutStatus.DELETED], null, "xyz"]
        ])(
            "verify that %s can only be updated when rollout status is %s",
            async (
                fieldName: string,
                updateAllowedForStatus: RolloutStatus[],
                currentValue: any,
                updatedValue: any
            ) => {
                for (let enumValue in RolloutStatus) {
                    const status = enumValue as RolloutStatus;
                    const existingEntity: RolloutEntity = getMockRolloutEntity({
                        status,
                        [fieldName]: currentValue
                    });

                    const updatedEntity: RolloutEntity = getMockRolloutEntity({
                        status,
                        [fieldName]: updatedValue
                    });

                    jest.spyOn(rolloutRepo, "getRolloutById").mockResolvedValue([existingEntity]);
                    // mocking this function since this function will be tested in separate test
                    jest.spyOn(rolloutValidationService, "validateRolloutCorrectness").mockImplementation(
                        async () => {}
                    );
                    const func = () => {
                        return rolloutValidationService.validateRolloutUpdate(updatedEntity);
                    };

                    if (updateAllowedForStatus.includes(status)) {
                        // shouldn't fail
                        await expect(func()).resolves.toBe(undefined);
                    } else {
                        // should fail
                        await expect(func()).rejects.toThrowError(WrongInput);
                        await expect(func()).rejects.toThrow("cannot be updated");
                    }
                }
            }
        );

        test("verify that exception is thrown when trying to update non-existent rollout", async () => {
            const updatedEntity: RolloutEntity = getMockRolloutEntity();
            jest.spyOn(rolloutRepo, "getRolloutById").mockResolvedValue([]);
            const func = () => {
                return rolloutValidationService.validateRolloutUpdate(updatedEntity);
            };
            await expect(func()).rejects.toThrowError(WrongInput);
            await expect(func()).rejects.toThrowError("does not exist");
        });
    });

    describe("validate rollout status update", () => {
        type TestParams = {
            currentStatus: RolloutStatus;
            newStatus: RolloutStatus;
            isValid: boolean;
        };

        const validStatusTransitions: Record<RolloutStatus, RolloutStatus[]> = {
            [RolloutStatus.DRAFT]: [RolloutStatus.LIVE, RolloutStatus.DELETED],
            [RolloutStatus.LIVE]: [RolloutStatus.DELETED],
            [RolloutStatus.DELETED]: []
        };

        let testCases: TestParams[] = [];
        for (let e1 in ConfigStatus) {
            const currentStatus = e1 as RolloutStatus;
            for (let e2 in ConfigStatus) {
                const newStatus = e2 as RolloutStatus;
                if (e1 === e2) {
                    continue;
                }
                testCases.push({
                    currentStatus,
                    newStatus,
                    isValid: validStatusTransitions[currentStatus].includes(newStatus)
                });
            }
        }

        test.each(testCases)(
            "verify that rollout status update from $currentStatus to $newStatus is $isValid",
            async ({ currentStatus, newStatus, isValid }: TestParams) => {
                const existingEntity: RolloutEntity = getMockRolloutEntity({ status: currentStatus });
                const updatedEntity: RolloutEntity = getMockRolloutEntity({ status: newStatus });

                jest.spyOn(rolloutRepo, "getRolloutById").mockResolvedValue([existingEntity]);
                // mocking this function since this function will be tested in separate test
                jest.spyOn(rolloutValidationService, "validateRolloutCorrectness").mockImplementation(async () => {});
                const func = () => {
                    return rolloutValidationService.validateRolloutUpdate(updatedEntity);
                };
                if (isValid) {
                    await expect(func()).resolves.toBe(undefined);
                } else {
                    await expect(func()).rejects.toThrowError(WrongInput);
                }
            }
        );
    });
});
