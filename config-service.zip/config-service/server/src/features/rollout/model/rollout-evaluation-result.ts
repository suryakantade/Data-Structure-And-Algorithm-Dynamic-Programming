export class RolloutEvaluationResult {
    // will be present if rollout is attached to an AB experiment
    configuration?: object;
    // more fields to be added after segment and experiment integration
    systemData: {
        rolloutId: string;
    };
}
