export enum RolloutStatus {
    DRAFT = "DRAFT",
    LIVE = "LIVE",
    DELETED = "DELETED"
}
