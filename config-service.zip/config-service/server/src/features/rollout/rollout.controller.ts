import { Controller, Post, Body, Put, Get, Query } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { RolloutService } from "./rollout.service";
import { RolloutInsertDto, RolloutPushDto } from "./dto/rollout-push.dto";
import { RolloutGetParamsDto } from "./dto/rollout-get.params.dto";
import { RolloutPullResponseDto } from "./dto/rollout-pull-response.dto";
import { IntraApi } from "../../common/decorators/authentication-decorators";

@ApiTags("APIs for CRUD operations on rollout")
@Controller({
    path: "rollout",
    version: "1"
})
@IntraApi()
export class RolloutController {
    constructor(readonly rolloutService: RolloutService) {}

    /**
     * API for creating a new rollout
     */
    @Post()
    pushRollout(@Body() insertDto: RolloutInsertDto): Promise<RolloutPullResponseDto> {
        return this.rolloutService.pushRollout(insertDto);
    }

    /**
     * API for updating an existing rollout
     */
    @Put()
    putRollout(@Body() rolloutDto: RolloutPushDto): Promise<RolloutPullResponseDto> {
        return this.rolloutService.putRollout(rolloutDto);
    }

    /**
     * API for fetching a rollout
     */
    @Get()
    getRollout(@Query() params: RolloutGetParamsDto): Promise<RolloutPullResponseDto[]> {
        return this.rolloutService.getRollouts(params);
    }
}
