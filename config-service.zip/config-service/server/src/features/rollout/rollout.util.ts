export class RolloutUtils {
    static hashStringToNumber = (str: string) => {
        let hash = 23;
        for (let ch of str) {
            hash = hash * 31 + ch.charCodeAt(0);
        }
        return hash;
    };
}
