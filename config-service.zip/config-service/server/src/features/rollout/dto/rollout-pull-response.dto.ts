import { RolloutStatus } from "../model/enums";
import { RolloutConstraintsDto } from "./rollout-constraints.dto";

export class RolloutPullResponseDto {
    /**
     * UUID - ID of rollout
     * @example 27b06503-76e5-4f01-95d5-bf7a36044293
     */
    id: string;

    /**
     * Name of rollout
     * @example CASHBOOK_HOME_SCREEN_ROLLOUT_ANDROID
     */
    name: string;

    /**
     * ID of the config to which this rollout belongs
     * @example 0cd59da2-4c41-4388-9fa8-17cbd4000204
     */
    config_id: string;

    /**
     * Name of the config to which this rollout belongs
     * @example CASHBOOK_HOME_SCREEN
     */
    config_name: string;

    /**
     * Percentage(0-100) of users getting the rollout
     * @example 25.75
     */
    rollout_percent: number;

    // segment_id?: string;

    // experiment_id?: string;

    /**
     * Current status of rollout
     * @example LIVE
     */
    status: RolloutStatus;

    /**
     * Rollout constraints that are used during rollout evaluation
     */
    constraints?: RolloutConstraintsDto;

    /**
     * Unix timestamp in milliseconds at which the rollout was created
     * @example 1649425044811
     */
    created_at: number;

    /**
     * User who created the rollout. Currently this is not supported so it will always be null
     * @example null
     */
    created_by?: string;

    /**
     * Unix timestamp in milliseconds at which the rollout was last updated
     * @example 1649425068658
     */
    updated_at: number;

    /**
     * User who last updated the rollout. Currently this is not supported so it will always be null
     * @example null
     */
    updated_by?: string;
}
