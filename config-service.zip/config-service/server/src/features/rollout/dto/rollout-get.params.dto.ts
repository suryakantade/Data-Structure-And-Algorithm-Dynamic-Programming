import { IsOptional, IsString, IsUUID } from "class-validator";

export class RolloutGetParamsDto {
    /**
     * Config Name for which rollouts needs to be fetched
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    @IsOptional()
    config_name?: string;

    /**
     * ID of rollout that needs to be fetched
     * @example bca324bb-d1f3-4af6-9532-02880f420032
     */
    @IsUUID()
    @IsOptional()
    rollout_id?: string;
}
