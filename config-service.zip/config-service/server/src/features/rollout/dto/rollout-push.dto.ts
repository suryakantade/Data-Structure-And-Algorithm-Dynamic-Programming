import {
    IsEnum,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    IsUUID,
    Matches,
    Max,
    Min,
    ValidateNested
} from "class-validator";
import { RolloutStatus } from "../model/enums";
import { RolloutConstraintsDto } from "./rollout-constraints.dto";
import { Type } from "class-transformer";
import { OmitType } from "@nestjs/swagger";

export class RolloutPushDto {
    /**
     * UUID - unique ID for rollout
     * @example 2a791b01-4877-4647-9c0f-837b7f7899b8
     */
    @IsUUID()
    id: string;

    /**
     * Name for rollout, can only contain capital alphabets, digits or underscore
     * @example CASHBOOK_HOME_SCREEN_ROLLOUT_ANDROID
     */
    @IsString()
    @Matches(/^[A-Z_0-9]+$/, {
        message: "Name can only contain capital alphabets A to Z, digits 0 to 9, or underscores(_)"
    })
    name: string;

    /**
     * Name of the config for which this rollout is being created
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    config_name: string;

    /**
     * Rollout percent between 0 to 100. Precision upto 4 decimal places is supported.
     * @example 25.3586
     */
    @IsNumber(
        { maxDecimalPlaces: 4 },
        {
            message: (args) => {
                return `${args.property} must be a number with maximum 4 decimal places`;
            }
        }
    )
    @Max(100)
    @Min(0)
    rollout_percent: number;

    // will add below fields when integrating with segment and experiment service
    // @IsUUID()
    // @IsOptional()
    // segment_id?: string;

    // @IsUUID()
    // @IsOptional()
    // experiment_id?: string;

    /**
     * Current status of the rollout
     * @example LIVE
     */
    @IsEnum(RolloutStatus)
    status: RolloutStatus;

    /**
     * Constraints that should be applied while evaluating the rollout
     */
    @ValidateNested()
    @Type(() => RolloutConstraintsDto)
    @IsObject()
    @IsOptional()
    constraints?: RolloutConstraintsDto;
}

export class RolloutInsertDto extends OmitType(RolloutPushDto, ["id"] as const) {}
