import { IsEnum, IsNumber, IsOptional } from "class-validator";
import { Platform } from "../../../common/models/platform.enum";

export class RolloutConstraintsDto {
    /**
     * Constraint for minimum app version
     * @example 602400
     */
    @IsNumber()
    @IsOptional()
    min_app_version?: number;

    /**
     * Constraint for maximum app version
     * @example 602800
     */
    @IsNumber()
    @IsOptional()
    max_app_version?: number;

    /**
     * Constraint for platform
     * @example android
     */
    @IsEnum(Platform)
    @IsOptional()
    platform?: Platform;
}
