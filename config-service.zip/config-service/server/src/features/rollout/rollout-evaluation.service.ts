import { Injectable } from "@nestjs/common";
import { PlatformInfo } from "../../common/models/platform-info";
import { RolloutEvaluationResult } from "./model/rollout-evaluation-result";
import { Helper } from "../../utils/helper";
import * as assert from "assert";
import { LogService } from "@khatabook/nestjs-logger";
import { RolloutStatus } from "./model/enums";
import { RolloutRepo } from "./data/rollout.repo";
import { RolloutConstraintsEntity } from "./data/entity/rollout-constraints.entity";
import { RolloutColumnName } from "./data/entity/rollout.column";
import { Config } from "../config/model/config";
import { ConfigTargetType } from "../config/model/enums";
import { IllegalState } from "../../common/error/IllegalState";
import { RolloutUtils } from "./rollout.util";

@Injectable()
export class RolloutEvaluationService {
    constructor(private readonly log: LogService, private readonly rolloutRepo: RolloutRepo) {
        log.setContext(RolloutEvaluationService.name);
    }

    /**
     * Returns undefined as map value if user is not eligible for any of the rollouts or there is no LIVE rollout
     */
    async evaluateRolloutsForConfigs(
        configs: Config[],
        platformInfo: PlatformInfo,
        userId?: string,
        anonymousId?: string
    ): Promise<Record<string, RolloutEvaluationResult | undefined>> {
        let configIds: string[] = [];
        let configIdToConfigMap: Record<string, Config> = {};
        configs.forEach((config) => {
            configIds.push(config.id);
            configIdToConfigMap[config.id] = config;
        });

        const rollouts = await this.rolloutRepo.getRolloutsByConfigIds(configIds);

        // filter out non-live rollouts
        const liveRollouts = rollouts.filter((x) => x[RolloutColumnName.STATUS] === RolloutStatus.LIVE);
        // sort ascending by rollout creation time
        liveRollouts.sort((rollout1, rollout2) => {
            const rollout1CreatedAt = rollout1.created_at;
            const rollout2CreatedAt = rollout2.created_at;
            return new Date(rollout1CreatedAt).getTime() - new Date(rollout2CreatedAt).getTime();
        });

        let rolloutEvaluationResultsForConfigs: Record<string, RolloutEvaluationResult | undefined> = {};
        for (const rollout of liveRollouts) {
            const { config_id: configId, constraints, id: rolloutId, rollout_percent: rolloutPercent } = rollout;
            const config = configIdToConfigMap[configId];
            const areConstraintsSatisfied = this.doesSatisfyRolloutConstraints(platformInfo, constraints ?? undefined);
            if (areConstraintsSatisfied) {
                // see whether user falls in the rollout or not
                let uuidHash: number;
                if (config.targetType === ConfigTargetType.USER_ID) {
                    assert(userId !== undefined, "User ID cannot be undefined if config target_type is USER_ID");
                    uuidHash = this.getUuidNumericHash(rolloutId, userId);
                } else if (config.targetType === ConfigTargetType.ANONYMOUS_ID) {
                    assert(
                        anonymousId !== undefined,
                        "Anonymous ID cannot be undefined if config target_type is ANONYMOUS_ID"
                    );
                    uuidHash = this.getUuidNumericHash(rolloutId, anonymousId);
                } else {
                    // impossible state
                    throw new IllegalState(
                        `Config target type must be either ${ConfigTargetType.USER_ID} or ${ConfigTargetType.ANONYMOUS_ID}`
                    );
                }
                const isPartOfRollout = uuidHash <= rolloutPercent;
                if (isPartOfRollout) {
                    rolloutEvaluationResultsForConfigs[configId] = {
                        systemData: {
                            rolloutId
                            // eventually will contain segment and experiment related data
                        }
                    };
                    // do not evaluate further rollouts because a user can be assigned only one rollout at a time
                    break;
                }
            }
        }
        return rolloutEvaluationResultsForConfigs;
    }

    doesSatisfyRolloutConstraints(platformInfo: PlatformInfo, rolloutConstraints?: RolloutConstraintsEntity): boolean {
        this.log.debug({ data: { constraints: rolloutConstraints, inputPlatformInfo: platformInfo } });
        if (!rolloutConstraints) {
            return true;
        }
        let satisfiesConstraints: boolean = true;

        if (
            !Helper.isNullOrUndefined(rolloutConstraints.platform) &&
            (Helper.isNullOrUndefined(platformInfo.platform) || platformInfo.platform !== rolloutConstraints.platform)
        ) {
            satisfiesConstraints = false;
        }
        if (
            !Helper.isNullOrUndefined(rolloutConstraints.max_app_version) &&
            (Helper.isNullOrUndefined(platformInfo.appVersion) ||
                platformInfo.appVersion! > rolloutConstraints.max_app_version!)
        ) {
            satisfiesConstraints = false;
        }
        if (
            !Helper.isNullOrUndefined(rolloutConstraints.min_app_version) &&
            (Helper.isNullOrUndefined(platformInfo.appVersion) ||
                platformInfo.appVersion! < rolloutConstraints.min_app_version!)
        ) {
            satisfiesConstraints = false;
        }
        return satisfiesConstraints;
    }

    private getUuidNumericHash(rolloutId: string, uuid: string): number {
        // concat rolloutId so that the hash is different for a user across different rollouts of same config
        const targetString = rolloutId + uuid;

        // check server/bin/uuid_to_number_distribution_test_script.js to see how fairly hashes are distributed between 0 to 100
        const numericRepresentation = RolloutUtils.hashStringToNumber(targetString);
        const decimalPlaces = 4;
        const moduloDivisor = Math.pow(10, decimalPlaces + 2) + 1; // if we want between 0 to 100 the divisor should be 101
        const modulo = numericRepresentation % moduloDivisor;
        const hashDivisor = Math.pow(10, decimalPlaces);
        const hash = modulo / hashDivisor;
        this.log.debug(`Numeric hash for ${targetString} between 0 to 100 is ${hash}`);
        return hash;
    }
}
