import { RolloutStatus } from "../../model/enums";
import { RolloutEntity, RolloutUpdateEntity } from "./rollout.entity";

export enum RolloutColumnName {
    ID = "id",
    NAME = "name",
    CONFIG_ID = "config_id",
    ROLLOUT_PERCENT = "rollout_percent",
    SEGMENT_ID = "segment_id",
    EXPERIMENT_ID = "experiment_id",
    STATUS = "status",
    CONSTRAINTS = "constraints",

    CREATED_AT = "created_at",
    CREATED_BY = "created_by",
    UPDATED_AT = "updated_at",
    UPDATED_BY = "updated_by"
}

export class UpdateEligibility {
    canUpdate: boolean;
    failureMessage?: string;

    constructor(canUpdate: boolean, failureMessage?: string) {
        this.canUpdate = canUpdate;
        this.failureMessage = failureMessage;
    }

    static ValidUpdate(): UpdateEligibility {
        return new UpdateEligibility(true);
    }

    static InvalidUpdate(failureMessage: string): UpdateEligibility {
        return new UpdateEligibility(false, failureMessage);
    }
}

export interface RolloutColumnHelpers {
    /**
     * Whether updating current value to a new one is valid or not in a given config status.
     */
    canUpdate: (
        currentRolloutStatus: RolloutStatus,
        existingEntity: RolloutEntity,
        newEntity: RolloutUpdateEntity
    ) => UpdateEligibility;
}

export const ROLLOUT_COLUMNS: Record<RolloutColumnName, RolloutColumnHelpers> = {
    [RolloutColumnName.ID]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Rollout ID cannot be updated")
    },
    [RolloutColumnName.NAME]: {
        canUpdate: (currentRolloutStatus) => {
            return [RolloutStatus.DRAFT].includes(currentRolloutStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Rollout Name cannot be updated in ${currentRolloutStatus} status`);
        }
    },
    [RolloutColumnName.CONFIG_ID]: {
        canUpdate: (currentRolloutStatus) => {
            return [RolloutStatus.DRAFT].includes(currentRolloutStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Config ID cannot be updated in ${currentRolloutStatus} status`);
        }
    },
    [RolloutColumnName.ROLLOUT_PERCENT]: {
        canUpdate: (currentRolloutStatus) => {
            return [RolloutStatus.DRAFT, RolloutStatus.LIVE].includes(currentRolloutStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(
                      `Rollout Percentage cannot be updated in ${currentRolloutStatus} status`
                  );
        }
    },
    [RolloutColumnName.SEGMENT_ID]: {
        canUpdate: (currentRolloutStatus) => {
            return [RolloutStatus.DRAFT].includes(currentRolloutStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Segment ID cannot be updated in ${currentRolloutStatus} status`);
        }
    },
    [RolloutColumnName.EXPERIMENT_ID]: {
        canUpdate: (currentRolloutStatus) => {
            return [RolloutStatus.DRAFT].includes(currentRolloutStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Experiment ID cannot be updated in ${currentRolloutStatus} status`);
        }
    },
    [RolloutColumnName.STATUS]: {
        canUpdate: (currentConfigStatus, existingEntity, newEntity) => {
            if (![RolloutStatus.DRAFT, RolloutStatus.LIVE].includes(currentConfigStatus)) {
                return UpdateEligibility.InvalidUpdate(`Status cannot be updated in ${currentConfigStatus} status`);
            }
            const { status: currentStatus } = existingEntity;
            const { status: newStatus } = newEntity;
            let isStatusTransitionValid: boolean = true;
            if (currentStatus === newStatus) {
                return UpdateEligibility.ValidUpdate();
            }
            switch (currentStatus) {
                case RolloutStatus.DRAFT:
                    isStatusTransitionValid = [RolloutStatus.LIVE, RolloutStatus.DELETED].includes(newStatus);
                    break;
                case RolloutStatus.LIVE:
                    isStatusTransitionValid = [RolloutStatus.DELETED].includes(newStatus);
                    break;
                case RolloutStatus.DELETED:
                    isStatusTransitionValid = false;
                    break;
                default:
                    isStatusTransitionValid = false;
                    break;
            }
            if (isStatusTransitionValid) {
                return UpdateEligibility.ValidUpdate();
            } else {
                return UpdateEligibility.InvalidUpdate(
                    `Status transition from ${currentStatus} to ${newStatus} is not allowed`
                );
            }
        }
    },
    [RolloutColumnName.CONSTRAINTS]: {
        canUpdate: (currentRolloutStatus) => {
            return [RolloutStatus.DRAFT, RolloutStatus.LIVE].includes(currentRolloutStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Constraints cannot be updated in ${currentRolloutStatus} status`);
        }
    },
    [RolloutColumnName.CREATED_AT]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Created At cannot be updated")
    },
    [RolloutColumnName.CREATED_BY]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Created By cannot be updated")
    },
    [RolloutColumnName.UPDATED_AT]: {
        canUpdate: () => UpdateEligibility.ValidUpdate()
    },
    [RolloutColumnName.UPDATED_BY]: {
        canUpdate: () => UpdateEligibility.ValidUpdate()
    }
};
