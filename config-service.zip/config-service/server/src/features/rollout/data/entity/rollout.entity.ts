import { RolloutConstraintsEntity } from "./rollout-constraints.entity";
import { RolloutColumnName } from "./rollout.column";
import { RolloutStatus } from "../../model/enums";

export class RolloutEntity {
    [RolloutColumnName.ID]: string;

    [RolloutColumnName.NAME]: string;

    [RolloutColumnName.CONFIG_ID]: string;

    [RolloutColumnName.ROLLOUT_PERCENT]: number;

    [RolloutColumnName.SEGMENT_ID]: string | null;

    [RolloutColumnName.EXPERIMENT_ID]: string | null;

    [RolloutColumnName.STATUS]: RolloutStatus;

    [RolloutColumnName.CONSTRAINTS]: RolloutConstraintsEntity | null;

    [RolloutColumnName.CREATED_AT]: string;

    // this is nullable column in DB, knex returns DB NULL values as javascript "null" object and not as "undefined".
    // That's why not adding undefined in type definition.
    [RolloutColumnName.CREATED_BY]: string | null;

    [RolloutColumnName.UPDATED_AT]: string;

    [RolloutColumnName.UPDATED_BY]: string | null;
}

// to ensure that created_at and created_by are never updated for an already present row
export type RolloutUpdateEntity = Omit<RolloutEntity, RolloutColumnName.CREATED_AT | RolloutColumnName.CREATED_BY>;
