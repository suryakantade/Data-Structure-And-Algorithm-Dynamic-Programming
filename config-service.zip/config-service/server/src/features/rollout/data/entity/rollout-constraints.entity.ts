import { Platform } from "../../../../common/models/platform.enum";

export class RolloutConstraintsEntity {
    min_app_version?: number;
    max_app_version?: number;
    platform?: Platform;
}
