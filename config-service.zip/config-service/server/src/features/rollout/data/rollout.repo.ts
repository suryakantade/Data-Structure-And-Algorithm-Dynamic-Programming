import { Inject, Injectable } from "@nestjs/common";
import { Constants } from "../../../utils/constants";
import { DataBase } from "../../../lib/database/database.service";
import { RolloutEntity, RolloutUpdateEntity } from "./entity/rollout.entity";
import { RolloutColumnName } from "./entity/rollout.column";

@Injectable()
export class RolloutRepo {
    readonly TABLE_NAME = "rollout";
    readonly UPSERT_CONFLICT_COLUMNS = ["id", "config_id"];

    constructor(
        @Inject(Constants.DATABASE_SERVICE_TOKEN)
        protected readonly db: DataBase
    ) {}

    async upsertRollout<T = RolloutEntity | RolloutUpdateEntity>(entity: T): Promise<RolloutEntity[]> {
        return this.db<RolloutEntity>(this.TABLE_NAME)
            .insert(entity)
            .onConflict(this.UPSERT_CONFLICT_COLUMNS)
            .merge()
            .returning("*");
    }

    async getByRolloutIdAndConfigId(rolloutId: string, configId: string): Promise<RolloutEntity[]> {
        return this.db<RolloutEntity>(this.TABLE_NAME).select().where({
            id: rolloutId,
            config_id: configId
        });
    }

    async getRolloutById(rolloutId: string): Promise<RolloutEntity[]> {
        return this.db<RolloutEntity>(this.TABLE_NAME).select().where(RolloutColumnName.ID, rolloutId);
    }

    async getRolloutsByConfigIds(configIds: string[]): Promise<RolloutEntity[]> {
        return this.db<RolloutEntity>(this.TABLE_NAME).select().whereIn(RolloutColumnName.CONFIG_ID, configIds);
    }

    async getRolloutsByConfigIdAndName(configId: string, rolloutName: string): Promise<RolloutEntity[]> {
        return this.db<RolloutEntity>(this.TABLE_NAME).select().where({
            config_id: configId,
            name: rolloutName
        });
    }
}
