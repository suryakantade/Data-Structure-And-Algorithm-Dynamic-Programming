import { IsEnum, IsObject, IsOptional, IsString, IsUUID, Matches } from "class-validator";
import { ConfigEntityType, ConfigStatus, ConfigTargetType } from "../model/enums";
import { Tenant } from "../../../common/models/tenant.enum";
import { OmitType } from "@nestjs/swagger";

export class ConfigPushDto {
    /**
     * Unique UUID for config
     * @example 3ee19046-4b3d-4b37-8275-5f140ff09eb4
     */
    @IsUUID()
    id: string;

    /**
     * Globally unique name for config, can only contain capital alphabets, digits or underscore
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    @Matches(/^[A-Z_0-9]+$/, {
        message: "Name can only contain capital alphabets A to Z, digits 0 to 9, or underscores(_)"
    })
    name: string;

    /**
     * Tenant to which config belongs
     * @example KHATABOOK
     *
     */
    @IsEnum(Tenant)
    tenant: Tenant;

    /**
     * Entity under which config falls, signifies the purpose of this config
     * @example FEATURE
     */
    @IsEnum(ConfigEntityType)
    entity_type: ConfigEntityType;

    /**
     * The target of the config, whether it requires user context(user_id) or not(anonymous_id)
     * @example USER_ID
     */
    @IsEnum(ConfigTargetType)
    target_type: ConfigTargetType;

    /**
     * Technical client config(no impact on user experience)
     */
    @IsObject()
    @IsOptional()
    client_meta?: object;

    /**
     * Config that can potentially impact user experience
     */
    @IsObject()
    @IsOptional()
    config_value?: object;

    /**
     * Current status of the config
     * @example LIVE
     */
    @IsEnum(ConfigStatus)
    status: ConfigStatus;
}

export class ConfigInsertDto extends OmitType(ConfigPushDto, ["id"] as const) {}
