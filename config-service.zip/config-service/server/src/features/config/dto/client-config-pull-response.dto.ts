import { ConfigEntityType } from "../model/enums";
import { Tenant } from "../../../common/models/tenant.enum";

export class ClientConfigPullResponseDto {
    /**
     * Signifies whether there are more configs to fetch. Currently pagination is not supported so it will always be false.
     * @example false
     */
    has_more: boolean;

    /**
     * list of items containing config data
     */
    items: ClientConfigPullResponseItemDto[];
}

export class ClientConfigPullResponseItemDto {
    /**
     * Config ID
     * @example b502b482-ddf4-4286-8452-f150daa79c93
     */
    id: string;

    /**
     * Config name
     * @example CASHBOOK_HOME_SCREEN
     */
    name: string;

    /**
     * Tenant to which config belongs
     * @example KHATABOOK
     */
    tenant: Tenant;

    /**
     * Entity type of config
     * @example DEFAULT
     */
    entity_type: ConfigEntityType;

    /**
     * Technical client config(no impact on user experience)
     */
    client_meta?: object;

    /**
     * Config that can potentially impact user experience
     */
    config_value?: object;

    /**
     * Metadata related to config like rolloutId, experiment and variant info etc.
     */
    system_data?: object;
}
