import { IsEnum, IsOptional } from "class-validator";
import { ConfigEntityType } from "../model/enums";

export class ClientConfigPullRequestParamsDto {
    /**
     * Entity type of config
     * @example FEATURE
     */
    @IsEnum(ConfigEntityType)
    @IsOptional()
    entity_type?: ConfigEntityType;
}
