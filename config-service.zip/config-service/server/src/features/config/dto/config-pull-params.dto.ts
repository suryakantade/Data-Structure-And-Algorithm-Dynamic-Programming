import { IsEnum, IsOptional, IsString, IsUUID } from "class-validator";
import { Tenant } from "../../../common/models/tenant.enum";
import { ConfigEntityType } from "../model/enums";

export class ConfigPullParamsDto {
    /**
     * Tenant to which config belongs
     * @example KHATABOOK
     *
     */
    @IsEnum(Tenant)
    tenant: Tenant;

    /**
     * Entity Type of config
     * @example FEATURE
     */
    @IsEnum(ConfigEntityType)
    @IsOptional()
    entity_type?: ConfigEntityType;

    /**
     * ID of config
     * @example 3ee19046-4b3d-4b37-8275-5f140ff09eb4
     */
    @IsUUID()
    @IsOptional()
    config_id?: string;

    /**
     * Name of config
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    @IsOptional()
    config_name?: string;
}
