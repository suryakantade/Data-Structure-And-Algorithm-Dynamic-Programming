import { ConfigEntityType, ConfigStatus, ConfigTargetType } from "../model/enums";
import { Tenant } from "../../../common/models/tenant.enum";

export class ConfigPullResponseDto {
    /**
     * Config ID
     * @example b502b482-ddf4-4286-8452-f150daa79c93
     */
    id: string;

    /**
     * Config name
     * @example CASHBOOK_HOME_SCREEN
     */
    name: string;

    /**
     * Tenant to which config belongs
     * @example KHATABOOK
     */
    tenant: Tenant;

    /**
     * Entity type of config
     * @example DEFAULT
     */
    entity_type: ConfigEntityType;

    /**
     * The target of the config, whether it requires user context(user_id) or not(anonymous_id)
     * @example USER_ID
     */
    target_type: ConfigTargetType;

    /**
     * Technical client config(no impact on user experience)
     */
    client_meta?: object;

    /**
     * Config that can potentially impact user experience
     */
    config_value?: object;

    /**
     * Current config status
     * @example DRAFT
     */
    status: ConfigStatus;

    /**
     * Config creation time expressed in unix timestamp milliseconds
     * @example 1648891979269
     */
    created_at: number;

    /**
     * Identifier for user who created the config. Currently this is not supported so it will always be null
     * @example null
     */
    created_by?: string;

    /**
     * Config last update time expressed in unix timestamp milliseconds
     * @example 1648891979269
     */
    updated_at: number;

    /**
     * Identifier for user who last updated the config. Currently this is not supported so it will always be null
     * @example null
     */
    updated_by?: string;
}
