import { IsArray, IsObject, IsOptional, IsString, IsUUID, ValidateNested } from "class-validator";
import { Type } from "class-transformer";

export class ClientConfigPullRequestMetaDto {
    /**
     * User ID for which config needs to be fetched
     * @example 29f29f0f-1571-4afe-80c3-a9c93ab00ba4
     */
    @IsUUID()
    @IsOptional()
    user_id?: string;

    /**
     * A random UUID for fetching config, this can be used for fetching configs that does not require user context
     * @example c7059c11-3404-4533-bc7c-21a4397d0276
     */
    @IsUUID()
    @IsOptional()
    anonymous_id?: string;
}

export class ClientConfigPullRequestItemDto {
    /**
     * Name of the config
     * @example CASHBOOK_HOME_SCREEN
     */
    @IsString()
    config_name: string;

    /**
     * Current hash of the config that client have
     * @example 251d22f1-331f-4d63-a993-dc9f0daad3de#1648891148426
     */
    @IsString()
    @IsOptional()
    config_hash?: string;
}

export class ClientConfigPullRequestDto {
    /**
     * Meta data needed for fetching config like user_id etc.
     */
    @IsObject()
    @ValidateNested()
    @Type(() => ClientConfigPullRequestMetaDto)
    meta: ClientConfigPullRequestMetaDto;

    /**
     * Information related to configs for which data needs to be fetched
     */
    @IsArray()
    @ValidateNested()
    @Type(() => ClientConfigPullRequestItemDto)
    items: ClientConfigPullRequestItemDto[];
}
