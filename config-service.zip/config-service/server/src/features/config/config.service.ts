import { forwardRef, Inject, Injectable } from "@nestjs/common";
import { ConfigRepo } from "./data/config.repo";
import { ConfigEntity, ConfigUpdateEntity } from "./data/entity/config.entity";
import { Config } from "./model/config";
import { LogService } from "@khatabook/nestjs-logger";
import { ConfigValidationService } from "./config-validation.service";
import { ConfigColumnName } from "./data/entity/config.columns";
import { Tenant } from "../../common/models/tenant.enum";
import { ConfigInsertDto, ConfigPushDto } from "./dto/config-push.dto";
import { ConfigPullParamsDto } from "./dto/config-pull-params.dto";
import { ConfigPullResponseDto } from "./dto/config-pull-response.dto";
import { ConfigEntityType } from "./model/enums";
import { HashService } from "../hash/hash.service";
import { HashEntityType, HashUpdateReferenceType } from "../hash/model/enums";
import * as assert from "assert";
import * as _ from "lodash";
import { v4 as uuidv4 } from "uuid";

@Injectable()
export class ConfigService {
    constructor(
        private readonly configRepo: ConfigRepo,
        private readonly log: LogService,
        private readonly configValidationService: ConfigValidationService,
        @Inject(forwardRef(() => HashService))
        private readonly hashService: HashService
    ) {
        log.setContext(ConfigService.name);
    }

    async handlePushConfigApi(insertDto: ConfigInsertDto): Promise<ConfigPullResponseDto> {
        const configPushDto: ConfigPushDto = {
            ...insertDto,
            id: uuidv4()
        };
        const entityToInsert = this.getConfigEntityFromPushDto(configPushDto);
        await this.configValidationService.validateConfigInsert(entityToInsert);
        // IMP: updating the hash before DB changes because if upsert is done first and hash updation fails then
        // config will be updated but its hash will remain same (i.e. incorrect state). In below approach, hash will be updated even if upsert
        // fails, that does not have any implication on correctness of data, just that client might do some redundant API calls.
        await this.updateHash(configPushDto.name);
        const insertedEntities = await this.configRepo.upsertConfig(entityToInsert);
        assert(insertedEntities.length === 1, "Exactly one config should have been inserted");
        return this.getConfigResponseDtoFromEntity(insertedEntities[0]);
    }

    async handlePutConfigApi(configPushDto: ConfigPushDto): Promise<ConfigPullResponseDto> {
        const entityToUpdate: ConfigUpdateEntity = _.omit(
            this.getConfigEntityFromPushDto(configPushDto),
            ConfigColumnName.CREATED_AT,
            ConfigColumnName.CREATED_BY
        );

        await this.configValidationService.validateConfigUpdate(entityToUpdate);
        // IMP: updating the hash before DB changes because if upsert is done first and hash updation fails then
        // config will be updated but its hash will remain same (i.e. incorrect state). In below approach, hash will be updated even if upsert
        // fails, that does not have any implication on correctness of data, just that client might do some redundant API calls.
        await this.updateHash(configPushDto.name);
        const updatedEntities = await this.configRepo.upsertConfig(entityToUpdate);
        assert(updatedEntities.length === 1, "Exactly one config should have been updated");
        return this.getConfigResponseDtoFromEntity(updatedEntities[0]);
    }

    async handleGetConfigApi(params: ConfigPullParamsDto): Promise<ConfigPullResponseDto[]> {
        const { tenant, config_id, config_name, entity_type } = params;
        let entities: ConfigEntity[] = await this.configRepo.getConfigByTenantAndIdAndNameAndEntityType(
            tenant,
            config_id,
            config_name ? [config_name] : undefined,
            entity_type
        );

        return entities.map(this.getConfigResponseDtoFromEntity);
    }

    async getConfigs(
        tenant?: Tenant,
        configId?: string,
        configName?: string,
        entityType?: ConfigEntityType
    ): Promise<Config[]> {
        const configEntities = await this.configRepo.getConfigByTenantAndIdAndNameAndEntityType(
            tenant,
            configId,
            configName ? [configName] : undefined,
            entityType
        );
        return configEntities.map((entity) => ({
            id: entity.id,
            name: entity.name,
            tenant: entity.tenant,
            entityType: entity.entity_type,
            targetType: entity.target_type,
            clientMeta: entity.client_meta ?? undefined,
            configValue: entity.config_value ?? undefined,
            status: entity.status
        }));
    }

    private getConfigEntityFromPushDto(configDto: ConfigPushDto): ConfigEntity {
        return {
            id: configDto.id,
            name: configDto.name,
            tenant: configDto.tenant,
            entity_type: configDto.entity_type,
            target_type: configDto.target_type,
            client_meta: configDto.client_meta ?? null,
            config_value: configDto.config_value ?? null,
            status: configDto.status,
            created_at: new Date().toISOString(),
            created_by: null,
            updated_at: new Date().toISOString(),
            updated_by: null
        };
    }

    private getConfigResponseDtoFromEntity(entity: ConfigEntity): ConfigPullResponseDto {
        return {
            id: entity[ConfigColumnName.ID],
            name: entity[ConfigColumnName.NAME],
            tenant: entity[ConfigColumnName.TENANT],
            entity_type: entity[ConfigColumnName.ENTITY_TYPE],
            target_type: entity[ConfigColumnName.TARGET_TYPE],
            client_meta: entity[ConfigColumnName.CLIENT_META] ?? undefined,
            config_value: entity[ConfigColumnName.CONFIG_VALUE] ?? undefined,
            status: entity[ConfigColumnName.STATUS],
            created_at: new Date(entity[ConfigColumnName.CREATED_AT]!).getTime(),
            created_by: entity[ConfigColumnName.CREATED_BY] ?? undefined,
            updated_at: new Date(entity[ConfigColumnName.UPDATED_AT]).getTime(),
            updated_by: entity[ConfigColumnName.UPDATED_BY] ?? undefined
        };
    }

    private async updateHash(configName: string) {
        await this.hashService.updateHash(
            {
                hash_entity_type: HashEntityType.CONFIG
            },
            {
                reference_id: configName,
                reference_id_type: HashUpdateReferenceType.CONFIG_NAME
            }
        );
    }
}
