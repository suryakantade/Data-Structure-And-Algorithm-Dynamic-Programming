import { Controller, Post, Body, Get, Query, Put, Req } from "@nestjs/common";
import { ApiHeaders, ApiTags } from "@nestjs/swagger";
import { ConfigService } from "./config.service";
import { PlatformInfo } from "../../common/models/platform-info";
import { getAppVersionFromHeaders, getPlatformFromHeaders, getTenantFromAppName } from "../../utils/api-header.util";
import { Request } from "express";
import { Constants } from "../../utils/constants";
import { ClientConfigService } from "./client-config.service";
import { ConfigInsertDto, ConfigPushDto } from "./dto/config-push.dto";
import { ConfigPullParamsDto } from "./dto/config-pull-params.dto";
import { ClientConfigPullRequestParamsDto } from "./dto/client-config-pull-request-params.dto";
import { ClientConfigPullRequestDto } from "./dto/client-config-pull-request.dto";
import { LogService } from "@khatabook/nestjs-logger";
import { ConfigPullResponseDto } from "./dto/config-pull-response.dto";
import { ClientConfigPullResponseDto } from "./dto/client-config-pull-response.dto";
import { IntraApi, PublicApi } from "../../common/decorators/authentication-decorators";

@ApiTags("APIs for CRUD operations on config")
@Controller({
    path: "config",
    version: "1"
})
export class ConfigController {
    constructor(
        private readonly configService: ConfigService,
        private readonly clientConfigService: ClientConfigService,
        private readonly log: LogService
    ) {
        log.setContext(ConfigController.name);
    }

    /**
     * API for creating a new config
     */
    @Post()
    @IntraApi()
    pushConfig(@Body() configInsertDto: ConfigInsertDto): Promise<ConfigPullResponseDto> {
        return this.configService.handlePushConfigApi(configInsertDto);
    }

    /**
     * API for updating an existing config
     */
    @Put()
    @IntraApi()
    putConfig(@Body() configPushDto: ConfigPushDto): Promise<ConfigPullResponseDto> {
        return this.configService.handlePutConfigApi(configPushDto);
    }

    /**
     * API for fetching a config. Config can be fetched using various identifiers like tenant, config_name etc, configs satisfying ALL the passed identifiers are returned.
     */
    @Get()
    @IntraApi()
    getConfig(@Query() params: ConfigPullParamsDto): Promise<ConfigPullResponseDto[]> {
        return this.configService.handleGetConfigApi(params);
    }

    /**
     * API for fetching client-config, it fetches static config as well as evaluates dynamic config using AB-experiment service
     */
    @Post("/get")
    @ApiHeaders([
        {
            name: Constants.HEADERS.X_KB_PLATFORM,
            required: false
        },
        {
            name: Constants.HEADERS.X_KB_APP_VERSION,
            required: false
        },
        {
            name: Constants.HEADERS.X_KB_APP_NAME,
            required: true
        }
    ])
    @PublicApi()
    getClientConfig(
        @Req() req: Request,
        @Query() params: ClientConfigPullRequestParamsDto,
        @Body() dto: ClientConfigPullRequestDto
    ): Promise<ClientConfigPullResponseDto> {
        const tenant = getTenantFromAppName(req);
        const platformInfo: PlatformInfo = {
            platform: getPlatformFromHeaders(req),
            appVersion: getAppVersionFromHeaders(req)
        };
        this.log.debug({ data: { tenant, platformInfo, userInfo: dto.meta } }, "Fetching client config");
        return this.clientConfigService.getConfigsForClient(tenant, platformInfo, params, dto);
    }
}
