import { initTestApplication } from "../../../../../../tests/common/baseclass.test.helper";
import { ConfigDbQueryTestHelper } from "./config-db-query.test.helper";
import { TestInitDataConfig } from "./config.test.types";

export async function init(): Promise<TestInitDataConfig> {
    const testInitData = await initTestApplication();
    const dbClient = testInitData.db.databaseClient;
    const dummyConfigDbObject = await ConfigDbQueryTestHelper.persistDummyConfig(dbClient);

    return {
        ...testInitData,
        dummyConfigDbObject: dummyConfigDbObject
    };
}
