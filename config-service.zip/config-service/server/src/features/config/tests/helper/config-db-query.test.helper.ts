import { Knex } from "knex";
import { v4 as uuidv4 } from "uuid";
import { DummyConfigDb } from "./config.test.types";

export class ConfigDbQueryTestHelper {
    static async persistDummyConfig(dbClient: Knex): Promise<DummyConfigDb> {
        const tableName = "config";
        const row = {
            id: uuidv4(),
            name: "TEST_CONFIG",
            target_type: "ANONYMOUS_ID",
            tenant: "KHATABOOK",
            entity_type: "DEFAULT",
            client_meta: {
                meta_key_1: "meta_value_1"
            },
            config_value: {
                test_key_1: "test_value_1",
                test_key_2: 2
            },
            status: "LIVE",
            created_by: null,
            updated_at: new Date().toISOString(),
            updated_by: null
        };
        await dbClient(tableName).insert(row);
        const insertedData = await dbClient(tableName).select().where({
            id: row.id
        });
        return insertedData[0];
    }
}
