import { v4 as uuidv4 } from "uuid";
import * as Joi from "joi";
import { Tenant } from "../../../../common/models/tenant.enum";
import { ConfigEntityType, ConfigStatus, ConfigTargetType } from "../../model/enums";
import { ConfigEntity, ConfigUpdateEntity } from "../../data/entity/config.entity";
import { DummyConfigDb } from "./config.test.types";
import { ConfigColumnName } from "../../data/entity/config.columns";

export const getConfigPullQueryParams = (
    tenant?: string,
    config_id?: string,
    config_name?: string,
    entity_type?: string
) => ({
    tenant,
    config_id,
    config_name,
    entity_type
});

export const getConfigPushDto = (overrideFields: any = {}) => {
    return {
        id: uuidv4(),
        name: "TEST_CONFIG_1",
        tenant: "KHATABOOK",
        entity_type: "DEFAULT",
        target_type: "ANONYMOUS_ID",
        client_meta: {
            meta_1: "meta_value"
        },
        config_value: {
            key1: "value1",
            key2: "value2"
        },
        status: "LIVE",
        ...overrideFields
    };
};

export const getConfigPutDto = (persistedConfig: DummyConfigDb) => {
    return {
        id: persistedConfig.id,
        name: persistedConfig.name,
        tenant: persistedConfig.tenant,
        entity_type: persistedConfig.entity_type,
        target_type: persistedConfig.target_type,
        // update client meta
        client_meta: {
            ...persistedConfig.client_meta,
            new_meta_key: "some value"
        },
        config_value: persistedConfig.config_value,
        status: persistedConfig.status
    };
};

export const getConfigInvalidPushDto = () => {
    return {
        id: "Not a UUID",
        name: "Name containing speci@l symbol",
        tenant: "WRONG_TENANT",
        entity_type: "WRONG_TYPE",
        target_type: "WRONG_TARGET",
        client_meta: "not an object",
        config_value: "not an object",
        status: "WRONG_STATUS"
    };
};

export const getInvalidConfigPullParamsDto = () => {
    return {
        tenant: "kb",
        config_id: "not-a-uuid",
        config_name: [123, 456]
    };
};

// provides a mock object, test using this should override fields on which it depends
export const getMockConfigEntity = (overrideFields: any = {}): ConfigEntity => {
    return {
        id: "646b7d64-3816-4c2c-bd11-91ffefb9dc76",
        name: "TEST_CONFIG",
        tenant: Tenant.KHATABOOK,
        entity_type: ConfigEntityType.DEFAULT,
        target_type: ConfigTargetType.USER_ID,
        client_meta: { cmk1: "cmv1" },
        config_value: { cvk1: "cvv1" },
        status: ConfigStatus.DRAFT,
        created_by: null,
        updated_at: new Date().toISOString(),
        updated_by: null,
        // override any passed properties
        ...overrideFields
    };
};

export const getMockConfigUpdateEntity = (overrideFields: any = {}): ConfigUpdateEntity => {
    const mockConfigEntity: ConfigUpdateEntity = getMockConfigEntity(overrideFields);
    delete mockConfigEntity[ConfigColumnName.CREATED_AT];
    delete mockConfigEntity[ConfigColumnName.CREATED_BY];
    return mockConfigEntity;
};

export const getClientConfigPullParams = (entityType?: string) => {
    return {
        entity_type: entityType
    };
};

export const getClientConfigPullHeaders = (appName: string = "khatabook") => {
    return {
        "x-kb-app-name": appName
    };
};

export const getClientConfigPullBody = (overrideFields: any = {}) => {
    return {
        meta: {
            user_id: uuidv4(),
            anonymous_id: uuidv4()
        },
        items: [
            {
                config_name: "C1"
            }
        ],
        // override any passed properties
        ...overrideFields
    };
};

export const getRolloutEvaluationResult = (overrideFields: any = {}) => {
    return {
        configuration: { k1: "v1" },
        systemData: { sk1: "sv1" },
        // override any passed properties
        ...overrideFields
    };
};

export const getClientConfigInvalidPullBody = () => {
    return {
        meta: {
            user_id: "not a uuid",
            anonymous_id: "invalid UUID"
        },
        items: [
            {
                config_name: 123,
                config_hash: 556
            }
        ]
    };
};

export const CONFIG_SCHEMA = {
    id: Joi.string().required(),
    name: Joi.string().required(),
    tenant: Joi.string()
        .required()
        .valid(...Object.values(Tenant)),
    entity_type: Joi.string()
        .required()
        .valid(...Object.values(ConfigEntityType)),
    target_type: Joi.string()
        .required()
        .valid(...Object.values(ConfigTargetType)),
    client_meta: Joi.object(),
    config_value: Joi.object(),
    status: Joi.string()
        .required()
        .valid(...Object.values(ConfigStatus)),
    created_at: Joi.number().required(),
    created_by: Joi.string(),
    updated_at: Joi.number().required(),
    updated_by: Joi.string()
};

export const CLIENT_CONFIG_SCHEMA = {
    has_more: Joi.boolean().required(),
    items: Joi.array()
        .items({
            id: Joi.string().required(),
            name: Joi.string().required(),
            tenant: Joi.string()
                .required()
                .valid(...Object.values(Tenant)),
            entity_type: Joi.string()
                .required()
                .valid(...Object.values(ConfigEntityType)),
            client_meta: Joi.object(),
            config_value: Joi.object(),
            system_data: Joi.object()
        })
        .required()
};
