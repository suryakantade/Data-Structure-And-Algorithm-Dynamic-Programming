import { TestInitData } from "../../../../../../tests/common/types.test.helper";

export interface TestInitDataConfig extends TestInitData {
    dummyConfigDbObject: DummyConfigDb;
}

export interface DummyConfigDb {
    id: string;
    name: string;
    target_type: string;
    tenant: string;
    entity_type: string;
    client_meta: object;
    config_value: object;
    status: string;
    created_at: string;
    updated_at: string;
    created_by: string | null;
    updated_by: string | null;
}
