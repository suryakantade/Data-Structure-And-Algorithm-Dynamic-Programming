import { INestApplication } from "@nestjs/common";
import { ApiNetworkServiceTestHelper } from "../../../../../../tests/common/api-network-service.test.helper";
import { CommonSetupTestHelper } from "../../../../../../tests/common/common-setup.test.helper";

export async function getConfig(app: INestApplication, params: object) {
    return await ApiNetworkServiceTestHelper.get({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/config",
        params,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}

export async function postConfig(app: INestApplication, body: object) {
    return await ApiNetworkServiceTestHelper.post({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/config",
        body,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}

export async function putConfig(app: INestApplication, body: object) {
    return await ApiNetworkServiceTestHelper.put({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/config",
        body,
        headers: {
            "x-api-token": CommonSetupTestHelper.getIntraAuthApiToken()
        }
    });
}

export async function getClientConfig(app: INestApplication, params: object, headers: object, body: object) {
    return await ApiNetworkServiceTestHelper.post({
        app: app.getHttpServer(),
        endpoints: "/config-service/v1/config/get",
        params,
        headers,
        body
    });
}
