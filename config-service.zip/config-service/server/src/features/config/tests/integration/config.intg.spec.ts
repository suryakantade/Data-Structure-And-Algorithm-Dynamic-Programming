import { init } from "../helper/config-baseclass.test.helper";
import {
    CONFIG_SCHEMA,
    getConfigInvalidPushDto,
    getConfigPullQueryParams,
    getConfigPushDto,
    getConfigPutDto,
    getInvalidConfigPullParamsDto
} from "../helper/config.data.test.helper";
import { getConfig, postConfig, putConfig } from "../helper/config-api.test.helper";
import { TestInitDataConfig } from "../helper/config.test.types";
import { HashService } from "../../../hash/hash.service";
import { ConfigRepo } from "../../data/config.repo";
import { v4 as uuidv4 } from "uuid";
import { TestUtility } from "../../../../../../tests/common/test.utility";
import { ConfigService } from "../../config.service";
import { teardownTestApplication } from "../../../../../../tests/common/baseclass.test.helper";

describe("Integration tests for config logic", () => {
    let initData: TestInitDataConfig;
    let hashService: HashService;
    let configRepo: ConfigRepo;
    let configService: ConfigService;

    beforeEach(async () => {
        initData = await init();
        hashService = await initData.app.resolve(HashService);
        configRepo = await initData.app.resolve(ConfigRepo);
        configService = await initData.app.resolve(ConfigService);
    }, 50000);

    describe("API: /v1/config", () => {
        describe("API: POST /, Insert new config", () => {
            test("should pass when correct input is passed", async () => {
                const body = getConfigPushDto({ id: undefined });
                const hashUpdateSpy = jest.spyOn(hashService, "updateHash");
                const configUpsertSpy = jest.spyOn(configRepo, "upsertConfig");
                const response = await postConfig(initData.app, body);
                expect(response.statusCode).toBe(201);
                TestUtility.joiValidator(CONFIG_SCHEMA, response.body);
                // verify hashing related logic
                expect(hashUpdateSpy).toHaveBeenCalledWith(
                    expect.anything(),
                    expect.objectContaining({
                        reference_id: body.name
                    })
                );
                // hash must be updated before upserting the config in DB
                expect(hashUpdateSpy.mock.invocationCallOrder[0]).toBeLessThan(
                    configUpsertSpy.mock.invocationCallOrder[0]
                );
            });

            test("should fail when body contract is not correct", async () => {
                const response = await postConfig(initData.app, getConfigInvalidPushDto());
                expect(response.statusCode).toBe(400);
                expect(response.body.message.length).toBe(7); // passed DTO with 7 incorrect fields
            });

            test("should fail if config already exists", async () => {
                const body = getConfigPushDto();
                body.name = initData.dummyConfigDbObject.name;
                const response = await postConfig(initData.app, body);
                expect(response.statusCode).toBe(400);
                expect(response.body.message.includes("already exists")).toBeTruthy();
            });
        });

        describe("API: PUT /, Update config", () => {
            test("should pass when correct input is passed", async () => {
                const body = getConfigPutDto(initData.dummyConfigDbObject);
                const hashUpdateSpy = jest.spyOn(hashService, "updateHash");
                const configUpsertSpy = jest.spyOn(configRepo, "upsertConfig");
                const response = await putConfig(initData.app, body);
                expect(response.statusCode).toBe(200);
                TestUtility.joiValidator(CONFIG_SCHEMA, response.body);
                // verify hashing related logic
                expect(hashUpdateSpy).toHaveBeenCalledWith(
                    expect.anything(),
                    expect.objectContaining({
                        reference_id: body.name
                    })
                );
                // hash must be updated before upserting the config in DB
                expect(hashUpdateSpy.mock.invocationCallOrder[0]).toBeLessThan(
                    configUpsertSpy.mock.invocationCallOrder[0]
                );
            });

            test("should fail when body contract is not correct", async () => {
                const response = await putConfig(initData.app, getConfigInvalidPushDto());
                expect(response.statusCode).toBe(400);
                expect(response.body.message.length).toBe(8);
            });

            test("should fail when update is invalid", async () => {
                const body = getConfigPutDto(initData.dummyConfigDbObject);
                // dummy config persisted in DB is in LIVE state, changing target_type is not allowed
                body.target_type = "USER_ID";
                const response = await putConfig(initData.app, body);
                expect(response.statusCode).toBe(400);
                expect(response.body.message.includes("cannot be updated")).toBeTruthy();
            });

            test("should fail when config does not exist", async () => {
                const body = getConfigPutDto(initData.dummyConfigDbObject);
                body.id = uuidv4();
                const response = await putConfig(initData.app, body);
                expect(response.statusCode).toBe(400);
                expect(response.body.message.includes("does not exist")).toBeTruthy();
            });
        });

        describe("API: GET /, Pull config", () => {
            test.each([
                ["fetch by tenant", false, false, false],
                ["fetch by entity_type", false, false, true],
                ["fetch by config_id", true, false, false],
                ["fetch by config_name", false, true, false]
            ])(
                "verify %s",
                async (
                    _: string,
                    isConfigIdPassed: boolean,
                    isConfigNamePassed: boolean,
                    isEntityTypePassed: boolean
                ) => {
                    const tenant = initData.dummyConfigDbObject.tenant;
                    const entityType = isEntityTypePassed ? initData.dummyConfigDbObject.entity_type : undefined;
                    const configId = isConfigIdPassed ? initData.dummyConfigDbObject.id : undefined;
                    const configName = isConfigNamePassed ? initData.dummyConfigDbObject.name : undefined;

                    const response = await getConfig(
                        initData.app,
                        getConfigPullQueryParams(tenant, configId, configName, entityType)
                    );
                    expect(response.statusCode).toBe(200);
                    expect(response.body.length).toEqual(1);
                    TestUtility.joiValidator(CONFIG_SCHEMA, response.body[0]);
                    expect(response.body[0]).toEqual({
                        ...initData.dummyConfigDbObject,
                        created_at: new Date(initData.dummyConfigDbObject.created_at).getTime(),
                        updated_at: new Date(initData.dummyConfigDbObject.updated_at).getTime(),
                        created_by: initData.dummyConfigDbObject.created_by || undefined,
                        updated_by: initData.dummyConfigDbObject.updated_by || undefined
                    });
                }
            );

            test("should fail when query params does not follow contract", async () => {
                const response = await getConfig(initData.app, getInvalidConfigPullParamsDto());
                expect(response.statusCode).toBe(400);
                expect(response.body.message.length).toBe(3);
            });
        });
    });

    describe("Internal functions not exposed through API but used by other modules", () => {
        test("test getConfig() for all possibilities of arguments", async () => {
            const funcArgs = [0, 1, 2, 3];
            const allPossibilities = TestUtility.getPowerSetOfArray(funcArgs);
            for (let args of allPossibilities) {
                if (args.length === 0) {
                    return;
                }
                let tenant, configId, configName, entityType;
                if (args.includes(0)) {
                    tenant = initData.dummyConfigDbObject.tenant;
                }
                if (args.includes(1)) {
                    configId = initData.dummyConfigDbObject.id;
                }
                if (args.includes(2)) {
                    configName = initData.dummyConfigDbObject.name;
                }
                if (args.includes(3)) {
                    entityType = initData.dummyConfigDbObject.entity_type;
                }
                const configs = await configService.getConfigs(tenant, configId, configName, entityType);
                expect(configs.length).toBe(1);
            }
            initData.dummyConfigDbObject;
        });
    });

    afterEach(async () => {
        await teardownTestApplication(initData.app, initData.db.databaseClient);
    }, 50000);
});
