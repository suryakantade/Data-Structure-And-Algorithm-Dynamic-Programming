import { init } from "../helper/config-baseclass.test.helper";
import { TestInitDataConfig } from "../helper/config.test.types";
import { getClientConfig } from "../helper/config-api.test.helper";
import {
    CLIENT_CONFIG_SCHEMA,
    getClientConfigInvalidPullBody,
    getClientConfigPullBody,
    getClientConfigPullHeaders,
    getClientConfigPullParams
} from "../helper/config.data.test.helper";
import { TestUtility } from "../../../../../../tests/common/test.utility";
import { RolloutEvaluationService } from "../../../rollout/rollout-evaluation.service";
import { Config } from "../../model/config";
import { teardownTestApplication } from "../../../../../../tests/common/baseclass.test.helper";

describe("Integration tests for client-config logic", () => {
    let initData: TestInitDataConfig;
    let rolloutEvaluationService: RolloutEvaluationService;

    beforeEach(async () => {
        initData = await init();
        rolloutEvaluationService = await initData.app.resolve(RolloutEvaluationService);
        jest.spyOn(rolloutEvaluationService, "evaluateRolloutsForConfigs").mockImplementation(
            async (configs: Config[], platformInfo, userId, anonymousId) => {
                return configs.reduce((tillNow, config) => {
                    return {
                        ...tillNow,
                        [config.id]: {
                            systemData: {}
                        }
                    };
                }, {});
            }
        );
    }, 50000);

    describe("API: /config/v1/get", () => {
        test.each([
            ["fetch by only entity_type", true, false],
            ["fetch by only config_name", false, true],
            ["fetch by both entity_type and config_name", true, true]
        ])(
            "should pass when input is correct and %s",
            async (_, shouldPassEntityType: boolean, shouldPassConfigName: boolean) => {
                const persistedObject = initData.dummyConfigDbObject;
                const response = await getClientConfig(
                    initData.app,
                    getClientConfigPullParams(shouldPassEntityType ? persistedObject.entity_type : undefined),
                    getClientConfigPullHeaders(),
                    getClientConfigPullBody({
                        items: shouldPassConfigName ? [{ config_name: persistedObject.name }] : []
                    })
                );
                const expectedResponse = {
                    has_more: false,
                    items: [
                        {
                            id: persistedObject.id,
                            name: persistedObject.name,
                            tenant: persistedObject.tenant,
                            entity_type: persistedObject.entity_type,
                            client_meta: persistedObject.client_meta,
                            config_value: persistedObject.config_value,
                            system_data: {}
                        }
                    ]
                };
                expect(response.statusCode).toBe(201);
                TestUtility.joiValidator(CLIENT_CONFIG_SCHEMA, response.body);
                expect(response.body).toMatchObject(expectedResponse);
            }
        );

        test.each([
            [
                "incorrect entity_type passed",
                getClientConfigPullParams("incorrect"),
                getClientConfigPullHeaders(),
                getClientConfigPullBody(),
                () => {}
            ],
            ["app name header not passed", getClientConfigPullParams(), {}, getClientConfigPullBody(), () => {}],
            [
                "incorrect app name header passed",
                getClientConfigPullParams(),
                getClientConfigPullHeaders("kb"),
                getClientConfigPullBody(),
                (response) => expect(response.body.message.includes("Unable to deduce tenant"))
            ],
            [
                "incorrect body schema passed",
                getClientConfigPullParams(),
                getClientConfigPullHeaders(),
                getClientConfigInvalidPullBody(),
                (response: any) => expect(response.body.message.length).toBe(4)
            ],
            [
                "neither user_id, nor anonymous_id is passed",
                getClientConfigPullParams(),
                getClientConfigPullHeaders(),
                getClientConfigPullBody({ meta: {} }),
                (response) =>
                    expect(response.body.message.includes("one out of user ID and anonymous ID must be passed"))
            ],
            [
                "non existent config name passed",
                getClientConfigPullParams(),
                getClientConfigPullHeaders(),
                getClientConfigPullBody({ items: [{ config_name: "SOME_RANDOM_NAME" }] }),
                (response) => expect(response.body.message.includes("Invalid config name")).toBeTruthy()
            ]
        ])(
            "verify that it should fail when %s",
            async (
                _: string,
                params: object,
                headers: object,
                body: object,
                additionalAssertions: (response: any) => void
            ) => {
                const response = await getClientConfig(initData.app, params, headers, body);
                expect(response.statusCode).toBe(400);
                additionalAssertions(response);
            }
        );
    });

    afterEach(async () => {
        await teardownTestApplication(initData.app, initData.db.databaseClient);
    }, 50000);
});
