import { ConfigValidationService } from "../../config-validation.service";
import { ConfigStatus } from "../../model/enums";
import { ConfigRepo } from "../../data/config.repo";
import { getMockConfigEntity, getMockConfigUpdateEntity } from "../helper/config.data.test.helper";
import { WrongInput } from "../../../../common/error/WrongInput";
import { ConfigEntity, ConfigUpdateEntity } from "../../data/entity/config.entity";
import { v4 as uuidv4 } from "uuid";
import { initTestModule } from "../../../../../../tests/common/baseclass.test.helper";

describe("Unit tests for config-validation-service", () => {
    let configValidationService: ConfigValidationService;
    let configRepo: ConfigRepo;

    beforeEach(async () => {
        const module = await initTestModule({ providers: [ConfigValidationService] });
        configValidationService = await module.resolve(ConfigValidationService);
        configRepo = await module.resolve(ConfigRepo);
    }, 50000);

    describe("Validate config status update", () => {
        type TestParams = {
            currentStatus: ConfigStatus;
            newStatus: ConfigStatus;
            isValid: boolean;
        };

        const validStatusTransitions: Record<ConfigStatus, ConfigStatus[]> = {
            [ConfigStatus.DRAFT]: [ConfigStatus.LIVE, ConfigStatus.DELETED],
            [ConfigStatus.LIVE]: [ConfigStatus.DELETED],
            [ConfigStatus.DELETED]: []
        };

        let testCases: TestParams[] = [];
        for (let e1 in ConfigStatus) {
            const currentStatus = e1 as ConfigStatus;
            for (let e2 in ConfigStatus) {
                const newStatus = e2 as ConfigStatus;
                if (e1 === e2) {
                    continue;
                }
                testCases.push({
                    currentStatus,
                    newStatus,
                    isValid: validStatusTransitions[currentStatus].includes(newStatus)
                });
            }
        }

        test.each(testCases)(
            `verify that config status update from $currentStatus to $newStatus is $isValid`,
            async ({ currentStatus, newStatus, isValid }: TestParams) => {
                const existingEntity: ConfigEntity = getMockConfigEntity({ status: currentStatus });
                const updatedEntity: ConfigUpdateEntity = getMockConfigUpdateEntity({ status: newStatus });

                jest.spyOn(configRepo, "getConfigByTenantAndIdAndNameAndEntityType").mockResolvedValue([
                    existingEntity
                ]);
                const func = () => {
                    return configValidationService.validateConfigUpdate(updatedEntity);
                };
                if (isValid) {
                    await expect(func()).resolves.toBe(undefined);
                } else {
                    await expect(func()).rejects.toThrowError(WrongInput);
                }
            }
        );
    });

    describe("Validate config updates across different status", () => {
        test.each([
            ["id", [], uuidv4(), uuidv4()],
            ["name", [], "C-1", "C-2"],
            ["tenant", [ConfigStatus.DRAFT], "KHATABOOK", "CASHBOOK"],
            ["entity_type", [ConfigStatus.DRAFT], "FEATURE", "DEFAULT"],
            ["target_type", [ConfigStatus.DRAFT], "USER_ID", "ANONYMOUS_ID"],
            ["client_meta", [ConfigStatus.DRAFT, ConfigStatus.LIVE], { key: "value" }, { key: "value2" }],
            ["config_value", [ConfigStatus.DRAFT, ConfigStatus.LIVE], null, { key: "value" }],
            [
                "updated_at",
                [ConfigStatus.DRAFT, ConfigStatus.LIVE, ConfigStatus.DELETED],
                new Date("2022-04-16").toISOString(),
                new Date("2022-04-17").toISOString()
            ],
            ["updated_by", [ConfigStatus.DRAFT, ConfigStatus.LIVE, ConfigStatus.DELETED], null, "abcd"]
        ])(
            "verify that %s can only be updated when config status is %s",
            async (fieldName: string, updateAllowedForStatus: ConfigStatus[], currentValue: any, updatedValue: any) => {
                // iterate over all config status
                for (let enumValue in ConfigStatus) {
                    const status = enumValue as ConfigStatus;
                    const existingEntity: ConfigEntity = getMockConfigEntity({
                        status,
                        [fieldName]: currentValue
                    });

                    const updatedEntity: ConfigUpdateEntity = getMockConfigUpdateEntity({
                        status,
                        [fieldName]: updatedValue
                    });

                    jest.spyOn(configRepo, "getConfigByTenantAndIdAndNameAndEntityType").mockResolvedValue([
                        existingEntity
                    ]);
                    const func = () => {
                        return configValidationService.validateConfigUpdate(updatedEntity);
                    };

                    if (updateAllowedForStatus.includes(status)) {
                        // shouldn't fail
                        await expect(func()).resolves.toBe(undefined);
                    } else {
                        // should fail
                        await expect(func()).rejects.toThrowError(WrongInput);
                        await expect(func()).rejects.toThrow("cannot be updated");
                    }
                }
            }
        );

        test.each([
            [
                "structure changing update for client_meta should not be allowed in LIVE status",
                "client_meta",
                { a: 123, b: 456 },
                { a: 889 },
                ConfigStatus.LIVE,
                false,
                "must match"
            ],
            [
                "structure changing update for client_meta should be allowed in DRAFT status",
                "client_meta",
                { a: 123, b: 456 },
                { a: 889 },
                ConfigStatus.DRAFT,
                true,
                undefined
            ],
            [
                "structure changing update for config_value should not be allowed in LIVE status",
                "config_value",
                { a: 123, b: 456 },
                { a: 889 },
                ConfigStatus.LIVE,
                false,
                "must match"
            ],
            [
                "structure changing update for config_value should be allowed in DRAFT status",
                "config_value",
                { a: 123, b: 456 },
                { a: 889 },
                ConfigStatus.DRAFT,
                true,
                undefined
            ]
        ])(
            "verify that %s",
            async (
                _,
                fieldName: string,
                currentValue: any,
                updatedValue: any,
                status: ConfigStatus,
                isUpdateValid: boolean,
                expectedErrorMessage?: string
            ) => {
                const existingEntity: ConfigEntity = getMockConfigEntity({
                    status,
                    [fieldName]: currentValue
                });

                const updatedEntity: ConfigUpdateEntity = getMockConfigUpdateEntity({
                    status,
                    [fieldName]: updatedValue
                });

                jest.spyOn(configRepo, "getConfigByTenantAndIdAndNameAndEntityType").mockResolvedValue([
                    existingEntity
                ]);
                const func = () => {
                    return configValidationService.validateConfigUpdate(updatedEntity);
                };

                if (isUpdateValid) {
                    // shouldn't fail
                    await expect(func()).resolves.toBe(undefined);
                } else {
                    // should fail
                    await expect(func()).rejects.toThrowError(WrongInput);
                    await expect(func()).rejects.toThrow(expectedErrorMessage);
                }
            }
        );
    });
});
