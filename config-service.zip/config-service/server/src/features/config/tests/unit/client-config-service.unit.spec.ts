import { ClientConfigService } from "../../client-config.service";
import { RolloutEvaluationService } from "../../../rollout/rollout-evaluation.service";
import { ConfigRepo } from "../../data/config.repo";
import { Tenant } from "../../../../common/models/tenant.enum";
import { v4 as uuidv4 } from "uuid";
import { WrongInput } from "../../../../common/error/WrongInput";
import {
    getClientConfigPullBody,
    getMockConfigEntity,
    getRolloutEvaluationResult
} from "../helper/config.data.test.helper";
import { ConfigEntity } from "../../data/entity/config.entity";
import { ConfigStatus, ConfigTargetType } from "../../model/enums";
import { Config } from "../../model/config";
import { RolloutEvaluationResult } from "../../../rollout/model/rollout-evaluation-result";
import { initTestModule } from "../../../../../../tests/common/baseclass.test.helper";

describe("Unit tests for client-config-service", () => {
    let rolloutEvaluationService: RolloutEvaluationService;
    let configRepo: ConfigRepo;
    let clientConfigService: ClientConfigService;

    beforeEach(async () => {
        const module = await initTestModule({ providers: [ClientConfigService] });
        rolloutEvaluationService = await module.resolve(RolloutEvaluationService);
        configRepo = await module.resolve(ConfigRepo);
        clientConfigService = await module.resolve(ClientConfigService);

        jest.spyOn(rolloutEvaluationService, "evaluateRolloutsForConfigs").mockImplementation(
            (configs: Config[], platformInfo, userId, anonymousId) => {
                const map = configs.reduce((tillNow, config) => {
                    return {
                        ...tillNow,
                        [config.id]: {
                            systemData: {}
                        }
                    };
                }, {});
                return Promise.resolve(map);
            }
        );
    }, 50000);

    describe("when config names are explicitly passed", () => {
        const configName = "C1";
        test.each([
            [
                "error is thrown when config is in DRAFT status",
                getMockConfigEntity({ name: configName, status: ConfigStatus.DRAFT }),
                getClientConfigPullBody({ items: [{ config_name: configName }] }),
                "is not LIVE"
            ],
            [
                "error is thrown when config is in DELETED status",
                getMockConfigEntity({ name: configName, status: ConfigStatus.DELETED }),
                getClientConfigPullBody({ items: [{ config_name: configName }] }),
                "is not LIVE"
            ],
            [
                "error is thrown when config is of target type USER_ID but user ID not passed",
                getMockConfigEntity({
                    name: configName,
                    target_type: ConfigTargetType.USER_ID,
                    status: ConfigStatus.LIVE
                }),
                getClientConfigPullBody({ items: [{ config_name: configName }], meta: { anonymous_id: uuidv4() } }),
                "user ID not passed"
            ],
            [
                "error is thrown when config is of target type ANONYMOUS_ID but anonymous ID not passed",
                getMockConfigEntity({
                    name: configName,
                    target_type: ConfigTargetType.ANONYMOUS_ID,
                    status: ConfigStatus.LIVE
                }),
                getClientConfigPullBody({ items: [{ config_name: configName }], meta: { user_id: uuidv4() } }),
                "anonymous ID not passed"
            ]
        ])("verify that %s", async (_, mockEntity: ConfigEntity, reqBody: any, expectedMessage: string) => {
            jest.spyOn(configRepo, "getConfigByTenantAndIdAndNameAndEntityType").mockImplementation(async () => {
                return [mockEntity];
            });
            const func = () => {
                return clientConfigService.getConfigsForClient(Tenant.KHATABOOK, {}, {}, reqBody);
            };
            await expect(func()).rejects.toThrowError(WrongInput);
            await expect(func()).rejects.toThrowError(expectedMessage);
        });
    });

    describe("when config names are not passed and fetched by tenant (same scenarios applicable when fetched by entity type)", () => {
        test.each([
            [
                "DRAFT configs are not returned",
                [getMockConfigEntity({ status: ConfigStatus.DRAFT })],
                getClientConfigPullBody({ items: [] }),
                0
            ],
            [
                "DELETED configs are not returned",
                [getMockConfigEntity({ status: ConfigStatus.DELETED })],
                getClientConfigPullBody({ items: [] }),
                0
            ],
            [
                "LIVE configs are returned",
                [getMockConfigEntity({ status: ConfigStatus.LIVE, target_type: ConfigTargetType.USER_ID })],
                getClientConfigPullBody({ meta: { user_id: uuidv4() }, items: [] }),
                1
            ],
            [
                "if user_id is passed then configs based on anonymous_id should not be fetched",
                [getMockConfigEntity({ status: ConfigStatus.LIVE, target_type: ConfigTargetType.ANONYMOUS_ID })],
                getClientConfigPullBody({ meta: { user_id: uuidv4() }, items: [] }),
                0
            ],
            [
                "if anonymous_id is passed then configs based on user_id should not be fetched",
                [getMockConfigEntity({ status: ConfigStatus.LIVE, target_type: ConfigTargetType.USER_ID })],
                getClientConfigPullBody({ meta: { anonymous_id: uuidv4() }, items: [] }),
                0
            ],
            [
                "if both user_id and anonymous_id are passed then both types of configs should be fetched",
                [
                    getMockConfigEntity({
                        id: uuidv4(),
                        status: ConfigStatus.LIVE,
                        target_type: ConfigTargetType.USER_ID
                    }),
                    getMockConfigEntity({
                        id: uuidv4(),
                        status: ConfigStatus.LIVE,
                        target_type: ConfigTargetType.ANONYMOUS_ID
                    })
                ],
                getClientConfigPullBody({ meta: { anonymous_id: uuidv4(), user_id: uuidv4() }, items: [] }),
                2
            ]
        ])("verify that %s", async (_, mockEntities: ConfigEntity[], reqBody: any, expectedNumberOfConfigs: number) => {
            jest.spyOn(configRepo, "getConfigByTenantAndIdAndNameAndEntityType").mockImplementation(async () => {
                return mockEntities;
            });
            const { has_more, items } = await clientConfigService.getConfigsForClient(
                Tenant.KHATABOOK,
                {},
                {},
                reqBody
            );
            expect(has_more).toBeFalsy(); // pagination not supported
            expect(items.length).toBe(expectedNumberOfConfigs);
        });
    });

    describe("Rollout scenarios", () => {
        test.each([
            [
                "configuration returned by rollout should override static config_value",
                getMockConfigEntity({ status: ConfigStatus.LIVE }),
                getRolloutEvaluationResult({ configuration: { k1: "v1" } })
            ],
            [
                "static config_value should be returned if rollout does not return configuration",
                getMockConfigEntity({ status: ConfigStatus.LIVE }),
                getRolloutEvaluationResult({ configuration: undefined })
            ],
            [
                "client_meta and config_value should not be returned if no rollout is applicable for the user",
                getMockConfigEntity({ status: ConfigStatus.LIVE }),
                undefined
            ]
        ])("verify that %s", async (_, mockConfigEntity: ConfigEntity, rolloutEvalResult?: RolloutEvaluationResult) => {
            jest.spyOn(configRepo, "getConfigByTenantAndIdAndNameAndEntityType").mockImplementation(async () => {
                return [mockConfigEntity];
            });
            jest.spyOn(rolloutEvaluationService, "evaluateRolloutsForConfigs").mockImplementation(async () => {
                return {
                    [mockConfigEntity.id]: rolloutEvalResult
                };
            });
            const { items } = await clientConfigService.getConfigsForClient(
                Tenant.KHATABOOK,
                {},
                {},
                getClientConfigPullBody({ meta: { user_id: uuidv4(), anonymous_id: uuidv4() }, items: [] })
            );
            expect(items.length).toBe(1);
            const response = items[0];
            const expectedOutput = {};
            if (rolloutEvalResult) {
                expectedOutput["client_meta"] = mockConfigEntity.client_meta;
                expectedOutput["system_data"] = rolloutEvalResult.systemData;
                if (rolloutEvalResult.configuration) {
                    expectedOutput["config_value"] = rolloutEvalResult.configuration;
                } else {
                    expectedOutput["config_value"] = mockConfigEntity.config_value;
                }
            }
            expect(response).toEqual(expect.objectContaining(expectedOutput));
        });
    });
});
