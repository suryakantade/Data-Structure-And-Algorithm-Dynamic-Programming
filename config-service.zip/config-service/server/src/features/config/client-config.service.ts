import { Injectable } from "@nestjs/common";
import { Tenant } from "../../common/models/tenant.enum";
import { PlatformInfo } from "../../common/models/platform-info";
import { WrongInput } from "../../common/error/WrongInput";
import { ConfigEntityType, ConfigStatus, ConfigTargetType } from "./model/enums";
import { ConfigEntity } from "./data/entity/config.entity";
import { ConfigColumnName } from "./data/entity/config.columns";
import { Config } from "./model/config";
import { ConfigRepo } from "./data/config.repo";
import { RolloutEvaluationService } from "../rollout/rollout-evaluation.service";
import { LogService } from "@khatabook/nestjs-logger";
import { ClientConfigPullRequestParamsDto } from "./dto/client-config-pull-request-params.dto";
import { ClientConfigPullRequestDto } from "./dto/client-config-pull-request.dto";
import { ClientConfigPullResponseDto, ClientConfigPullResponseItemDto } from "./dto/client-config-pull-response.dto";
import { IllegalState } from "../../common/error/IllegalState";

@Injectable()
export class ClientConfigService {
    constructor(
        private readonly configRepo: ConfigRepo,
        private readonly rolloutEvaluationService: RolloutEvaluationService,
        private readonly log: LogService
    ) {
        log.setContext(ClientConfigService.name);
    }

    async getConfigsForClient(
        tenant: Tenant,
        platformInfo: PlatformInfo,
        params: ClientConfigPullRequestParamsDto,
        dto: ClientConfigPullRequestDto
    ): Promise<ClientConfigPullResponseDto> {
        const { user_id: userId, anonymous_id: anonymousId } = dto.meta;
        if (!userId && !anonymousId) {
            throw new WrongInput("At-least one out of user ID and anonymous ID must be passed");
        }

        const { entity_type: entityType } = params;
        const configNames = dto.items.map((x) => x.config_name);
        const configEntities = await this.getConfigEntities(tenant, configNames, entityType, userId, anonymousId);
        return this.evaluateConfigs(configEntities, platformInfo, userId, anonymousId);
    }

    private async getConfigEntities(
        tenant: Tenant,
        configNames: string[],
        entityType?: ConfigEntityType,
        userId?: string,
        anonymousId?: string
    ): Promise<ConfigEntity[]> {
        const configEntities: ConfigEntity[] = await this.configRepo.getConfigByTenantAndIdAndNameAndEntityType(
            tenant,
            undefined,
            configNames,
            entityType
        );

        if (configNames.length !== 0) {
            // If config names were pass explicitly then do validations like config must be LIVE etc.
            this.validateConfigs(tenant, configNames, configEntities, userId, anonymousId, entityType);
            return configEntities;
        } else {
            // filter out non-LIVE configs and configs that does not support given target type etc.
            return configEntities.filter((entity) => {
                if (entity[ConfigColumnName.STATUS] !== ConfigStatus.LIVE) {
                    this.log.debug(
                        {
                            data: {
                                configId: entity.id,
                                status: entity.status
                            }
                        },
                        "Skipping config because it is not LIVE"
                    );
                    return false;
                }
                // target type validations
                if (userId && anonymousId) {
                    // since both IDs are provided so all configs are okay
                } else if (userId) {
                    this.log.debug(
                        {
                            data: {
                                configId: entity.id,
                                targetType: entity.target_type
                            }
                        },
                        "Skipping config because target type and passed UUID are different"
                    );
                    // only user id provided, configs of target type anonymous ID should be filtered out
                    if (entity[ConfigColumnName.TARGET_TYPE] !== ConfigTargetType.USER_ID) {
                        return false;
                    }
                } else if (anonymousId) {
                    this.log.debug(
                        {
                            data: {
                                configId: entity.id,
                                targetType: entity.target_type
                            }
                        },
                        "Skipping config because target type and passed UUID are different"
                    );
                    // only anonymous id provided, configs of target type user ID should be filtered out
                    if (entity[ConfigColumnName.TARGET_TYPE] !== ConfigTargetType.ANONYMOUS_ID) {
                        return false;
                    }
                } else {
                    // invalid state, if both are null then code shouldn't have reached here.
                    throw new IllegalState("At-least one of userId and anonymousId must be present");
                }
                return true;
            });
        }
    }

    private validateConfigs(
        tenant: string,
        configNames: string[],
        configEntities: ConfigEntity[],
        userId?: string,
        anonymousId?: string,
        entityType?: string
    ) {
        // keeping "undefined" in Record value to signify that undefined can be returned for some strings
        const configNameToConfigEntityMap: Record<string, ConfigEntity | undefined> = {};
        configEntities.forEach((configEntity) => {
            configNameToConfigEntityMap[configEntity[ConfigColumnName.NAME]] = configEntity;
        });
        configNames.forEach((configName) => {
            const entity = configNameToConfigEntityMap[configName];
            if (!entity) {
                throw new WrongInput(
                    `Invalid config name. Config with name ${configName} does not exist for tenant ${tenant} ${
                        entityType ? `and entity_type ${entityType}` : ""
                    }`
                );
            }

            if (entity[ConfigColumnName.STATUS] !== ConfigStatus.LIVE) {
                throw new WrongInput(`Config ${configName} is not LIVE.`);
            }

            if (!userId && entity[ConfigColumnName.TARGET_TYPE] === ConfigTargetType.USER_ID) {
                throw new WrongInput(`Config ${configName} is based on USER_ID but user ID not passed`);
            }

            if (!anonymousId && entity[ConfigColumnName.TARGET_TYPE] === ConfigTargetType.ANONYMOUS_ID) {
                throw new WrongInput(`Config ${configName} is based on ANONYMOUS_ID but anonymous ID not passed`);
            }
        });
    }

    private async evaluateConfigs(
        configEntities: ConfigEntity[],
        platformInfo: PlatformInfo,
        userId?: string,
        anonymousId?: string
    ): Promise<ClientConfigPullResponseDto> {
        const configModels: Config[] = configEntities.map(this.getConfigModelFromConfigEntity);
        const rolloutEvaluationResultsMap = await this.rolloutEvaluationService.evaluateRolloutsForConfigs(
            configModels,
            platformInfo,
            userId,
            anonymousId
        );

        const configResponseItems: ClientConfigPullResponseItemDto[] = configModels.map((config) => {
            const { id: configId } = config;
            const rolloutEvaluationForConfig = rolloutEvaluationResultsMap[configId];
            let clientMeta: object | undefined = undefined;
            let configValue: object | undefined = undefined;
            let systemData: object | undefined = undefined;
            if (rolloutEvaluationForConfig) {
                // there is at-least one rollout applicable for the user
                const rolloutConfig = rolloutEvaluationForConfig.configuration;
                // Implicit assumption, rollout config should either be null/undefined or it should contain JSON with at-least one property, empty json is not allowed.
                // If rollout attached to experiment then use that config value otherwise use static(default) value stored in config-service DB
                configValue = rolloutConfig ? rolloutConfig : config.configValue;
                clientMeta = config.clientMeta;
                systemData = rolloutEvaluationForConfig.systemData;
            } else {
                // no rollout is applicable for the user
                this.log.debug({ data: { userId, anonymousId, configName: config.name } }, "No rollout applicable");
            }

            return {
                id: config.id,
                name: config.name,
                tenant: config.tenant,
                entity_type: config.entityType,
                client_meta: clientMeta,
                config_value: configValue,
                system_data: systemData
            };
        });

        return {
            has_more: false,
            items: configResponseItems
        };
    }

    private getConfigModelFromConfigEntity(entity: ConfigEntity): Config {
        return {
            id: entity[ConfigColumnName.ID],
            name: entity[ConfigColumnName.NAME],
            tenant: entity[ConfigColumnName.TENANT],
            entityType: entity[ConfigColumnName.ENTITY_TYPE],
            targetType: entity[ConfigColumnName.TARGET_TYPE],
            configValue: entity[ConfigColumnName.CONFIG_VALUE] ?? undefined,
            clientMeta: entity[ConfigColumnName.CLIENT_META] ?? undefined,
            status: entity[ConfigColumnName.STATUS]
        };
    }
}
