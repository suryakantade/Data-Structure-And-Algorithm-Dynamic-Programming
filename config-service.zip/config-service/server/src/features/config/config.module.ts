import { forwardRef, Module } from "@nestjs/common";
import { ConfigController } from "./config.controller";
import { ConfigRepo } from "./data/config.repo";
import { ConfigService } from "./config.service";
import { RolloutModule } from "../rollout/rollout.module";
import { ConfigValidationService } from "./config-validation.service";
import { ClientConfigService } from "./client-config.service";
import { HashModule } from "../hash/hash.module";

@Module({
    controllers: [ConfigController],
    providers: [ConfigService, ConfigRepo, ConfigValidationService, ClientConfigService],
    exports: [ConfigService],
    imports: [forwardRef(() => RolloutModule), forwardRef(() => HashModule)]
})
export class ConfigModule {}
