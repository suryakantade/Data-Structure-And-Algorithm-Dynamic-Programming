import { ConfigEntityType, ConfigStatus, ConfigTargetType } from "./enums";
import { Tenant } from "../../../common/models/tenant.enum";

/**
 * Can be used for sending Config info to other modules like Rollout. We should not send Entity or DTO objects to other module.
 * Entity and DTO should be internal to a module.
 */
export class Config {
    id: string;
    name: string;
    tenant: Tenant;
    entityType: ConfigEntityType;
    targetType: ConfigTargetType;
    clientMeta?: object;
    configValue?: object;
    status: ConfigStatus;
}
