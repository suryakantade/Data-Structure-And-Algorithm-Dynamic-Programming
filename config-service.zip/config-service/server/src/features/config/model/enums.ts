export enum ConfigEntityType {
    DEFAULT = "DEFAULT",
    FEATURE = "FEATURE",
    VALIDATION = "VALIDATION"
}

export enum ConfigStatus {
    DRAFT = "DRAFT",
    LIVE = "LIVE",
    DELETED = "DELETED"
}

export enum ConfigTargetType {
    USER_ID = "USER_ID",
    ANONYMOUS_ID = "ANONYMOUS_ID"
}
