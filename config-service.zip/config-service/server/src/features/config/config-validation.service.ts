import { Injectable } from "@nestjs/common";
import { ConfigEntity, ConfigUpdateEntity } from "./data/entity/config.entity";
import { WrongInput } from "../../common/error/WrongInput";
import { CONFIG_COLUMNS, ConfigColumnName } from "./data/entity/config.columns";
import * as _ from "lodash";
import { ConfigRepo } from "./data/config.repo";
import * as assert from "assert";

@Injectable()
export class ConfigValidationService {
    constructor(private readonly configRepo: ConfigRepo) {}

    async validateConfigInsert(newEntity: ConfigEntity) {
        const configName = newEntity[ConfigColumnName.NAME];
        const existingEntities = await this.configRepo.getConfigByName(configName);
        if (existingEntities.length !== 0) {
            throw new WrongInput(`Config with name: ${configName} already exists`);
        }
    }

    async validateConfigUpdate(updatedEntity: ConfigUpdateEntity) {
        const configId = updatedEntity[ConfigColumnName.ID];
        const configName = updatedEntity[ConfigColumnName.NAME];
        const tenant = updatedEntity[ConfigColumnName.TENANT];

        const existingEntities = await this.configRepo.getConfigByTenantAndIdAndNameAndEntityType(tenant, configId, [
            configName
        ]);
        if (existingEntities.length === 0) {
            throw new WrongInput(
                `Config with ID ${configId} and name ${configName} does not exist for tenant ${tenant}`
            );
        }
        assert(existingEntities.length === 1, "Multiple configs with same ID cannot exist");
        const existingEntity = existingEntities[0];

        const { status: currentConfigStatus } = existingEntity;

        Object.entries(CONFIG_COLUMNS).forEach(([columnName, columnHelpers]) => {
            if (!(columnName in updatedEntity)) {
                // this column is not getting updated so no need to validate
                return;
            }
            const existingValue = existingEntity[columnName];
            const newValue = updatedEntity[columnName];

            if (!_.isEqual(existingValue, newValue)) {
                const updateEligibility = columnHelpers.canUpdate(currentConfigStatus, existingEntity, updatedEntity);
                if (!updateEligibility.canUpdate) {
                    assert(
                        updateEligibility.failureMessage !== undefined,
                        "Failure message must be passed if update is invalid"
                    );
                    throw new WrongInput(updateEligibility.failureMessage);
                }
            }
        });
    }
}
