import { Inject, Injectable } from "@nestjs/common";
import { Constants } from "../../../utils/constants";
import { DataBase } from "../../../lib/database/database.service";
import { ConfigEntityType } from "../model/enums";
import { ConfigEntity, ConfigUpdateEntity } from "./entity/config.entity";
import { ConfigColumnName } from "./entity/config.columns";
import { Tenant } from "../../../common/models/tenant.enum";

@Injectable()
export class ConfigRepo {
    readonly TABLE_NAME = "config";
    readonly UPSERT_CONFLICT_COLUMNS = ["id", "name"];

    constructor(
        @Inject(Constants.DATABASE_SERVICE_TOKEN)
        protected readonly db: DataBase
    ) {}

    async upsertConfig<T = ConfigEntity | ConfigUpdateEntity>(entity: T): Promise<ConfigEntity[]> {
        return this.db<ConfigEntity>(this.TABLE_NAME)
            .insert(entity)
            .onConflict(this.UPSERT_CONFLICT_COLUMNS)
            .merge()
            .returning("*");
    }

    async getConfigByName(configName: string): Promise<ConfigEntity[]> {
        return this.db<ConfigEntity>(this.TABLE_NAME).select().where({
            name: configName
        });
    }

    async getConfigByTenantAndIdAndNameAndEntityType(
        tenant?: Tenant,
        configId?: string,
        configNames?: string[],
        entityType?: ConfigEntityType
    ): Promise<ConfigEntity[]> {
        let whereClause: object = {};
        if (tenant) {
            whereClause[ConfigColumnName.TENANT] = tenant;
        }
        if (entityType) {
            whereClause[ConfigColumnName.ENTITY_TYPE] = entityType;
        }
        if (configId) {
            whereClause[ConfigColumnName.ID] = configId;
        }
        if (configNames && configNames.length !== 0) {
            return this.db<ConfigEntity>(this.TABLE_NAME).select().whereIn("name", configNames).andWhere(whereClause);
        } else {
            return this.db<ConfigEntity>(this.TABLE_NAME).select().where(whereClause);
        }
    }
}
