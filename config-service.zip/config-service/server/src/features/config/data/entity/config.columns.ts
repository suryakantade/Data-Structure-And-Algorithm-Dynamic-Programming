import { ConfigStatus } from "../../model/enums";
import { ConfigEntity, ConfigUpdateEntity } from "./config.entity";
import { Helper } from "../../../../utils/helper";

export enum ConfigColumnName {
    // columns populated by client
    ID = "id",
    NAME = "name",
    TENANT = "tenant",
    ENTITY_TYPE = "entity_type",
    TARGET_TYPE = "target_type",
    CLIENT_META = "client_meta",
    CONFIG_VALUE = "config_value",
    STATUS = "status",

    // columns populated internally by server
    CREATED_AT = "created_at",
    CREATED_BY = "created_by",
    UPDATED_AT = "updated_at",
    UPDATED_BY = "updated_by"
}

export class UpdateEligibility {
    canUpdate: boolean;
    failureMessage?: string;

    constructor(canUpdate: boolean, failureMessage?: string) {
        this.canUpdate = canUpdate;
        this.failureMessage = failureMessage;
    }

    static ValidUpdate(): UpdateEligibility {
        return new UpdateEligibility(true);
    }

    static InvalidUpdate(failureMessage: string): UpdateEligibility {
        return new UpdateEligibility(false, failureMessage);
    }
}

export interface ConfigColumnHelpers {
    /**
     * Whether updating current value to a new one is valid or not in a given config status.
     */
    canUpdate: (
        currentConfigStatus: ConfigStatus,
        existingEntity: ConfigEntity,
        newEntity: ConfigUpdateEntity
    ) => UpdateEligibility;
}

export const CONFIG_COLUMNS: Record<ConfigColumnName, ConfigColumnHelpers> = {
    [ConfigColumnName.ID]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Config ID cannot be updated")
    },
    [ConfigColumnName.NAME]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Config Name cannot be updated")
    },
    [ConfigColumnName.TENANT]: {
        canUpdate: (currentConfigStatus) => {
            return [ConfigStatus.DRAFT].includes(currentConfigStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Tenant cannot be updated in ${currentConfigStatus} status`);
        }
    },
    [ConfigColumnName.ENTITY_TYPE]: {
        canUpdate: (currentConfigStatus) => {
            return [ConfigStatus.DRAFT].includes(currentConfigStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Entity type cannot be updated in ${currentConfigStatus} status`);
        }
    },
    [ConfigColumnName.TARGET_TYPE]: {
        canUpdate: (currentConfigStatus) => {
            return [ConfigStatus.DRAFT].includes(currentConfigStatus)
                ? UpdateEligibility.ValidUpdate()
                : UpdateEligibility.InvalidUpdate(`Target type cannot be updated in ${currentConfigStatus} status`);
        }
    },
    [ConfigColumnName.CLIENT_META]: {
        canUpdate: (currentConfigStatus, existingEntity, newEntity) => {
            if (![ConfigStatus.DRAFT, ConfigStatus.LIVE].includes(currentConfigStatus)) {
                return UpdateEligibility.InvalidUpdate(
                    `Client Meta cannot be updated in ${currentConfigStatus} status`
                );
            }
            if (currentConfigStatus === ConfigStatus.DRAFT) {
                // any update is allowed
                return UpdateEligibility.ValidUpdate();
            }
            const isStructureMatch = Helper.isStructureMatch(newEntity.client_meta, existingEntity.client_meta);
            if (!isStructureMatch) {
                return UpdateEligibility.InvalidUpdate("New client meta must match existing key structure");
            }
            return UpdateEligibility.ValidUpdate();
        }
    },
    [ConfigColumnName.CONFIG_VALUE]: {
        canUpdate: (currentConfigStatus, existingEntity, newEntity) => {
            if (![ConfigStatus.DRAFT, ConfigStatus.LIVE].includes(currentConfigStatus)) {
                return UpdateEligibility.InvalidUpdate(
                    `Config value cannot be updated in ${currentConfigStatus} status`
                );
            }
            if (currentConfigStatus === ConfigStatus.DRAFT) {
                // any update is allowed
                return UpdateEligibility.ValidUpdate();
            }
            const isStructureMatch = Helper.isStructureMatch(newEntity.config_value, existingEntity.config_value);
            if (!isStructureMatch) {
                return UpdateEligibility.InvalidUpdate("New config value must match existing key structure");
            }
            return UpdateEligibility.ValidUpdate();
        }
    },
    [ConfigColumnName.STATUS]: {
        canUpdate: (currentConfigStatus, existingEntity, newEntity) => {
            if (![ConfigStatus.DRAFT, ConfigStatus.LIVE].includes(currentConfigStatus)) {
                return UpdateEligibility.InvalidUpdate(`Status cannot be updated in ${currentConfigStatus} status`);
            }
            const { status: currentStatus } = existingEntity;
            const { status: newStatus } = newEntity;
            let isStatusTransitionValid: boolean = true;
            if (currentStatus === newStatus) {
                return UpdateEligibility.ValidUpdate();
            }
            switch (currentStatus) {
                case ConfigStatus.DRAFT:
                    isStatusTransitionValid = [ConfigStatus.LIVE, ConfigStatus.DELETED].includes(newStatus);
                    break;
                case ConfigStatus.LIVE:
                    isStatusTransitionValid = [ConfigStatus.DELETED].includes(newStatus);
                    break;
                case ConfigStatus.DELETED:
                    isStatusTransitionValid = false;
                    break;
                default:
                    isStatusTransitionValid = false;
                    break;
            }
            if (isStatusTransitionValid) {
                return UpdateEligibility.ValidUpdate();
            } else {
                return UpdateEligibility.InvalidUpdate(
                    `Status transition from ${currentStatus} to ${newStatus} is not allowed`
                );
            }
        }
    },
    [ConfigColumnName.CREATED_AT]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Created At cannot be updated")
    },
    [ConfigColumnName.CREATED_BY]: {
        canUpdate: () => UpdateEligibility.InvalidUpdate("Created By cannot be updated")
    },
    [ConfigColumnName.UPDATED_AT]: {
        canUpdate: () => UpdateEligibility.ValidUpdate()
    },
    [ConfigColumnName.UPDATED_BY]: {
        canUpdate: () => UpdateEligibility.ValidUpdate()
    }
};
