import { ConfigEntityType, ConfigStatus, ConfigTargetType } from "../../model/enums";
import { ConfigColumnName } from "./config.columns";
import { Tenant } from "../../../../common/models/tenant.enum";

export class ConfigEntity {
    [ConfigColumnName.ID]: string;

    [ConfigColumnName.NAME]: string;

    [ConfigColumnName.TENANT]: Tenant;

    [ConfigColumnName.ENTITY_TYPE]: ConfigEntityType;

    [ConfigColumnName.TARGET_TYPE]: ConfigTargetType;

    [ConfigColumnName.CLIENT_META]: object | null;

    [ConfigColumnName.CONFIG_VALUE]: object | null;

    [ConfigColumnName.STATUS]: ConfigStatus;

    [ConfigColumnName.CREATED_AT]: string;

    // this is nullable column in DB, knex returns DB NULL values as javascript "null" object and not as "undefined".
    // That's why not adding undefined in type definition.
    [ConfigColumnName.CREATED_BY]: string | null;

    [ConfigColumnName.UPDATED_AT]: string;

    [ConfigColumnName.UPDATED_BY]: string | null;
}

// to ensure that created_at and created_by are never updated for an already present row
export type ConfigUpdateEntity = Omit<ConfigEntity, ConfigColumnName.CREATED_AT | ConfigColumnName.CREATED_BY>;
