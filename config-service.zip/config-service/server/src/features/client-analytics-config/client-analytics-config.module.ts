import { Module } from '@nestjs/common';
import { LibModule } from '../../lib/lib.module';
import { ClientAnalyticsController } from './client-analytics-config.controller';
import { ClientAnalyticsConfigService } from './client-analytics-config.service';

@Module({
    imports: [LibModule],
    controllers: [ClientAnalyticsController],
    providers: [ClientAnalyticsConfigService],
    
})
export class ClientAnalyticsModule { }
