import { LogService } from "@khatabook/nestjs-logger";
import { Injectable, OnModuleInit } from "@nestjs/common";
import { SchedulerRegistry } from "@nestjs/schedule";
import { EventService, EventServiceEvents } from "../../lib/event/event.service";
import { S3Service } from "../../lib/s3/s3.service";
import { Helper } from "../../utils/helper";
import { ClientAnalyticsRequestDTO } from "./dto/client-analytics-request.dto";
import { ClientAnalyticsConfigDTO } from "./dto/client-analytics.dto";
import { InternalConfigService } from "../../lib/internal-config/internal-config.service";
import { CustomError } from "@khatabook/test-sdk/build/common/exception-handler/custom-error";

const hash = require("object-hash");

@Injectable()
export class ClientAnalyticsConfigService implements OnModuleInit {
    private lastComputedHash: string;

    private clientAnalyticsConfigList: ClientAnalyticsConfigDTO[];

    constructor(
        readonly s3Service: S3Service,
        readonly configService: InternalConfigService,
        readonly schedulerRegistry: SchedulerRegistry,
        readonly eventService: EventService,
        readonly logger: LogService
    ) {
        this.eventService.on(EventServiceEvents.APP_STARTED, this.loadAnalyticsConfig.bind(this));
        this.logger.setContext(ClientAnalyticsConfigService.name);
    }

    onModuleInit() {
        const jobIntervalInMs = this.configService.getClientAnalyticsConfig().refreshInterval;

        const interval = setInterval(this.loadAnalyticsConfig.bind(this), jobIntervalInMs);
        this.schedulerRegistry.addInterval("loadConfig", interval);
    }

    public async getAnalyticsConfig(clientAnalyticsRequestDTO: ClientAnalyticsRequestDTO) {
        let analyticsConfig: ClientAnalyticsConfigDTO[] = [];
        if (!clientAnalyticsRequestDTO.hash || clientAnalyticsRequestDTO.hash != this.lastComputedHash) {
            analyticsConfig = this.clientAnalyticsConfigList;
        }

        return {
            config: analyticsConfig,
            hash: this.lastComputedHash
        };
    }

    async getFromS3ByTenant(): Promise<ClientAnalyticsConfigDTO[]> {
        const { Body } = await this.s3Service.getObject(
            this.configService.getClientAnalyticsConfig().analyticsPath,
            this.configService.getClientAnalyticsConfig().bucket
        );

        if (!Body) {
            this.logger.error(
                {
                    err: new CustomError("Error loading from S3"),
                    data: {
                        path: this.configService.getClientAnalyticsConfig().analyticsPath,
                        s3Bucket: this.configService.getClientAnalyticsConfig().analyticsPath
                    }
                },
                "analytics config refresh ERROR Loading Data from S3"
            );
            throw new CustomError("analytics config refresh ERROR Loading Data from S3");
        }

        let body = JSON.parse(Body.toString("utf-8"));
        return body;
    }

    async loadAnalyticsConfig() {
        try {
            let configuredClientAnalyitcsFromS3: ClientAnalyticsConfigDTO[] = await this.getFromS3ByTenant();
            const computedHash = await this.computeHash(configuredClientAnalyitcsFromS3);
            if (!this.lastComputedHash || this.lastComputedHash != computedHash) {
                this.clientAnalyticsConfigList = configuredClientAnalyitcsFromS3;
                this.lastComputedHash = computedHash;
            }
        } catch (error) {
            this.logger.error({ err: error }, `Error while loading client analytics config from s3`);
        }
    }

    async computeHash(clientAnalyticsRequestList: ClientAnalyticsConfigDTO[]): Promise<string> {
        return hash(clientAnalyticsRequestList, {
            algorithm: "md5",
            encoding: "base64"
        });
    }
}
