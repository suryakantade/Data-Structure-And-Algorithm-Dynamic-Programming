import { Controller, Get, Query } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { ClientAnalyticsConfigService } from "./client-analytics-config.service";
import { ClientAnalyticsRequestDTO } from "./dto/client-analytics-request.dto";

@ApiTags("analytics")
@Controller({
    path: "analytics",
    version: "1"
})
export class ClientAnalyticsController {
    constructor(private readonly clientAnalyticsConfigService: ClientAnalyticsConfigService) {}

    @Get("config")
    async getRules(@Query() query: ClientAnalyticsRequestDTO) {
      return await this.clientAnalyticsConfigService.getAnalyticsConfig(query);
    }

}
