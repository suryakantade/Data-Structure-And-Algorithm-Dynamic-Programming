import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, Min } from 'class-validator';

export class ClientAnalyticsRequestDTO{

    @ApiProperty()
    @ApiPropertyOptional()
    @IsString()
    @IsOptional()
    hash?: string;

}