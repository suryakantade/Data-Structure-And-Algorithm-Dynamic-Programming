
export class ClientAnalyticsConfigDTO {

    name: string;

    feature?: string;

    description?: string;

    segment?: boolean;

    clever_tap?: boolean;

    firebase?: boolean;

    singular?: boolean;

    user_leap?: boolean;

    hansel?: boolean;

    frequency?: string;

    frequency_meta?: string;
}
