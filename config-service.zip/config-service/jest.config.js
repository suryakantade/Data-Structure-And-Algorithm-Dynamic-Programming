module.exports = {
    roots: ["./server", "./tests"],
    testMatch: [
        "./**/integration/?(*.)+(intg.spec).+(ts|tsx)",
        "./**/unit/?(*.)+(unit.spec).+(ts|tsx)",
        "./**/boot/?(*.)+(test).+(ts|tsx|js)"
    ],
    preset: "ts-jest",
    verbose: true,
    clearMocks: true, // at describe level
    restoreMocks: true, // This will lead to any mocks having their fake implementations removed and restores their initial implementation.
    globalSetup: "<rootDir>/tests/test-global-init.ts",
    globalTeardown: "<rootDir>/tests/test-global-teardown.ts",
    testResultsProcessor: "jest",
    testEnvironment: "node",
    collectCoverage: true,
    coverageDirectory: "temp/coverage",
    collectCoverageFrom: ["<rootDir>/server/src/**/*.ts"],
    coveragePathIgnorePatterns: [
        "<rootDir>/server/src/.*/tests/.*|(\\.|/)(spec)\\.ts",
        "<rootDir>/server/src/common/error/*"
    ],
    coverageReporters: ["text-summary", "html", "lcov"],
    moduleDirectories: ["node_modules", "server"],
    reporters: [
        "default",
        [
            "jest-junit",
            {
                suiteName: "Jest Test Report",
                outputDirectory: "temp/",
                outputName: "junit.xml"
            }
        ],
        [
            "jest-html-reporters",
            {
                publicPath: "temp/test-report",
                filename: "report.html",
                pageTitle: "Jest Test Report",
                expand: true
            }
        ]
    ]
};
